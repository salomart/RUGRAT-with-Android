																	Welcome to the RUGRAT experiment setup 'How to'.
																	
Description:
------------
RUGRAT was used to create over 70 Java benchmark programs ranging 300K to 5M LOC in size. These generated programs, in total, size
more than 90 GB. These were used to run different program analysis tools to evaluate their performance. For space limitation, it is 
not possible to distribute or publish all these generated programs. In the containing folder, we provide scripts to re-create these
programs.

In this step-by-step tutorial we demonstrate how to setup the experiment environment to recreate the RUGRAT results.

Pre-requisite:
-----------------
	1. As mentioned in the website, you need to have Java, Ant, FindBugs, PMD, JLint and Randoop tools installed in your machine.
		Please refer to the respective websites (links can be found in the RUGRAT website: www.rugrat.ws) to collect them.
	2. The ant build files invoke these tools. So, you need to update individual ant scripts to refer to the 
		directories where you installed these tools.
		For Example, in "scripts\TestRun1\10KLOC\FindBugs build\min" you need to specify FindBugs installation directory.
	3. Download the RUGRAT source code. 
	4. Depending up on the number of experiments you would like to run (in our case, we ran 10 of them), copy 'TestRun1' 
		and rename it as 'TestRun2', 'TestRun3', etc.		
	5. Inside 'Configs' folder, we have defined ranges for different program characteristics for each category of programs (10K, 50K LOC etc.).
		You can modify it to match your need. These are used to automatically create random configuration files for RUGRAT.
	6. Run ConfigCreator.java in "edu.uta.cse.rugrat.config" package. This takes 2 command-line arguments:
		args[0] = Path to 'Configs' folder
		args[1] = Path to the folder that holds 'TestRun1', 'TestRun2' as sub-folders.
		This will create random configuration files for each program category.
	7. From command-prompt, go the 'scripts' folder and type: ant -k TestRun1 <TestRun2> <TestRun3> ...
		This will begin executing the experiments.
		

NOTE:
-----
	1. To analyze the results, please refer to 'edu.uta.cse.rugrat.result' package in the source code. 
		It has self-explaining, straight forward result processing code to summarize the results.
	2. Because of the random nature of RUGRAT tool, generated programs may vary from the ones actually used in the experiment.
		But this will not affect the research findings for the experiment.
	
	
For further information and bug report:
---------------------------------------
Please send your queries to:
	Ishtiaque Hussain (ishtiaque.hussain@mavs.uta.edu)
	Christoph Csallner (csallner@uta.edu)
	Mark Grechanik (mark.grechanik@accenture.com)
	