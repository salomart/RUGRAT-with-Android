package com.accenture.lab.carfast.test;


public class TenKLOC2 implements TenKLOCInterface2 {
static byte[] f0= new byte[21];
int f1;
int f2;


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC2 classObj = new TenKLOC2();
if( ((var0+"ylrhsgzeipjfvpifqhtylhqfhdtkvaieqodswayxmawvbjbujvswyxamtl")==((var0+"ol")+(var0+"disuuwnqhefagbcxrw")))){
if( ((var0+"dpgnqkwjwvciorcotgabcpkxaimxsdlvqnupkstmhosclcsarbtekmntpzhoatpxychkbzifygmmhcmgtnqmvefsubatpdussf")!=(var0+"psrkgnwhqnphlnjagvoseliwqjbmuqhslzwticvgemfdvghyzejzvohjupranivdqpstwclchwedfpxtl"))){
if( ((var1*(short)(13546))==(var1%(short)(20386)))){
TenKLOC7.TenKLOC7method2('z',(int)(245),(int)(127),'a','h');
}
}
}
if( (((var0+"xfowqorhepukoqxxibbscdokqzfwqcbpjeisrlz")==(var0+"eecdpwbynysmlupawxwnktlyndhkwutjannufkwkvgreqxaflx"))||((var0+"onoocayurwvxlkuqwlzqxaqydemkkbufoolpefwzgtrmifqizdsvdmvrujtzxjkxqqktmrrtoxzgrvhxwwikfurkqpbdhj")!=(var0+"yztskgbkgxcwcnfuzxbnlzxplzxugbd")))){
var2 = new TenKLOC7();
}
if( ((var1/(short)(1145))!=(var1/(short)(4206)))){
System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 13");
}
if((((var0+"vimcsuvzvaisbwdqvuqvrjogxecjrkpozksbyxdhtfhjsawixjaemfdfj")==(var0+"slmfprcvjiqoumckyncenxlrjqxqoebimrtbzungotarqwoduxtcpwnfmbiavrpghlrvfkxiuvhlwjaxv"))||((var0+"srszqmrilxteszwxzjrfjosnxbfgnhyutqsdzntzinnvkelvlfaqh")==(var0+"gkyknaoqdfyauqitfqkrsgpuufabjckoxizixgsyicnbfttzuwajik")))){
System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 22");
}
else{
 System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 27");
}
if((((var0+"plrqwubovaksmqcogqidqmhbumfbipxetkbfcbjqrtkdchzomnphgijicowishndlyhnxckjcyapihwhnkbezbhrtojvioswjn")==(var0+"snmhhsptyyvpdgc"))&&((((var0+"evqdeqcmidqfdpylbnseguonhwkkpzheaofejcsttssqstjwsqcruomhyggqmbkzktsinkxfgppszmoeuuzsmmdtwqgxjaqmsec")+(var0+"ejynrbhhxkdxndqecbmssegilojgxnaqvkz"))+(var0+"phvjvzetqxq"))!=(var0+"zbczaryxpeiujpywovkikjmqrfjqtpuzfkgxonrtlbruzwgqcyhly")))){
System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 36");
}
else{
 System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 39");
}
for(int i = 0; i < 4; i++){
 if( (((var0+"weldtxizkeptlundssetvhxibukpbsnhtzyjborgbpiigzahdumnkuzxjehiepbvkoredjvhjykl")!=(var0+"axomybbuykfloaexkarjmwuytbswhu"))&&((var0+"rwpvrmwujokyayrmaulaekperbumvcyqcsczidkpnol")!=(var0+"uxmvouzikejnomzicenog")))){
System.out.println("TenKLOC2 - TenKLOCInterface2Method0- LineInMethod: 46");
}
}
if( (((var1+(short)(26134))!=(var1*(short)(16908)))&&((var1-(short)(22617))<=((var1-(short)(14661))+(var1-(short)(13507)))))){
var1 = (short)((((var1+(short)(14628))+(var1%(short)(4636)))+((var1+(short)(14819))*(((var1+(short)(22473))+((var1-(short)(16670))+(var1/(short)(18687))))+(var1*(short)(29391)))))+(var1-(short)(13322)));
}
if( ((var1-(short)(12112))<=(var1/(short)(22622)))){
var2 = new TenKLOC7();
}
if( ((var0+"zrscdyhsuscwgkycpzkgbtygyjtmfwitszgbpnhtyecnixsekvuxziqjivudvkehoybbmopadasntxoygclifhtmvpvn")==(var0+"yfqzfzcdqmbyqlruxnexajhzjbrlroocrzhoexytqqiobpoeztznagzpskrwxaanfsxiyttchntuwyjlirsrcbhvkexfl"))){
var1 = (short)((var1%(short)(16304))*(var1+(short)(12130)));
}
return (short)var1;

}

public float TenKLOC2method0(short var0, String var1, short var2){
 TenKLOC2 classObj = new TenKLOC2();
if(((var1+"jdpdlfohptesdjdnztxotbrqvxsxvsfwrihpvyzapxislexhykojjxgccjxliaotqhigotknbtktilnxbkxrmogbgtcxbbvg")!=(var1+"kecqmfmhzucreeoaghlwhasgglxj"))){
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 5");
}
if( ((var0*(short)(18176))!=(var2-var0))){
if( (((var1+"ycqyvevfillktfbhsbmgaecdlekauvrzbarvzgwplycgleinlxqlgpguxitwvzkgpsmgtix")+(var1+"khgdzcodeunrkwhpmgzocfqhaclloynzfbvdmgxlbrzxdtchjtrtiqopuxtgqvwlhqbudofzrflzodgmnpsxkoyidkgje"))==((var1+"ztmempqswiywnwjbxyhfcsxmwmluvmvxpmhnuztbcvpdjdzfqwmcvsgvnqxftxzjnehxazocgytcsjeuzkaqyzistokfk")+((var1+"znsvnfahezafjgkyczvjekoujxyajevykurxxssgguhpvfptqzfccwxbptykkqeohuazejsrwfzcrgtrcmspumxemfepazuegnfhz")+(var1+"rhyqybohrzmoznvmmupaxywvrujn"))))){
if( ((var0*(short)(17001))==((var0-(short)(10405))*(var2/(short)(7179))))){
var1 = (String)(((var1+"qjzdtkgw")+(var1+"mayzobkdhfaxwgmtmrpvfozwmhvkjqklwcxhfmvlvzswqlglgpukvwlvyirfgxqvfuicxodjgsqwxugtkdkejupck"))+(var1+"qmymibuptkqyhdnojjdetpsthnkywsnuh"));
}
}
}
for(int i = 0; i < 6; i++){
 f1 = (int)(((int)(267)%(int)(531))*(((int)(235)*(int)(648))/(int)(341)));
}
if(((var1+"lpwopzpqgolumrjnlpsbnbcpojauercksugmvoyemzwabepfprglnkwsocxsnrbsomee")!=((var1+"euvzjdzhmlsvlraaukzbyoaxhlnbhojulwkuteyuvkoyhjzvgsmbzerpbob")+(var1+"fpforrzizigugkugcnzyjsur")))){
System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 21");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 25");
}
if((((var0+(short)(8345))*(var2+(short)(24449)))>=(var2+var0))){
System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 30");
}
else{
 f2 = (int)((int)(250)-(int)(247));
}
if( ((var2-(short)(6646))<(var2%(short)(4812)))){
var2 = (short)((var0+(short)(2292))*(var2+var0));
}
if(((var1+"eilogcpknoptidgcevnxap")==(var1+"vkadihyxnscdthikqxfouaucepr"))){
var1 = (String)((var1+"dhmvqhydcgrphfiftqyvlgmsu")+((var1+"qgnoxrovoyabdhnzaexdkttgbaikhawgmfkpsopepfszzj")+(var1+"qstuxciiathhwxrfuocslufuqrqfuaiwb")));
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 43");
}
if((((var1+"viyyegvfkfviweipurtxpdahpqttmvzeyuultraricznrxvpfouinnaupffwyn")+(var1+"jdfvdukbfyxpwxowwjonsflbmposqdudvhvgpayvjiveidkexnlyffljqwkdazebqibohtscf"))==(var1+"dgppcrqzbxqn"))){
System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 48");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 52");
}
if( ((var1+"prhlhqajlezxcddipyghugeqtdlfyzaeinbnwaltepeakrtnxhqwowuzicalfpor")!=(var1+"fhowthauflkpeaztkcpggxamiylafubcmpehjy"))){
System.out.println("TenKLOC2 - TenKLOC2method0- LineInMethod: 55");
}
return (float)(float)(0.3832143);

}

public static int TenKLOC2method1(short var0, TenKLOC9 var1, int var2){
 TenKLOC2 classObj = new TenKLOC2();
for(int i = 0; i < 2; i++){
 f0[5] = (byte)((byte)(25)*(byte)(-3));
}
if( (((var0/(short)(6322))-((var0/(short)(3621))-(var0-(short)(1285))))==((var0*(short)(7445))%(short)(30417)))){
var1 = new TenKLOC9();
}
if( ((((((var2/(int)(507))-((var2/(int)(589))+(((var2+(int)(140))-(var2+(int)(89)))%(int)(464))))>(((var2%(int)(738))%(int)(672))+(var2*(int)(132))))&&((var2-(int)(106))>=(var2+(int)(108))))&&((((var2*(int)(427))<=((var2+(int)(77))*((var2%(int)(93))-(var2+(int)(601)))))&&((var2-(int)(429))>(var2*(int)(536))))&&((var2+(int)(23))>=(var2+(int)(120)))))&&((var2+(int)(52))<(var2-(int)(613))))){
var1 = new TenKLOC9();
var1.TenKLOC9method1('t','h',(long)(655));
}
if( ((var2*(int)(712))>=(var2%(int)(59)))){
if( ((var2-(int)(304))>=(var2+(int)(736)))){
if( ((var2%(int)(256))<(var2*(int)(313)))){
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 16");
}
}
}
switch((var2*(int)(653))){
case 0:
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 19");
 break;
case 1:
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 26");
 break;
case 2:
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 31");
 break;
case 3:
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 35");
 break;
case 4:
var1 = new TenKLOC9();
 break;
case 5:
var1 = new TenKLOC9();
 break;
case 6:
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 46");
 break;
default :
var1 = new TenKLOC9();
}
if(((var2*(int)(42))<=(var2*(int)(164)))){
System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 56");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method1- LineInMethod: 59");
}
return (int)var2;

}

public static char TenKLOC2method2(byte var0, float var1, short var2){
 TenKLOC2 classObj = new TenKLOC2();
if(((var1*(float)(0.50019455))<=(var1-(float)(0.66526437)))){
var0 = (byte)(-5);
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 5");
}
if(((var2+(short)(1370))>=((var2-(short)(17916))-(var2*(short)(30838))))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 11");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 13");
}
if(((var2+(short)(12917))>(((var2*(short)(27705))*(var2+(short)(26746)))*(var2-(short)(17451))))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 18");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 21");
}
if( (((var1/(float)(0.8311188))<(var1/(float)(0.60963374)))&&(((var1/(float)(0.5468158))%(float)(0.4651997))==(var1-(float)(0.6680261))))){
if( ((((var1-(float)(0.32442462))<(var1%(float)(0.9201076)))&&((var1+(float)(0.6877479))!=(var1*(float)(0.55173486))))&&((var1*(float)(0.26083577))<=(var1/(float)(0.8314867))))){
if( ((var0-(byte)(-110))>(var0%(byte)(-95)))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 28");
}
}
}
if( ((var0+(byte)(-49))==(var0-(byte)(-72)))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 35");
}
if(((((var1*(float)(0.2335118))*((var1-(float)(0.94341534))*(var1-(float)(0.7993792))))*(var1*(float)(0.032616913)))!=(var1/(float)(0.38026422)))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 43");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 46");
}
if(((var0-(byte)(-123))<((f0[5]*f0[14])*((f0[4]/(byte)(13))-(((f0[7]+f0[3])*(f0[12]/(byte)(-78)))+((f0[10]*f0[14])-(f0[8]+f0[2]))))))){
System.out.println("TenKLOC2 - TenKLOC2method2- LineInMethod: 55");
}
else{
 var1 = (float)((var1*(float)(0.5543521))*(var1-(float)(0.40449685)));
}
return (char)'d';

}

public static Object TenKLOC2method3(TenKLOC16 var0, int var1, String var2, String var3, float var4, byte var5){
 TenKLOC2 classObj = new TenKLOC2();
if( ((var4+(float)(0.5796288))<=(var4-(float)(0.78442603)))){
var5 = (byte)(-128);
}
if((((var1+(int)(221))-(var1+(int)(456)))>(var1*(int)(455)))){
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 7");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 11");
}
if(((var2+"ynyyfhgmqixbckzvlthqguapkruxiig")!=(var2+"xcnulututtsnnujbgrtjamfxvreyytozguxworuebvznbgtsmazjveeaeeifkcdn"))){
var5 = (byte)(f0[4]+f0[3]);
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 19");
}
if( ((var4-(float)(0.7539299))==((var4+(float)(0.5114047))-((var4*(float)(0.57940763))-((var4*(float)(0.9200926))+((var4-(float)(0.7959007))%(float)(0.051003397))))))){
var1 = (int)(((var1+(int)(92))+(var1*(int)(133)))-(var1*(int)(629)));
}
if( ((((var4+(float)(0.67305577))>=(var4+(float)(0.7001236)))&&((var4+(float)(0.66236985))<(((var4*(float)(0.49688458))*(var4/(float)(0.85217845)))+(var4-(float)(0.85689414)))))&&((var4*(float)(0.51055133))>=(var4+(float)(0.49102628))))){
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 26");
}
if(((var4*(float)(0.7814097))>(var4+(float)(0.66684943)))){
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 34");
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 38");
}
if( ((var4+(float)(0.5764076))>(var4*(float)(0.62618273)))){
if( ((var4-(float)(0.8688407))<=(var4+(float)(0.61977607)))){
if( (((f0[16]%(byte)(-42))<(var5/(byte)(116)))||(((f0[19]-f0[12])*((f0[18]%(byte)(10))+((f0[19]*(byte)(37))-((f0[19]+f0[1])/(byte)(-88)))))!=((var5+(byte)(85))*(var5-(byte)(49)))))){
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 45");
}
}
}
if( ((var5-(byte)(32))!=(var5-(byte)(85)))){
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 51");
}
switch((var1*(int)(144))){
case 0:
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 54");
 break;
case 1:
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 57");
 break;
case 2:
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 64");
 break;
default :
System.out.println("TenKLOC2 - TenKLOC2method3- LineInMethod: 68");
}
return (Object)var0;

}

public Object TenKLOC2method4(byte var0, TenKLOC18 var1, String var2){
 TenKLOC2 classObj = new TenKLOC2();
if( ((var0/(byte)(112))<(var0*(byte)(9)))){
TenKLOC18.TenKLOC18method1((double)(0.5883773783504079),var2,(short)(19940));
}
for(int i = 0; i < 3; i++){
 f2 = (int)(((int)(175)-(int)(362))*((int)(20)*(int)(597)));
}
if( (((var0*(byte)(125))!=((var0-(byte)(-70))*(var0+(byte)(42))))||((var0*(byte)(-51))!=(var0+(byte)(-26))))){
System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 9");
}
if(((var2+"oeauasmybxhtaftsgvhemjurttnoudbicifeodmrhuchlemdorcjvgnatfaagvmhskwlcrufqcdfwpuu")==((var2+"zacgdtgaphlidfooipal")+(var2+"fpxcqrqyotsnxdylantnsmoyxnfzbzqeepsovijmvunrvdinqypargxxotkubtnsulefwhedxnsqrmuwcgj")))){
var0 = (byte)((var0+(byte)(44))-(((var0*(byte)(-8))-(var0-(byte)(-98)))%(byte)(-7)));
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 16");
}
if( ((var2+"tdwaelywuqfvxrdffmtjdfvuwewxffmqhsugitdjyzpxnnibh")==((var2+"psqaoputflptsbcrjzjhiyznzjjubuszzymigyovtbszbjgbzhxymekkpfjinyjocpetgd")+(var2+"zhstridrwupuyyjdcngi")))){
if( ((var0/(byte)(-17))<=(var0+(byte)(-24)))){
if( (((((var0+(byte)(-86))%(byte)(48))-(var0-(byte)(40)))==(var0*(byte)(66)))&&((var0+(byte)(66))!=(var0+(byte)(-101))))){
System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 23");
}
}
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 27");
}
if((((var2+"tkqpapqjktzzrqistynkrwncuhfsafolefewjambhnxjfozhtaaowczzbhjuaqggqtvzqtaqhtgjevjlmysbhni")+(var2+"vxqdrjquci"))==(var2+"rxdbpawkkdhqgvtyilxfpeibniwhujzknghghyyxvzbpeawriwjmsxlbgppmncwwttmlcyjawhhvkrzlpald"))){
var1 = new TenKLOC18();
}
else{
 System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 34");
}
if((((var0%(byte)(-91))-(var0/(byte)(-88)))==((var0+(byte)(-97))-(var0-(byte)(-40))))){
System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 42");
}
else{
 var1 = new TenKLOC18();
}
for(int i = 0; i < 9; i++){
 f1 = (int)(((int)(394)*(int)(545))%(int)(594));
}
if( ((var0%(byte)(-52))==(var0%(byte)(-37)))){
f2 = (int)(((int)(534)-(int)(765))+((f1/(int)(245))+(f1*f2)));
}
for(int i = 0; i < 8; i++){
 if( ((var2+"frqhpw")!=(var2+"gkujljciuzcvbrbosvzrljpecflhlfgfwrhxoiwzecwpramkgpmvrmlstena"))){
System.out.println("TenKLOC2 - TenKLOC2method4- LineInMethod: 58");
}
}
return (Object)var1;

}


public static void main(String args[]){
TenKLOC2 obj = new TenKLOC2();
obj.TenKLOCInterface2Method0("chpquohxcbrxnxpqmgrjwejrjztedcgoxfmjlc",(short)(9718),new TenKLOC7());
obj.TenKLOC2method0((short)(625),"xsojdlgnhetfdpqxqzubfqfpfgwqqnjzqedphtideurjzuhewmdniypijfje",(short)(16990));
TenKLOC2method1((short)(20438),new TenKLOC9(),(int)(223));
TenKLOC2method2((byte)(79),(float)(0.5544139),(short)(24120));
TenKLOC2method3(new TenKLOC16(),(int)(749),"maxdnftvlbnsameiknhhlpvphrxcwqpbdsemyoiwybxszjyryuzditfsrpibzdgousfmolygtnhwldtty","msiehcavbdzbhyrgviet",(float)(0.76091284),(byte)(-114));
obj.TenKLOC2method4((byte)(-22),new TenKLOC18(),"sjphudbcotyuhgmaiorgaeagfzposncxmbbnciltciuizjnbjnhuurpktxyjjgmcpunepxhjjp");
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC2 obj = new TenKLOC2();
obj.TenKLOCInterface2Method0("kgtegelthcbabsmjatngzihpxvuiix",(short)(6117),new TenKLOC7());
obj.TenKLOC2method0((short)(18080),"wtqtxykroymynraeimnujlkzdgythpelkzkqsqpfbdpqehdmamdyhlyamnwrftmibrbpwxoorpqnaeozae",(short)(27182));
TenKLOC2method1((short)(13825),new TenKLOC9(),i4);
TenKLOC2method2((byte)(-102),(float)(0.07887471),(short)(7158));
TenKLOC2method3(new TenKLOC16(),i5,"nbdqdaizowcbdyxhulgsiljdlvzqhodnqgyjxbxajofoovrwcpequcmhixylauclugr","onvjzyytjnsmeudiwcnhngknkxdlamqmqjygfmclfufqeehrrduwukqbjgpvxjmdwsmh",(float)(0.17020404),(byte)(-110));
obj.TenKLOC2method4((byte)(92),new TenKLOC18(),"qjxwmpjezobtvhgznwayoejryuxgaatbygqjbqcwfmeswltwxtfqx");
}

}