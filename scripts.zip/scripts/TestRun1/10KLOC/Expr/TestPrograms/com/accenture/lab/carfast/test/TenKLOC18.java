package com.accenture.lab.carfast.test;


public class TenKLOC18 implements TenKLOCInterface1 {
short[] f0= new short[114];
static String f1;


public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2){
 TenKLOC18 classObj = new TenKLOC18();
if(((var0+(int)(304))<=((var0+(int)(238))+(var0*(int)(561))))){
f0[14] = (short)((var2*(short)(24824))-((f0[45]*f0[9])-(f0[12]%(short)(3904))));
}
else{
 System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 6");
}
switch((((var0/(int)(347))/(int)(751))%(int)(688))){
case 0:
System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 13");
 break;
case 1:
var0 = (int)((var0-(int)(176))+(var0-(int)(531)));
 break;
case 2:
f0[8] = (short)((var2-(short)(28460))-(var2-(short)(32157)));
 break;
case 3:
TenKLOC29.TenKLOC29method4(null,var2,var0);
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 27");
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 32");
 break;
case 6:
System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 39");
 break;
default :
System.out.println("TenKLOC18 - TenKLOCInterface1Method0- LineInMethod: 42");
}
return (short)var2;

}

public String TenKLOCInterface1Method1(int var0, byte var1, String var2){
 TenKLOC18 classObj = new TenKLOC18();
for(int i = 0; i < 9; i++){
 if( (((var1*(byte)(-32))>(var1+(byte)(-101)))||((var1+(byte)(-101))!=(var1%(byte)(-50))))){
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 5");
}
}
if(((var0/(int)(196))!=(var0/(int)(576)))){
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 11");
}
else{
 var1 = (byte)(-66);
}
switch((var0*(int)(199))){
case 0:
f0[64] = (short)(f0[52]+f0[111]);
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 20");
 break;
case 2:
var0 = (int)((var0+(int)(675))/(int)(499));
 break;
case 3:
var2 = (String)((var2+"ezejsmpnejhwqpmtirqajtpisimasqmmpmbheyytqaslxtjzzojqpgciugsdjuamcphbwaacyw")+(var2+"gezratmdlzcbpjqugajetsoednfzkucqabokmwvdgiubokirnsdrupwduezrrzminewqunereez"));
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 30");
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 34");
 break;
case 6:
f0[111] = (short)((((short)(32761)/(short)(2541))+((short)(2268)/(short)(5013)))*((short)(17389)+(short)(13235)));
 break;
default :
System.out.println("TenKLOC18 - TenKLOCInterface1Method1- LineInMethod: 41");
}
return (String)var2;

}

public Object TenKLOCInterface1Method2(double var0, byte var1, int var2){
 TenKLOC18 classObj = new TenKLOC18();
for(int i = 0; i < 0; i++){
 if( ((var0*(double)(0.4123360305679781))>(var0+(double)(0.5345321007226501)))){
var2 = (int)(var2*(int)(598));
}
}
if((((var1*(byte)(50))!=(var1*(byte)(-120)))&&((var1*(byte)(43))<(var1%(byte)(-15))))){
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 10");
}
else{
 System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 12");
}
for(int i = 0; i < 6; i++){
 if( (((var1%(byte)(76))<(var1/(byte)(51)))&&(((var1+(byte)(121))==(var1*(byte)(63)))||((var1/(byte)(59))>=(var1*(byte)(24)))))){
if( ((var0+(double)(0.5647995163999977))>(var0/(double)(0.14726448206847564)))){
if( (((((var2/(int)(473))-(var2+(int)(704)))+(var2*(int)(546)))>(var2+(int)(679)))&&((var2-(int)(55))<=(var2-(int)(486))))){
}
}
}
}
if( (((((var2/(int)(123))%(int)(723))+((var2+(int)(274))/(int)(372)))%(int)(565))<=((var2+(int)(770))-(var2*(int)(418))))){
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 27");
}
switch((var2/(int)(685))){
case 0:
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 32");
 break;
case 1:
var0 = (double)((var0*(double)(0.9176421704496639))%(double)(0.27964748250647287));
 break;
case 2:
f0[103] = (short)((f0[89]*f0[104])+((short)(28725)%(short)(7229)));
 break;
case 3:
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 44");
 break;
case 4:
f0[84] = (short)(((short)(6222)+(short)(11914))-((short)(12528)*(short)(19781)));
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 50");
 break;
case 6:
var2 = (int)((var2-(int)(386))-(var2*(int)(624)));
 break;
case 7:
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 59");
 break;
case 8:
var1 = (byte)(var1-(byte)(-40));
 break;
default :
System.out.println("TenKLOC18 - TenKLOCInterface1Method2- LineInMethod: 65");
}
return (Object)null;

}

public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2){
 TenKLOC18 classObj = new TenKLOC18();
switch((var2-(int)(30))){
case 0:
var2 = (int)((var2/(int)(222))*(var2%(int)(618)));
 break;
case 1:
var1 = TenKLOC16.TenKLOC16method0("brhtcipiaxwymqeaxzawommexkauoymmqyqzpocuywzjevrsjcbwltzxlqytkdpxyruszlbhlyzkwsdcjopjwizmqbleasnxds",(double)(0.7673123188484531),var2);

 break;
case 2:
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 9");
 break;
default :
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 16");
}
if( (((var2%(int)(172))>=(var2*(int)(207)))||((var2/(int)(536))==((var2/(int)(407))/(int)(191))))){
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 20");
}
for(int i = 0; i < 7; i++){
 f0[65] = (short)(((f0[79]+f0[58])/(short)(22498))/(short)(19962));
}
switch((var2/(int)(173))){
case 0:
f0[0] = (short)((f0[64]-f0[2])*(f0[101]*f0[69]));
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 33");
 break;
case 2:
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 38");
 break;
case 3:
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 43");
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 49");
 break;
default :
System.out.println("TenKLOC18 - TenKLOCInterface1Method3- LineInMethod: 55");
}
return (double)(double)(0.9174324207760676);

}

public byte TenKLOC18method0(float var0, int var1, int var2){
 TenKLOC18 classObj = new TenKLOC18();
for(int i = 0; i < 6; i++){
 var1 = (int)((var1*(int)(639))+((var2+var1)-(var1+(int)(738))));
}
switch((var1*(int)(260))){
case 0:
var2 = (int)((var1*var2)/(int)(643));
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 9");
 break;
case 2:
var1 = (int)((var1*var2)+(var2/(int)(259)));
 break;
default :
var1 = (int)(187);
}
switch((var1*(int)(51))){
case 0:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 18");
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 24");
 break;
case 2:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 30");
 break;
case 3:
var0 = (float)((var0*(float)(0.47405475))-(((var0%(float)(0.29893392))*(var0+(float)(0.99023664)))/(float)(0.15514529)));
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 38");
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 43");
 break;
case 6:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 49");
 break;
case 7:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 54");
 break;
case 8:
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 58");
 break;
default :
System.out.println("TenKLOC18 - TenKLOC18method0- LineInMethod: 61");
}
return (byte)(byte)(124);

}

public static byte TenKLOC18method1(double var0, String var1, short var2){
 TenKLOC18 classObj = new TenKLOC18();
if(((var2/(short)(2142))<((var2-(short)(15804))*((var2*(short)(19640))/(short)(9842))))){
}
else{
 System.out.println("TenKLOC18 - TenKLOC18method1- LineInMethod: 5");
}
if( ((((var2%(short)(20084))+(var2/(short)(26501)))>=(var2+(short)(6558)))&&((var2+(short)(22454))!=(var2-(short)(31325))))){
if( (((var2+(short)(28301))==((var2*(short)(18914))+(var2*(short)(20111))))&&(((var2-(short)(5373))<=(var2-(short)(25833)))&&((var2/(short)(27735))>((var2/(short)(9662))+(var2*(short)(14749))))))){
if( ((var1+"zdrgrywjojfgnsnconlbxgdaxdchveqxqafqxcbvnuwllweumundjhemtgvxictrqjaqmazyhmnfxbzgwsrjm")!=((var1+"ouxpyptsaxcanin")+(var1+"cuwmdkwjtoiome")))){
System.out.println("TenKLOC18 - TenKLOC18method1- LineInMethod: 15");
}
}
}
if( ((var1+"dtjmcpgnpjkocxvegubnriyenkgbsqocyhjfqjickdajhvmkevhlhhnutkimco")!=(var1+"mvdnwxlssmxmvuranzertekbxwlmzvinemlomofiaxmdngkvoxpj"))){
System.out.println("TenKLOC18 - TenKLOC18method1- LineInMethod: 22");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC18 - TenKLOC18method1- LineInMethod: 26");
}
if( (((var0*(double)(0.10135914344833474))%(double)(0.35667308634966377))<=((((var0+(double)(0.9980789956490205))/(double)(0.14164220176900266))%(double)(0.8927028076201412))+(var0/(double)(0.2720833147198174))))){
f1 = (String)((f1+"eorwb")+(var1+"hmlhqbbfqrhncahwpvkxvedwfncwsbvozwfrssf"));
}
if( ((var1+"kuwamjrkscvicgmfbfpajgwtpnhpjeum")==(var1+"fmorpwodhwzqcyiulhranyowgxepaukggiid"))){
f1 = (String)(f1+"cbkbrkekdlmdiuhzkvplojeqyxnzddokpyqpgpoafhvyjx");
}
return (byte)(byte)(109);

}

public static short TenKLOC18method2(char var0, float var1, float var2){
 TenKLOC18 classObj = new TenKLOC18();
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 3");
}
for(int i = 0; i < 8; i++){
 if( ((var0%'z')!=(var0-'k'))){
if( ((var1%(float)(0.9769449))!=(var1*var2))){
System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 13");
}
}
}
for(int i = 0; i < 9; i++){
 }
if( (((var0%'v')==(var0/'h'))||(((var0+'a')!=((var0+'x')*(var0*'v')))&&((var0-'n')<(var0/'b'))))){
if( ((var0-'j')!=(var0*'m'))){
System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 21");
}
}
for(int i = 0; i < 5; i++){
 if( (((var0-'t')-((var0+'l')+(var0%'f')))==(var0/'o'))){
System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 26");
}
}
if((((((var2%(float)(0.539347))!=(var2/(float)(0.075229645)))&&(((var2+var1)*(var2-(float)(0.7148511)))>(var2/(float)(0.05146563))))||((var2/(float)(0.04851657))<(var1*var2)))||(((var2-var1)>((var2+var1)%(float)(0.5395765)))&&((var2/(float)(0.05064869))!=(var1*var2))))){
System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 35");
}
else{
 System.out.println("TenKLOC18 - TenKLOC18method2- LineInMethod: 38");
}
return (short)(short)(10683);

}

public static int TenKLOC18method3(int var0, float var1, long var2){
 TenKLOC18 classObj = new TenKLOC18();
if(((var0/(int)(97))<=(var0-(int)(743)))){
f1 = (String)("yesxjdnjvkojffgynaamyjrahyycxygtwaowgugodrkgbvenh"+"ncrlftjjxoeul");
}
else{
 var1 = (float)(0.276748);
}
if(((var0/(int)(703))!=(var0*(int)(529)))){
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 10");
}
else{
 System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 15");
}
switch((var0+(int)(423))){
case 0:
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 19");
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 23");
 break;
case 2:
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 27");
 break;
case 3:
f1 = (String)("swtdpuvmwopdjeifenvzlfguaafcwrzjabaersbocjmejeocewntiqtxmsemzctmsdpijkutuzkqchp"+"dtrsrkoxhvhkysrkvflqvrobgftnbzrtj");
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 37");
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOC18method3- LineInMethod: 42");
 break;
case 6:
f1 = (String)(("gfdsrulgfvnbqzharqoydudhkyzrpyqacfqebwlxyjiknvijxywd"+"lwqer")+(f1+"mescowdefgbltqijyhmiqflkbjsdjsdaxlhqexmiyxmavgpqnorcwomwhdkzlrekhecsqdryeymnincrzdtsj"));
 break;
default :
f1 = (String)(("dsavlyoweaialdchifvnkuj"+"pqbozjfehmvilqszawxkhylqrpnodrpfefgeelqobhxmjwkmygrgielhiwodjyfksrlutobhsnbzpzm")+("hnhuxvexuwfnusrkkqtmefzpbuemqptvktuscvystkrywhjaguvluvxqjhjqzlxzmhuddylyacpctlylvzgdligumgv"+"brjybdjvdyngnwdgjshequdhkpfvhegbvbspyzlcqtxdqonmxmwyznylgygxjgtailvuotwgykqkguxkgftwcxgdbncnex"));
}
return (int)var0;

}

public static short TenKLOC18method4(int var0, float var1, char var2){
 TenKLOC18 classObj = new TenKLOC18();
if( ((var1-(float)(0.51055455))>(var1-(float)(0.32055253)))){
var2 = 'r';
}
for(int i = 0; i < 5; i++){
 if( (((var1-(float)(0.9033544))-(var1+(float)(0.5995841)))<=(var1+(float)(0.9372233)))){
if( ((var0+(int)(577))>=(var0*(int)(160)))){
if( ((var0*(int)(408))>(var0*(int)(76)))){
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 11");
}
}
}
}
switch((((var0+(int)(570))-(var0+(int)(320)))-(var0*(int)(226)))){
case 0:
f1 = (String)(("zhgxqzttytclwlqrekqrbsknvbiocicsm"+"itfvywn")+("qljuewdrzedyysmhckxtmjvorulemgovtoxkcstasmhljksahtgfxdskkhqouxsv"+"edsnmnvasftjlaljket"));
 break;
case 1:
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 20");
 break;
case 2:
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 24");
 break;
case 3:
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 27");
 break;
case 4:
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 34");
 break;
case 5:
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 39");
 break;
default :
System.out.println("TenKLOC18 - TenKLOC18method4- LineInMethod: 43");
}
return (short)(short)(30964);

}


public static void main(String args[]){
TenKLOC18 obj = new TenKLOC18();
obj.TenKLOCInterface1Method0((int)(456),new TenKLOC29(),(short)(21183));
obj.TenKLOCInterface1Method1((int)(344),(byte)(116),"navjyyglezyjbtqulbwvhamfodlmpbtawpgrjzthtopnozlsrsly");
obj.TenKLOCInterface1Method2((double)(0.5224133200807279),(byte)(-87),(int)(406));
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.15054691),(int)(269));
obj.TenKLOC18method0((float)(0.87268305),(int)(111),(int)(534));
TenKLOC18method1((double)(0.5496385348610366),"fdldrjjjnqzhioibqocdqbmlfhorarkzskeztaiotfvlxqecxejbcp",(short)(17758));
TenKLOC18method2('o',(float)(0.6486655),(float)(0.13643587));
TenKLOC18method3((int)(531),(float)(0.8229192),(long)(521));
TenKLOC18method4((int)(104),(float)(0.5054322),'i');
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC18 obj = new TenKLOC18();
obj.TenKLOCInterface1Method0(i5,new TenKLOC29(),(short)(8665));
obj.TenKLOCInterface1Method1(i6,(byte)(-128),"ghwgcdyvvkeajqvctrs");
obj.TenKLOCInterface1Method2((double)(0.29102409411298824),(byte)(87),i1);
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.8460982),i5);
obj.TenKLOC18method0((float)(0.69433314),i2,i0);
TenKLOC18method1((double)(0.8832998257909656),"ipqerptqxjxdndsazfhnorcfintabciyaeiqjvgtzidnhfoehjjjcmztttnarbqlxygcsxjvbafphfwrelqvhpltnwqtgjwkdb",(short)(13706));
TenKLOC18method2('u',(float)(0.8430119),(float)(0.16165626));
TenKLOC18method3(i6,(float)(0.62572366),(long)(282));
TenKLOC18method4(i3,(float)(0.40480536),'c');
}

}