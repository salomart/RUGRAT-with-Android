package com.accenture.lab.carfast.test;


public interface TenKLOCInterface3
{
public float TenKLOCInterface3Method0(double var0, byte var1, double var2);
}