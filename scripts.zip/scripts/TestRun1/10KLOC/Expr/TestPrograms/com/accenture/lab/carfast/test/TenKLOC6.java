package com.accenture.lab.carfast.test;


public class TenKLOC6 {
long[] f0= new long[43];
static long f1;
static byte f2;
static char f3;


public float TenKLOC6method0(double var0, int var1, float var2, String var3, TenKLOC7 var4, String var5){
 TenKLOC6 classObj = new TenKLOC6();
if((((var0/(double)(0.8531249699206397))>=(var0-(double)(0.4992858420603977)))&&((((var0+(double)(0.8969984280430443))-((var0-(double)(0.20445227350469575))*(var0+(double)(0.9813947484990826))))>=((var0*(double)(0.19491663473448206))*(var0-(double)(0.8100787982461628))))&&((var0+(double)(0.9526601544274981))>(var0+(double)(0.43318513442296736)))))){
var1 = (int)(284);
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 5");
}
if(((var0+(double)(0.02542083557981334))>=(var0/(double)(0.885552264708024)))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 13");
}
else{
 f0[39] = (long)(((long)(531)%(long)(44))+((long)(669)+(long)(21)));
}
if( ((var0-(double)(0.2776965229868865))!=(var0%(double)(0.09352801657576493)))){
if( ((var1+(int)(262))!=(var1%(int)(703)))){
if( ((var0-(double)(0.6186325067401299))!=(var0-(double)(0.9436442901469888)))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 22");
}
}
}
if((((var1*(int)(669))>(var1+(int)(125)))||((var1-(int)(332))!=(var1*(int)(623))))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 29");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 31");
}
for(int i = 0; i < 8; i++){
 if( ((var1%(int)(438))==(var1-(int)(500)))){
var2 = (float)(var2-(float)(0.6757957));
}
}
if(((var2/(float)(0.16262388))>((var2%(float)(0.34654504))+(var2*(float)(0.86176974))))){
f0[8] = (long)((f0[7]*f0[18])-((long)(647)+(long)(600)));
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 46");
}
if( ((var1+(int)(655))>=(var1%(int)(545)))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 51");
}
if( ((var3+"kixmsisdmcdcpwqkamhgkjohfnwabvhmxqfmdnzjqjhqepwpkluzsmujwelqgntositesgrjtyqpitkrcowsevxoceqy")==(var5+"nximgkruyxwuelqhsbzvidhalnmrcjthfsjekfnmowyvifscqrwjdgskpwdalbqvgrolcwpzkfooqndqfnzvvdqmslfinfak"))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 58");
}
if( (((var3+"picazjutqajmiorewmttmrttmfongmvaxmnetvifuhehhbkiiubdistgtpjbgmnusvqqnjwniusoxwbddnfniha")==((var5+"tfodpczxmmnzrqtmmqpzreayqkkgkummtkrpuiaoewsdem")+(var5+"kq")))&&((var3+var5)!=(var5+var3)))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 62");
}
if((((var5+var3)+(var5+"qarhgampytycjkhsgxlgsutoulrethgckkajyvgzgmdqylwqdukgatiomjkylghoxmzsqkbmrnyapnvtshbeslnsoiqmyrufqsbd"))==(var5+var3))){
System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 70");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method0- LineInMethod: 74");
}
return (float)var2;

}

public double TenKLOC6method1(double var0, TenKLOC10 var1, double var2, TenKLOC0 var3, double var4, int var5){
 TenKLOC6 classObj = new TenKLOC6();
for(int i = 0; i < 5; i++){
 if( ((var0+var2)<((var0-(double)(0.1570356960567042))-((var4/(double)(0.8486610667744592))+(var2-(double)(0.3398426536009065)))))){
if( ((var5*(int)(560))!=((var5*(int)(554))+((var5+(int)(423))*(var5+(int)(387)))))){
if( (((var0%(double)(0.06808817635836528))-(var2%(double)(0.046327068736545796)))!=(var2-var4))){
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 9");
}
}
}
}
switch((var5+(int)(3))){
case 0:
TenKLOC10.TenKLOC10method4(var5,(short)(6131),var0);
 break;
case 1:
var1 = new TenKLOC10();
 break;
case 2:
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 21");
 break;
case 3:
var5 = (int)((((var5-(int)(284))+(var5+(int)(563)))*(var5/(int)(600)))-(((var5+(int)(161))*(var5+(int)(237)))/(int)(481)));
 break;
default :
f0[22] = (long)(((long)(774)*(long)(574))-((long)(27)*(long)(225)));
}
if(((var5-(int)(712))==(var5/(int)(520)))){
f0[20] = (long)(((long)(315)-(long)(594))/(long)(456));
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 33");
}
for(int i = 0; i < 1; i++){
 if( ((var5+(int)(725))!=(var5-(int)(349)))){
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 39");
}
}
if(((var5-(int)(732))<=(var5%(int)(21)))){
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 47");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 48");
}
if( ((var5/(int)(504))!=(var5*(int)(281)))){
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 54");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 60");
}
if(((var2+(double)(0.5187751864031194))>(var2*var0))){
System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 68");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method1- LineInMethod: 70");
}
return (double)var2;

}

public Object TenKLOC6method2(double var0, byte var1, char var2){
 TenKLOC6 classObj = new TenKLOC6();
for(int i = 0; i < 0; i++){
 if( ((var0*(double)(0.6794155498020129))==(var0+(double)(0.5643071032195182)))){
if( ((((var1/(byte)(-91))-(var1*(byte)(77)))>=(var1/(byte)(-22)))||((var1-(byte)(-77))>=((var1*(byte)(-32))-((var1*(byte)(-28))-((var1-(byte)(84))*(var1+(byte)(-18)))))))){
var2 = (char)((var2*'g')+(var2%'a'));
}
}
}
if( ((var2+'k')<(((var2*'o')*(var2+'e'))-((var2*'n')+(var2/'t'))))){
if( (((var1+(byte)(-31))>=(var1-(byte)(16)))||((var1-(byte)(42))==(var1+(byte)(30))))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 12");
}
}
for(int i = 0; i < 7; i++){
 if( ((var2*'c')<=(var2-'d'))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 17");
}
}
for(int i = 0; i < 7; i++){
 if( ((var2+'f')>(var2%'j'))){
var1 = (byte)((var1+(byte)(0))*(var1%(byte)(-42)));
}
}
if( ((var1-(byte)(8))==(var1-(byte)(89)))){
var0 = (double)(0.1965165997729521);
}
if(((var0+(double)(0.7668666692554675))!=((var0+(double)(0.3475007755542264))-(var0+(double)(0.48814703691938655))))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 31");
}
else{
 f0[26] = (long)(((long)(367)%(long)(667))-(((long)(568)*(long)(451))/(long)(670)));
}
if((((var2*'r')-(var2*'b'))>(var2%'b'))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 37");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 42");
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 49");
}
if((((var2-'u')+(var2*'g'))>(var2/'i'))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 54");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 59");
}
if(((var1-(byte)(113))==(var1-(byte)(-85)))){
System.out.println("TenKLOC6 - TenKLOC6method2- LineInMethod: 65");
}
else{
 var1 = (byte)(var1+(byte)(-57));
}
return (Object)null;

}

public String TenKLOC6method3(double var0, short var1, double var2, int var3, String var4){
 TenKLOC6 classObj = new TenKLOC6();
if( (((var1-(short)(3715))-(var1*(short)(11981)))<=((var1+(short)(3554))/(short)(5951)))){
f0[17] = (long)(((long)(200)%(long)(123))-((long)(769)+(long)(296)));
}
switch((var3+(int)(776))){
case 0:
var1 = (short)(((var1%(short)(11830))-(var1*(short)(28759)))+(var1+(short)(25564)));
 break;
case 1:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 9");
 break;
case 2:
var2 = (double)((var2*var0)+(var0-var2));
 break;
case 3:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 19");
 break;
default :
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 23");
}
if(((var1+(short)(7916))>(var1*(short)(2318)))){
var2 = (double)(var2/(double)(0.3055257309825843));
}
else{
 f0[24] = (long)(((long)(76)/(long)(511))+((long)(341)-(long)(118)));
}
if(((var0*var2)<=(((var0*(double)(0.01989329736877754))+((var2+(double)(0.9330961211493722))+(var2/(double)(0.4027318043132746))))+(var0-var2)))){
var3 = (int)(580);
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 37");
}
if((((var4+"ydrfwawbzgdujrmvnenlebzausfckbnymowhxphrbdfidqkgqgephqjbswmd")!=((var4+"gsqwf")+(var4+"lysdubiocyflvumcodwcwoxfekvefmwjjcuvqkqsxkirknrfcumfewaksnuzqrgsf")))||((var4+"ekfhisdlmotnxeclpzmwqsnztkbfbusamgokqsdkuhdfifnnopmbiioletkdcjdhymvpluisuoxjfoncaxieioogrtcaohe")==(var4+"sfkupmqrcuzseeafeaqdisdkrotav")))){
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 44");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 49");
}
if((((var1+(short)(7044))/(short)(22813))>=(var1-(short)(21547)))){
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 54");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 56");
}
if( (((var3%(int)(31))>=((var3+(int)(569))*(var3-(int)(542))))&&((var3*(int)(228))>=(var3+(int)(147))))){
if( ((var4+"uzbeckjbfddqm")==(var4+"qficjldeqqqgwzjbbdwxmhwpjlbdtmowyrvcyhgucdnuetbfnfcksfnxxejjntehaezwohlqigqfdnslehjdjkdygnkviagpwemrc"))){
var3 = (int)((var3-(int)(303))+(var3-(int)(414)));
}
}
switch((var3/(int)(754))){
case 0:
f0[8] = (long)((((long)(304)/(long)(84))%(long)(398))+((long)(388)-(long)(570)));
 break;
case 1:
var3 = (int)((var3-(int)(364))+(var3+(int)(80)));
 break;
case 2:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 70");
 break;
case 3:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 75");
 break;
case 4:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 78");
 break;
case 5:
f0[32] = (long)((((long)(140)*(long)(580))-((long)(39)%(long)(480)))+(f0[11]%(long)(487)));
 break;
case 6:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 88");
 break;
case 7:
System.out.println("TenKLOC6 - TenKLOC6method3- LineInMethod: 94");
 break;
default :
f0[42] = (long)((((((long)(392)%(long)(485))*((long)(446)-(long)(690)))*(((long)(404)*(long)(259))%(long)(461)))-(((long)(358)+(long)(728))%(long)(204)))+(f0[34]+f0[41]));
}
return (String)var4;

}

public static double TenKLOC6method4(byte var0, double var1, byte var2){
 TenKLOC6 classObj = new TenKLOC6();
if( ((var1+(double)(0.7160097309790673))<=(var1/(double)(0.8703333984304693)))){
if( (((var1-(double)(0.6898412793341981))+(var1/(double)(0.5741094607456793)))==(var1*(double)(0.8165704516416311)))){
f1 = (long)(((long)(523)+(long)(202))-((long)(431)-(long)(119)));
}
}
for(int i = 0; i < 3; i++){
 if( ((var1-(double)(0.43455996323476787))>=(var1%(double)(0.7019673857791233)))){
if( ((var2*(byte)(86))!=(((var0-var2)+(var2+var0))%(byte)(-123)))){
f1 = (long)(((long)(512)/(long)(776))%(long)(88));
}
}
}
if( ((((var1%(double)(0.3674667271895449))<=(var1%(double)(0.49382240184525095)))&&((((var1%(double)(0.30383111004312857))-(var1*(double)(0.5532291064233218)))-(var1+(double)(0.7931818076975344)))>=(var1*(double)(0.502228785901959))))&&((var1-(double)(0.3126425698749893))>=(var1*(double)(0.8696664314465448))))){
System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 15");
}
if((((var2+(byte)(59))>=((var2-var0)*(var0-(byte)(49))))&&((f2*(byte)(-14))!=(var2*(byte)(-50))))){
f2 = (byte)((var2+var0)/(byte)(-86));
}
else{
 f2 = (byte)((var0-(byte)(24))*(var0/(byte)(-113)));
}
if( ((var1%(double)(0.3713968252007449))!=((var1+(double)(0.9262671895849345))*(var1+(double)(0.7926105623255246))))){
System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 28");
}
if(((var0*(byte)(16))>=(var2+(byte)(117)))){
var0 = (byte)((var0%(byte)(-102))*(f2+(byte)(-64)));
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 34");
}
if( ((var2*(byte)(-127))>=(var0%(byte)(106)))){
var1 = (double)((var1+(double)(0.9789429230517884))/(double)(0.9063856096503987));
}
if((((var1-(double)(0.4962608665110231))+((var1*(double)(0.9387962100908195))-(var1/(double)(0.09140713050002025))))==(var1/(double)(0.48181329469212353)))){
System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 44");
}
else{
 var1 = (double)(0.9474356501929694);
}
if((((var1+(double)(0.24097150876222373))-(var1*(double)(0.17294003265741542)))<=(var1/(double)(0.1843240019375011)))){
System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 50");
}
else{
 System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 53");
}
for(int i = 0; i < 7; i++){
 f2 = (byte)((f2-(byte)(103))/(byte)(-70));
}
for(int i = 0; i < 7; i++){
 System.out.println("TenKLOC6 - TenKLOC6method4- LineInMethod: 61");
}
if(((var2+(byte)(126))>=(var2+var0))){
var2 = (byte)((var2+var0)+(var0/(byte)(18)));
}
else{
 var0 = (byte)((var2-var0)%(byte)(46));
}
return (double)var1;

}


public static void main(String args[]){
TenKLOC6 obj = new TenKLOC6();
obj.TenKLOC6method0((double)(0.7272012828626565),(int)(649),(float)(0.8780633),"ocfzsjslqvepdsqphymtcozfwhyccgzlefhqqrtzhckspzurivbivtzqwpmkjvhoqicdcnjpehc",new TenKLOC7(),"dcmyvhytaggfvfybnzljsqbjgvtmhjyorqzamcdjskebu");
obj.TenKLOC6method1((double)(0.4283000833945295),new TenKLOC10(),(double)(0.5654526854460181),new TenKLOC0(),(double)(0.7999837466027608),(int)(382));
obj.TenKLOC6method2((double)(0.23395535497155062),(byte)(-72),'u');
obj.TenKLOC6method3((double)(0.2085859954618272),(short)(18107),(double)(0.43344228482507774),(int)(663),"mveptrxawpfubdzhamhftuwfswximqxxeyrrexiudsucvsuaveuicpxcbkaaxsjwgobqvekvdntgqnqkpbutxlb");
TenKLOC6method4((byte)(-119),(double)(0.05525092591659586),(byte)(-104));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC6 obj = new TenKLOC6();
obj.TenKLOC6method0((double)(0.3671584831416155),i2,(float)(0.66260123),"ibrybntoaxjxmazxqrcxfzkypicfmscbrjknhpicfvctqficjjrynzrkttuvh",new TenKLOC7(),"bsccztcjqrhyoctkukxawijkhqqpinvcivqdpckinnnudombuokqatsgmdrrbbntcm");
obj.TenKLOC6method1((double)(0.98257026110306),new TenKLOC10(),(double)(0.4383600829077785),new TenKLOC0(),(double)(0.5949518252196176),i5);
obj.TenKLOC6method2((double)(0.9902599760809669),(byte)(-112),'a');
obj.TenKLOC6method3((double)(0.6371628494429228),(short)(15398),(double)(0.889606626078085),i4,"diaskdnrxtxfruuzffsepilawymttnpwdwkjuwjcxtxajvkoeiwmteyrkhmelraviquvosqejgdd");
TenKLOC6method4((byte)(-43),(double)(0.8572527207034368),(byte)(-74));
}

}