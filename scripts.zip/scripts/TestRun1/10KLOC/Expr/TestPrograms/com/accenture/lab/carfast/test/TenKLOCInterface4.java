package com.accenture.lab.carfast.test;


public interface TenKLOCInterface4
{
public long TenKLOCInterface4Method0(int var0, long var1, short var2, String var3, double var4, double var5);
public double TenKLOCInterface4Method1(int var0, int var1, int var2);
}