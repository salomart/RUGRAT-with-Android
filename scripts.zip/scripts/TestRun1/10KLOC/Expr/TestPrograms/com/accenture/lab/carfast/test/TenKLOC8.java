package com.accenture.lab.carfast.test;


public class TenKLOC8 {
long[] f0= new long[131];
static long f1;
int[] f2= new int[141];


public static byte TenKLOC8method0(byte var0, char var1, long var2, short var3, short var4){
 TenKLOC8 classObj = new TenKLOC8();
if(((var0+(byte)(-124))==(var0*(byte)(116)))){
var4 = (short)(var3*var4);
}
else{
 var3 = (short)((var3*(short)(20756))-(var4+var3));
}
if((((var3*(short)(13090))-((var4-(short)(31043))+(var4+(short)(403))))>(var4-var3))){
f1 = (long)((var2%(long)(544))*(f1*(long)(670)));
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 12");
}
for(int i = 0; i < 1; i++){
 if( ((var1/'c')==(var1+'a'))){
var4 = (short)(26171);
}
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 19");
}
if(((f1%(long)(201))>=(var2/(long)(763)))){
System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 25");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 27");
}
if( ((var1*'l')!=(var1+'w'))){
if( ((var2-(long)(139))!=(f1*(long)(87)))){
if( (((((((var1*'v')-(var1*'n'))/'w')!=(var1-'s'))&&((var1-'p')==((var1-'x')/'w')))||(((var1%'s')-(var1*'q'))>=(var1*'l')))&&(((var1*'j')<=(var1%'i'))&&((var1-'z')<((var1*'a')%'x'))))){
System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 38");
}
}
}
if( ((var4*var3)>(((var4-(short)(32358))-(var3%(short)(7427)))-(var3*(short)(25348))))){
System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 42");
}
for(int i = 0; i < 5; i++){
 f1 = (long)((f1/(long)(455))+((var2+(long)(429))/(long)(192)));
}
if(((var1/'k')!=(var1-'s'))){
System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 51");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 56");
}
if(((((var4%(short)(30089))!=(var4-var3))&&((var4+var3)==(var3%(short)(8292))))&&((((var3+(short)(27697))%(short)(16775))<(var4+(short)(29397)))&&((((var4-(short)(22658))*(var4+var3))>=((var3%(short)(3148))*((var3*(short)(15092))*(var4-(short)(17109)))))&&((var3-var4)<(var3+var4)))))){
var2 = (long)(var2-(long)(323));
}
else{
 var4 = (short)(((var4+(short)(29510))-(var4*var3))*(((var4+var3)-(var3+(short)(17402)))*(var4-(short)(2041))));
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC8 - TenKLOC8method0- LineInMethod: 65");
}
return (byte)var0;

}

public short TenKLOC8method1(TenKLOC3 var0, float var1, char var2){
 TenKLOC8 classObj = new TenKLOC8();
if( (((var1-(float)(0.06643981))>=(var1+(float)(0.94050276)))&&((var1+(float)(0.9830182))==(var1*(float)(0.3828268))))){
if( (((var2*'i')<(var2+'o'))&&((var2/'f')>=((var2-'x')%'s')))){
var2 = 'h';
}
}
if(((var2*'l')>(var2%'e'))){
System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 9");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 12");
}
if(((var1+(float)(0.8807873))==(var1+(float)(0.11680198)))){
System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 17");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 22");
}
if(((var2+'g')!=(var2*'c'))){
f2[124] = (int)(((int)(127)-(int)(595))*((int)(689)+(int)(508)));
}
else{
 f2[97] = (int)((f2[136]*f2[23])-((int)(741)/(int)(329)));
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 35");
}
if(((var1*(float)(0.6305434))<(var1/(float)(0.3910101)))){
var2 = (char)(((var2%'q')*(var2+'h'))-((var2+'y')*((var2%'x')-(var2*'v'))));
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 45");
}
if( ((var2+'y')<((var2-'k')/'i'))){
if( ((var2-'n')>(var2+'l'))){
System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 52");
}
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 58");
}
if( ((var1%(float)(0.48668623))<(var1%(float)(0.32705587)))){
System.out.println("TenKLOC8 - TenKLOC8method1- LineInMethod: 63");
}
return (short)(short)(10971);

}

public char TenKLOC8method2(char var0, float var1, char var2){
 TenKLOC8 classObj = new TenKLOC8();
for(int i = 0; i < 2; i++){
 if( ((var1*(float)(0.48625654))>=((var1%(float)(0.53311473))*(var1+(float)(0.96615446))))){
if( ((var1-(float)(0.7796957))==(var1-(float)(0.61039054)))){
if( ((var0%'r')>=(var2*'n'))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 9");
}
}
}
}
if(((var1%(float)(0.7281543))!=(var1+(float)(0.90723455)))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 15");
}
else{
 }
for(int i = 0; i < 9; i++){
 if( ((var1*(float)(0.8324516))>=(var1-(float)(0.6668193)))){
var0 = (char)((var0-'q')*(var2+var0));
}
}
if((((var2+var0)*((var0+'c')*(var2+'v')))>=(var2+'r'))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 32");
}
for(int i = 0; i < 0; i++){
 if( (((var1+(float)(0.8988603))+(var1%(float)(0.37132293)))<=(var1-(float)(0.29330117)))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 40");
}
}
if( ((var0%'m')<=(var2*'f'))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 46");
}
if(((var0*'p')>(var2*'b'))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 51");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 52");
}
if( ((var0*var2)==((var2+var0)%'b'))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 58");
}
if( (((var1-(float)(0.47166312))<(var1+(float)(0.95388657)))&&(((var1-(float)(0.487494))-(var1*(float)(0.855856)))>=(var1+(float)(0.5886385))))){
var1 = (float)((var1+(float)(0.90608263))-(var1-(float)(0.43829244)));
}
if( ((((var2/'v')+(var0/'b'))==(var0%'f'))||((var0/'s')<=(var0+var2)))){
System.out.println("TenKLOC8 - TenKLOC8method2- LineInMethod: 68");
}
return (char)var0;

}

public static double TenKLOC8method3(long var0, char var1, int var2){
 TenKLOC8 classObj = new TenKLOC8();
for(int i = 0; i < 8; i++){
 if( ((var2+(int)(507))>=(var2-(int)(735)))){
}
}
if( ((var2-(int)(231))<=(var2+(int)(167)))){
if( (((var1-'x')<=(var1*'v'))||(((var1*'p')+(var1*'s'))<=(var1*'p')))){
if( (((var1*'k')-(var1*'n'))<(var1%'d'))){
System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 11");
}
}
}
if((((var1/'g')<=(var1-'w'))&&((((var1+'x')+(var1*'x'))-(var1*'e'))<=(((var1*'n')-((var1+'t')*(((var1+'t')*(var1+'a'))-(var1+'w'))))-(var1*'m'))))){
System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 18");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 22");
}
if( ((var1/'j')!=(var1+'z'))){
System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 29");
}
if(((var1-'x')<((var1-'h')/'g'))){
var1 = (char)((var1*'e')+(var1+'o'));
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 35");
}
if(((var1+'s')>=((((var1-'k')/'m')-(var1-'d'))+((var1*'c')+((var1+'y')%'j'))))){
var1 = (char)((var1*'n')-(var1+'g'));
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 43");
}
if( ((var0*(long)(522))<=(var0+(long)(132)))){
System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 50");
}
switch((var2*(int)(26))){
case 0:
var2 = (int)((var2+(int)(665))*(var2+(int)(610)));
 break;
case 1:
f1 = (long)(((var0-(long)(575))-(var0-(long)(379)))-(f1%(long)(298)));
 break;
case 2:
f1 = (long)((var0-(long)(329))%(long)(567));
 break;
default :
f1 = (long)((var0+(long)(757))-(var0/(long)(302)));
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC8 - TenKLOC8method3- LineInMethod: 67");
}
return (double)(double)(0.6389064819345672);

}

public byte TenKLOC8method4(short var0, char var1, char var2){
 TenKLOC8 classObj = new TenKLOC8();
if(((var1/'p')>(var2/'m'))){
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 5");
}
if( ((((var2-'i')%'q')==((var1-'w')+(var2+var1)))&&((var1%'k')<=(var2*'v')))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 8");
}
for(int i = 0; i < 2; i++){
 var2 = (char)((var1%'u')%'b');
}
if( ((((var2/'r')!=(((var1-'x')-(var2*var1))+((var2-var1)*((var1-var2)+((var2+'r')%'c')))))&&(((var2-var1)/'o')<=(var2*var1)))||((var2/'v')>=(var1+'s')))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 17");
}
if(((var0-(short)(22759))>(var0+(short)(20008)))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 23");
}
else{
 var0 = (short)((var0-(short)(24564))%(short)(10424));
}
if( ((var0+(short)(26789))==(var0*(short)(27273)))){
if( ((((var0+(short)(32666))-((var0*(short)(15679))*(var0-(short)(8378))))<(var0/(short)(26900)))&&((var0+(short)(20553))==((var0+(short)(32706))-(var0/(short)(10230)))))){
f0[104] = (long)(((long)(508)*(long)(257))+((long)(653)*(long)(728)));
}
}
if(((var0*(short)(28507))==(var0-(short)(10334)))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 34");
}
else{
 System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 35");
}
if( (((var1%'v')-(var2%'g'))>=((var2-var1)*(var2-'l')))){
if( (((var0/(short)(27431))%(short)(5904))>((var0*(short)(14083))*((((var0*(short)(28639))%(short)(2817))%(short)(24475))/(short)(11998))))){
var2 = (char)((((var1/'o')+(var1+'u'))+(((var2/'d')*(var1%'r'))-(var1*'v')))+((var2*'z')/'e'));
}
}
if((((var2+'a')>=((var2-var1)*(var2+'w')))&&((var1-'i')!=(var1*var2)))){
var0 = (short)((var0-(short)(30931))-(var0-(short)(12183)));
}
else{
 var1 = (char)(var2*'p');
}
if( ((var0/(short)(30649))<((var0-(short)(31387))-(var0*(short)(5150))))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 53");
}
if( ((var1*'f')<(((var2/'y')+((var1%'n')-((var1-var2)+(var2/'w'))))/'l'))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 59");
}
for(int i = 0; i < 7; i++){
 if( ((((var0%(short)(15038))-((var0*(short)(14140))+(var0-(short)(22486))))==(var0/(short)(8318)))||((var0+(short)(30507))>((var0+(short)(1438))-(var0+(short)(19458)))))){
System.out.println("TenKLOC8 - TenKLOC8method4- LineInMethod: 64");
}
}
return (byte)(byte)(-105);

}


public static void main(String args[]){
TenKLOC8 obj = new TenKLOC8();
TenKLOC8method0((byte)(110),'e',(long)(602),(short)(15785),(short)(19419));
obj.TenKLOC8method1(new TenKLOC3(),(float)(0.91797507),'h');
obj.TenKLOC8method2('t',(float)(0.60969996),'g');
TenKLOC8method3((long)(123),'s',(int)(279));
obj.TenKLOC8method4((short)(15929),'d','h');
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC8 obj = new TenKLOC8();
TenKLOC8method0((byte)(80),'a',(long)(463),(short)(25083),(short)(14583));
obj.TenKLOC8method1(new TenKLOC3(),(float)(0.5364497),'u');
obj.TenKLOC8method2('m',(float)(0.68970555),'p');
TenKLOC8method3((long)(165),'c',i4);
obj.TenKLOC8method4((short)(21146),'x','s');
}

}