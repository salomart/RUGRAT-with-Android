package com.accenture.lab.carfast.test;


public class TenKLOC10 {
static String[] f0= new String[52];
static long f1;
static double[] f2= new double[42];
byte f3;


public static float TenKLOC10method0(TenKLOC29 var0, short var1, double var2){
 TenKLOC10 classObj = new TenKLOC10();
for(int i = 0; i < 4; i++){
 f0[50] = (String)(("ulavugmzdwcmtnspidgdfeykmmpyqnbbcdfdprrvjkbdbhc"+"ukfhnoxlwhkcblgjqxkapbczsrlk")+(("ri"+"rijtlwybpzfxbhidqhragpmwalfvhlxuyqbhjafb")+("nlvhqcvuziaersamolqaecwyyeswkvf"+"hteshwynrxqjpfauhsbgjvqjtibgmawtwgxlzimwgopbbirhvkmnnqsuamdchrlmifephzqafbdxaaap")));
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC10 - TenKLOC10method0- LineInMethod: 6");
}
for(int i = 0; i < 6; i++){
 if( ((var2*(double)(0.2784732235686519))>=((var2*(double)(0.969740267197587))+(var2/(double)(0.12714179501487866))))){
var2 = (double)((var2/(double)(0.05602135442553746))*(var2-(double)(0.7453532883371362)));
}
}
for(int i = 0; i < 7; i++){
 System.out.println("TenKLOC10 - TenKLOC10method0- LineInMethod: 15");
}
if(((var2%(double)(0.9318862142495848))!=(var2*(double)(0.12601610475814184)))){
System.out.println("TenKLOC10 - TenKLOC10method0- LineInMethod: 24");
}
else{
 var1 = (short)(13132);
}
if( (((var1+(short)(12544))<(var1-(short)(23246)))&&(((var1*(short)(32561))>=((var1-(short)(18089))+(var1+(short)(16115))))&&(((var1*(short)(2192))<=(var1*(short)(19103)))&&(((var1*(short)(3543))>(var1*(short)(14342)))&&(((var1%(short)(14946))>=(((var1*(short)(17708))+(var1-(short)(25901)))+(var1*(short)(26353))))&&((var1%(short)(15580))>=(var1-(short)(9447))))))))){
if( ((var2%(double)(0.031138882699086046))<((var2+(double)(0.6682449116360876))+(((var2-(double)(0.9246338209027152))*(var2+(double)(0.9649957676252812)))-(var2-(double)(0.4215058080644085)))))){
if( ((f2[18]+f2[19])==(f2[18]*f2[28]))){
var0 = new TenKLOC29();
}
}
}
if( (((var1+(short)(162))-(var1%(short)(6588)))==(var1-(short)(25885)))){
f2[37] = (double)((var2%(double)(0.16416680762868519))*(var2-(double)(0.33742067016368193)));
}
if( ((var2/(double)(0.18394285843491953))!=(var2+(double)(0.656219216276316)))){
f2[26] = (double)((var2-(double)(0.007510053796009553))-(var2-(double)(0.32624401403730474)));
}
for(int i = 0; i < 7; i++){
 if( (((var1+(short)(28906))<=(var1/(short)(9427)))&&((var1+(short)(11743))==(var1-(short)(23115))))){
var1 = (short)(((var1%(short)(1188))*(var1+(short)(20664)))*(var1*(short)(17980)));
}
}
if( ((((var1*(short)(13917))%(short)(17806))>=(var1*(short)(28603)))||((((var1-(short)(11675))==(var1+(short)(7406)))&&((var1+(short)(5851))==(var1-(short)(25054))))&&(((var1%(short)(3708))/(short)(12121))!=((var1+(short)(26828))*(var1+(short)(482))))))){
var1 = (short)(((var1%(short)(8994))+(var1-(short)(10981)))-(var1*(short)(22039)));
}
if(((var1*(short)(32674))<(var1-(short)(12817)))){
System.out.println("TenKLOC10 - TenKLOC10method0- LineInMethod: 53");
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method0- LineInMethod: 56");
}
if(((var2+(double)(0.5960549738682875))<(var2-(double)(0.6657916871557451)))){
var2 = (double)((var2*(double)(0.9174327922978315))*(f2[12]*f2[35]));
}
else{
 var2 = (double)((var2%(double)(0.9991024207609398))/(double)(0.8944714323661743));
}
for(int i = 0; i < 7; i++){
 if( ((var1-(short)(16736))<(var1*(short)(17162)))){
var0 = new TenKLOC29();
}
}
return (float)(float)(0.6571633);

}

public double TenKLOC10method1(TenKLOC16 var0, String var1, int var2, float var3, short var4, char var5){
 TenKLOC10 classObj = new TenKLOC10();
if( (((var2+(int)(137))<=(var2+(int)(66)))&&((var2-(int)(124))<=(var2+(int)(738))))){
if( ((var2-(int)(161))<((var2-(int)(358))-(var2-(int)(481))))){
if( ((var5-'z')>(var5-'g'))){
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 7");
}
}
}
if((((var3+(float)(0.562988))-((var3-(float)(0.7288454))+(var3/(float)(0.6153495))))!=(var3/(float)(0.4727431)))){
var2 = (int)((var2*(int)(63))%(int)(437));
}
else{
 var1 = "qxzgzmildkllpbbiiaxmqglybapnzca";
}
if(((var5%'y')>=(var5+'h'))){
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 21");
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 26");
}
if(((var3/(float)(0.5258404))>=(var3*(float)(0.4657737)))){
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 34");
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 36");
}
switch(((var2+(int)(682))-(var2*(int)(565)))){
case 0:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 39");
 break;
case 1:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 42");
 break;
case 2:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 47");
 break;
default :
var3 = (float)(((var3*(float)(0.25031632))-(var3+(float)(0.8540981)))*((var3%(float)(0.3073904))-(var3*(float)(0.49905515))));
}
if(((((var5-'x')+(var5-'y'))+(var5/'y'))>=(var5*'b'))){
f3 = (byte)((f3%(byte)(-125))*(((byte)(-28)+(byte)(115))*(((byte)(70)+(byte)(6))+((byte)(118)/(byte)(74)))));
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 57");
}
switch((var2+(int)(466))){
case 0:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 62");
 break;
case 1:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 66");
 break;
case 2:
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 69");
 break;
default :
System.out.println("TenKLOC10 - TenKLOC10method1- LineInMethod: 75");
}
return (double)(double)(0.12729228914092272);

}

public String TenKLOC10method2(int var0, char var1, String var2, int var3){
 TenKLOC10 classObj = new TenKLOC10();
switch((var0*(int)(666))){
case 0:
var1 = 'd';
 break;
case 1:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 5");
 break;
case 2:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 12");
 break;
case 3:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 17");
 break;
default :
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 23");
}
if( (((((var2+"txv")+(var2+"umkprslblewjlsnivklonkybsqmtraulwxquztpnsijeozoiclpcocpomvasrsytdhcdhxdifamwkipsfljrosfdoptlhoyswqm"))+(var2+"uqwoidjolulvkoifbvccjgbsnhdgxcnupcxqlzckucmmpt"))+(var2+"awvlqjllsyiaovhjxtisncyubepjnbpxxywhksmidkp"))!=(var2+"uoojtkayvxzxuwsrcrfnhogqumodmdvogaxysdljmlt"))){
if( ((((var1*'u')+(var1/'t'))%'n')>=(var1-'v'))){
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 28");
}
}
switch((var3-var0)){
case 0:
f3 = (byte)(((byte)(80)-(byte)(43))/(byte)(-47));
 break;
case 1:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 34");
 break;
case 2:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 37");
 break;
case 3:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 43");
 break;
case 4:
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 50");
 break;
default :
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 53");
}
if(((var3-(int)(511))>=((var3-var0)+(var0-(int)(59))))){
System.out.println("TenKLOC10 - TenKLOC10method2- LineInMethod: 60");
}
else{
 f3 = (byte)(((byte)(-54)%(byte)(-38))/(byte)(-80));
}
for(int i = 0; i < 7; i++){
 if( ((var0+var3)<=(var3-var0))){
var1 = (char)(((var1/'g')/'h')*(var1*'d'));
}
}
return (String)var2;

}

public static Object TenKLOC10method3(int var0, short var1, long var2){
 TenKLOC10 classObj = new TenKLOC10();
if( ((var1-(short)(30294))<=(var1%(short)(1275)))){
var0 = (int)(484);
}
switch((var0-(int)(494))){
case 0:
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 5");
 break;
case 1:
f1 = (long)(var2/(long)(363));
 break;
case 2:
var1 = (short)((var1/(short)(6879))-(var1*(short)(15988)));
 break;
default :
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 17");
}
if( (((var0+(int)(681))==((var0%(int)(11))%(int)(586)))&&(((var0+(int)(382))==(var0*(int)(418)))||((var0*(int)(98))<=(var0/(int)(700)))))){
f2[36] = (double)((((double)(0.438982952877647)+(double)(0.9336510850053891))*(((double)(0.9913022094553864)/(double)(0.33001280059026206))*((double)(0.41422282858835247)+(double)(0.2410656767390985))))%(double)(0.3147051003204858));
}
for(int i = 0; i < 1; i++){
 if( ((var0+(int)(93))>((var0*(int)(441))+((((var0+(int)(245))+(var0-(int)(706)))+(var0-(int)(114)))/(int)(215))))){
if( ((var1-(short)(24769))!=(var1-(short)(24602)))){
if( ((var1+(short)(14237))>((var1*(short)(18919))+(var1/(short)(30807))))){
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 31");
}
}
}
}
if( ((var2/(long)(208))<=(var2+(long)(761)))){
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 38");
}
for(int i = 0; i < 1; i++){
 if( (((var0%(int)(76))>=(var0+(int)(225)))&&((var0+(int)(711))<=(var0+(int)(726))))){
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 46");
}
}
if(((var1%(short)(21928))<=(var1/(short)(858)))){
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 55");
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 60");
}
if( ((((var1-(short)(24081))/(short)(12228))==(var1-(short)(20538)))&&(((var1%(short)(31344))>(var1-(short)(13370)))||((((var1+(short)(31861))+((var1*(short)(32291))/(short)(873)))>=(var1*(short)(15829)))&&(((var1%(short)(32723))+(var1*(short)(31625)))>=((var1+(short)(7367))+(var1+(short)(10621)))))))){
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 63");
}
switch((var0*(int)(290))){
case 0:
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 66");
 break;
case 1:
var0 = (int)((var0*(int)(665))-(var0*(int)(458)));
 break;
case 2:
System.out.println("TenKLOC10 - TenKLOC10method3- LineInMethod: 75");
 break;
default :
var0 = (int)(var0%(int)(677));
}
return (Object)null;

}

public static short TenKLOC10method4(int var0, short var1, double var2){
 TenKLOC10 classObj = new TenKLOC10();
if( (((var1%(short)(7340))<=(var1+(short)(20769)))&&((var1/(short)(9048))<=((var1%(short)(31958))-(var1*(short)(16424)))))){
var0 = (int)((var0*(int)(258))/(int)(467));
}
if( ((var0*(int)(574))>(var0*(int)(495)))){
System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 6");
}
for(int i = 0; i < 5; i++){
 }
if( ((var1-(short)(30268))<(var1%(short)(3151)))){
var0 = (int)((var0*(int)(197))*(var0*(int)(406)));
}
if(((var1/(short)(13926))<(var1-(short)(26349)))){
var0 = (int)(var0*(int)(100));
}
else{
 System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 21");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 25");
}
switch((var0+(int)(124))){
case 0:
System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 31");
 break;
case 1:
System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 35");
 break;
case 2:
var0 = (int)(var0*(int)(119));
 break;
default :
f2[14] = (double)((var2%(double)(0.8739590767063816))+(var2*(double)(0.34972909386144946)));
}
for(int i = 0; i < 7; i++){
 f2[15] = (double)((var2-(double)(0.041042535033025684))*(var2*(double)(0.843748751941982)));
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 51");
}
for(int i = 0; i < 9; i++){
 f1 = (long)(((long)(390)/(long)(139))*((long)(185)-(long)(458)));
}
if( ((var0%(int)(531))<(var0%(int)(553)))){
if( ((var2+(double)(0.04069452036849852))>=(var2-(double)(0.36910683176121617)))){
System.out.println("TenKLOC10 - TenKLOC10method4- LineInMethod: 63");
}
}
return (short)var1;

}


public static void main(String args[]){
TenKLOC10 obj = new TenKLOC10();
TenKLOC10method0(new TenKLOC29(),(short)(5146),(double)(0.8564289074244588));
obj.TenKLOC10method1(new TenKLOC16(),"msdzxbzaughawxiibguwpxxlig",(int)(605),(float)(0.067601025),(short)(11726),'b');
obj.TenKLOC10method2((int)(42),'w',"nskjljlyizycrsrrbyucxoxmobczgjztjgclgmmyfggfzmguujtydpyjmrdo",(int)(281));
TenKLOC10method3((int)(771),(short)(6728),(long)(453));
TenKLOC10method4((int)(248),(short)(12550),(double)(0.8717687176074779));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC10 obj = new TenKLOC10();
TenKLOC10method0(new TenKLOC29(),(short)(11588),(double)(0.3163863604784194));
obj.TenKLOC10method1(new TenKLOC16(),"uqsglsuwydfkpakjxipzxorhwuqjn",i4,(float)(0.7657006),(short)(670),'d');
obj.TenKLOC10method2(i0,'z',"gxfncq",i4);
TenKLOC10method3(i1,(short)(12762),(long)(682));
TenKLOC10method4(i6,(short)(30273),(double)(0.656579445174795));
}

}