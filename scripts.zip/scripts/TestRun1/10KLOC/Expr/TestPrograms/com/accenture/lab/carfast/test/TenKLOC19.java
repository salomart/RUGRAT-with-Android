package com.accenture.lab.carfast.test;


public class TenKLOC19 extends TenKLOC1 implements TenKLOCInterface1 {
static long[] f0= new long[70];
static String[] f1= new String[130];


public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2){
 TenKLOC19 classObj = new TenKLOC19();
if(((var2/(short)(1273))<(var2-(short)(30038)))){
var0 = (int)(248);
}
else{
 System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 5");
}
for(int i = 0; i < 1; i++){
 var1 = new TenKLOC29();
}
if(((var2-(short)(6570))<((var2-(short)(9703))+(var2+(short)(3548))))){
var1 = new TenKLOC29();
}
else{
 System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 16");
}
switch((var0*(int)(308))){
case 0:
System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 21");
 break;
case 1:
System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 24");
 break;
case 2:
System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 27");
 break;
case 3:
var2 = (short)(var2-(short)(19922));
 break;
case 4:
var1 = new TenKLOC29();
 break;
case 5:
var2 = (short)((var2+(short)(13602))-(var2*(short)(13505)));
 break;
case 6:
System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 39");
 break;
default :
System.out.println("TenKLOC19 - TenKLOCInterface1Method0- LineInMethod: 45");
}
return (short)var2;

}

public String TenKLOCInterface1Method1(int var0, byte var1, String var2){
 TenKLOC19 classObj = new TenKLOC19();
if( (((var0-(int)(169))!=(var0/(int)(483)))&&((var0%(int)(87))<((var0-(int)(52))/(int)(124))))){
if( ((var0/(int)(766))>(var0/(int)(205)))){
if( ((var1+(byte)(67))!=(var1+(byte)(-128)))){
var2 = (String)(var2+"uiylhpgyqdysceamzypzzwbnswvkokryfurxfenbyhvxkrrxzjfhkcqqvas");
}
}
}
switch((var0*(int)(521))){
case 0:
var1 = (byte)((var1%(byte)(102))-(var1/(byte)(110)));
 break;
case 1:
var0 = (int)(622);
 break;
case 2:
System.out.println("TenKLOC19 - TenKLOCInterface1Method1- LineInMethod: 15");
 break;
case 3:
System.out.println("TenKLOC19 - TenKLOCInterface1Method1- LineInMethod: 22");
 break;
case 4:
var2 = (String)((((var2+"jgsuolagaqdrgonvvzpunghmvfckzhptkha")+(var2+"zbrvygvnxdlljremitaszmzbdaedkppcwfgflzoorhzwboszvwywmehpyaloapzpeyzoyl"))+(var2+"ngxrwhbisfpbuntyqefqpsvceylftjzmpwygqntglmvephvvp"))+(var2+"fbsemfchqiztauuhncdebzduopaldjwkjodlaentydnlpftvbwvfkcvpezimmdmbymzvrgsqcjemvroxfxvezezgzvnewh"));
 break;
case 5:
System.out.println("TenKLOC19 - TenKLOCInterface1Method1- LineInMethod: 30");
 break;
default :
var1 = (byte)(var1-(byte)(44));
}
if( ((var2+"dcncchptefqkmxxjzzgvgkcawcygwuanzhsotlmijuolybdouxv")==(var2+"tfbirzzynwupec"))){
var2 = (String)((var2+"vtorctxbuxanclhhuaxvqhfmjwkioghgbvuyftjduujbdomaeippadwxtbezhnualpvlauglltqoxqduiqumu")+(var2+"eqqexfsxwipktqrxojfiwwstoni"));
}
return (String)var2;

}

public Object TenKLOCInterface1Method2(double var0, byte var1, int var2){
 TenKLOC19 classObj = new TenKLOC19();
switch((var2*(int)(775))){
case 0:
System.out.println("TenKLOC19 - TenKLOCInterface1Method2- LineInMethod: 3");
 break;
case 1:
System.out.println("TenKLOC19 - TenKLOCInterface1Method2- LineInMethod: 7");
 break;
default :
var1 = (byte)(62);
}
if( (((var1+(byte)(33))+(var1-(byte)(59)))<(var1+(byte)(-69)))){
var2 = (int)((var2+(int)(268))+(var2/(int)(194)));
}
if( ((var1-(byte)(-45))!=(var1%(byte)(-54)))){
var2 = (int)((var2+(int)(733))-(var2*(int)(557)));
}
if(((var2+(int)(404))!=(var2-(int)(445)))){
System.out.println("TenKLOC19 - TenKLOCInterface1Method2- LineInMethod: 20");
}
else{
 System.out.println("TenKLOC19 - TenKLOCInterface1Method2- LineInMethod: 24");
}
if( ((var1-(byte)(97))!=(var1-(byte)(-82)))){
if( ((var0-(double)(0.3705010627107962))>(var0+(double)(0.8027452554619725)))){
System.out.println("TenKLOC19 - TenKLOCInterface1Method2- LineInMethod: 33");
}
}
return (Object)null;

}

public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2){
 TenKLOC19 classObj = new TenKLOC19();
for(int i = 0; i < 4; i++){
 var1 = (float)((var1-(float)(0.49513328))%(float)(0.82987374));
}
switch((var2-(int)(110))){
case 0:
var0 = new TenKLOC16();
var1 = var0.TenKLOC24method0("dkkjfhtretkiagvjwxrhuejroabuobjc",var1,"domvlnvfvrvcmmlfswxkvgwcoyqblhmdygnyverwgfbrwosiifkmgjgcr",(short)(13838),(byte)(83));

 break;
case 1:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 9");
 break;
case 2:
var0 = new TenKLOC16();
 break;
default :
var1 = (float)((var1*(float)(0.0018410683))-(var1+(float)(0.04651004)));
}
switch(((var2*(int)(676))%(int)(165))){
case 0:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 19");
 break;
case 1:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 26");
 break;
case 2:
var1 = (float)((var1%(float)(0.95612925))+(var1*(float)(0.38626593)));
 break;
case 3:
var1 = (float)((var1*(float)(0.56226826))%(float)(0.8319513));
 break;
case 4:
var0 = new TenKLOC16();
 break;
case 5:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 38");
 break;
case 6:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 41");
 break;
case 7:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 45");
 break;
case 8:
System.out.println("TenKLOC19 - TenKLOCInterface1Method3- LineInMethod: 52");
 break;
default :
var2 = (int)((var2-(int)(303))%(int)(341));
}
return (double)(double)(0.10338824941626945);

}

public String TenKLOC19method0(byte var0, char var1, double var2, TenKLOC1 var3, int var4, int var5){
 TenKLOC19 classObj = new TenKLOC19();
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 4");
}
switch((var4-(int)(23))){
case 0:
var1 = (char)((var1%'r')/'g');
 break;
case 1:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 13");
 break;
case 2:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 16");
 break;
case 3:
var3 = new TenKLOC19();
 break;
case 4:
var0 = (byte)((var0-(byte)(22))+(var0*(byte)(-116)));
 break;
case 5:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 27");
 break;
case 6:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 32");
 break;
case 7:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 35");
 break;
case 8:
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 38");
 break;
default :
System.out.println("TenKLOC19 - TenKLOC19method0- LineInMethod: 44");
}
return (String)"gqcmavetzxhnwlevnpwcwmpndevebhzwjonxkileqesazhyiqzdnwmzarou";

}

public static String TenKLOC19method1(byte var0, long var1, TenKLOC7 var2){
 TenKLOC19 classObj = new TenKLOC19();
if( ((((var1-(long)(3))*(var1%(long)(707)))<(f0[20]+f0[24]))||(((var1-(long)(400))+((var1-(long)(367))*(var1*(long)(343))))<=(var1+(long)(250))))){
f0[34] = (long)((((var1*(long)(661))+(var1-(long)(137)))*(var1*(long)(475)))+(var1*(long)(502)));
}
for(int i = 0; i < 6; i++){
 if( ((var0*(byte)(40))<=(var0/(byte)(11)))){
if( ((((var1+(long)(712))-(var1%(long)(181)))/(long)(205))==(var1*(long)(412)))){
System.out.println("TenKLOC19 - TenKLOC19method1- LineInMethod: 10");
}
}
}
if( ((var0+(byte)(75))==(var0+(byte)(122)))){
if( ((f0[30]-f0[67])>(var1*(long)(242)))){
System.out.println("TenKLOC19 - TenKLOC19method1- LineInMethod: 19");
}
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC19 - TenKLOC19method1- LineInMethod: 22");
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC19 - TenKLOC19method1- LineInMethod: 25");
}
if(((((var0*(byte)(48))-(((var0+(byte)(102))%(byte)(9))-(var0/(byte)(-18))))+(var0%(byte)(-31)))<=(var0-(byte)(73)))){
f0[36] = (long)(var1-(long)(592));
}
else{
 var2 = new TenKLOC7();
var2.TenKLOC7method0((double)(0.5095219792701945),(int)(566),(double)(0.5895720069200754));
}
if( ((((var1/(long)(728))*((var1-(long)(729))/(long)(582)))+(var1%(long)(725)))<=(var1%(long)(206)))){
System.out.println("TenKLOC19 - TenKLOC19method1- LineInMethod: 36");
}
return (String)"rfbjakxcwzruqnqrcqgwxkctjlpcdsjcuicvpkmfypzkrtgsubewvnkosykqzbdhuzxlarbkercdrfnrkogtyafofrdziifufxl";

}

public byte TenKLOC19method2(byte var0, TenKLOC14 var1, short var2, short var3){
 TenKLOC19 classObj = new TenKLOC19();
if((((var0+(byte)(76))%(byte)(3))>(var0+(byte)(-30)))){
var0 = (byte)((var0-(byte)(119))/(byte)(-80));
}
else{
 var0 = (byte)((var0-(byte)(94))+(var0%(byte)(-32)));
}
if( ((((var3%(short)(8003))+((var2*(short)(8596))*(((var3-var2)*(var2-var3))-(var3+var2))))<(var2*(short)(6696)))&&((var2%(short)(12519))<=(var3*var2)))){
if( ((var2*(short)(26658))<((var2/(short)(31392))%(short)(13019)))){
System.out.println("TenKLOC19 - TenKLOC19method2- LineInMethod: 11");
}
}
for(int i = 0; i < 9; i++){
 var2 = (short)((var3%(short)(4833))*(var3*(short)(4028)));
}
if( (((var0/(byte)(33))+(var0-(byte)(41)))==(var0*(byte)(2)))){
if( ((var0%(byte)(35))!=(var0/(byte)(-24)))){
var1 = new TenKLOC14();
}
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC19 - TenKLOC19method2- LineInMethod: 25");
}
if( ((var0/(byte)(6))>(var0/(byte)(120)))){
System.out.println("TenKLOC19 - TenKLOC19method2- LineInMethod: 30");
}
if( ((var2/(short)(1970))>=((var2-(short)(19652))/(short)(26683)))){
var0 = (byte)((var0%(byte)(105))%(byte)(56));
}
if(((var0-(byte)(-104))<(var0*(byte)(-1)))){
System.out.println("TenKLOC19 - TenKLOC19method2- LineInMethod: 39");
}
else{
 System.out.println("TenKLOC19 - TenKLOC19method2- LineInMethod: 44");
}
return (byte)var0;

}

public static double TenKLOC19method3(TenKLOC22 var0, TenKLOC8 var1, byte var2){
 TenKLOC19 classObj = new TenKLOC19();
for(int i = 0; i < 8; i++){
 if( ((var2%(byte)(-95))>=(var2/(byte)(-31)))){
System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 5");
}
}
if(((var2+(byte)(-128))>=(var2%(byte)(-111)))){
var0 = new TenKLOC22();
var2 = var0.TenKLOC22method4((short)(486),'r',(double)(0.3734631395505038));

}
else{
 System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 12");
}
if( ((var2%(byte)(-49))==(var2/(byte)(18)))){
if( ((((var2-(byte)(-36))==(var2-(byte)(-32)))&&((var2+(byte)(-102))<=(var2*(byte)(-59))))||(((var2/(byte)(-94))!=((var2+(byte)(64))%(byte)(30)))&&((var2+(byte)(4))<(var2-(byte)(-85)))))){
if( ((var2/(byte)(71))>(var2/(byte)(-44)))){
System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 22");
}
}
}
if(((var2*(byte)(32))!=((((var2/(byte)(83))/(byte)(-119))%(byte)(5))/(byte)(94)))){
System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 28");
}
if( (((var2+(byte)(53))<(var2*(byte)(55)))&&((var2-(byte)(36))<=(var2*(byte)(-89))))){
System.out.println("TenKLOC19 - TenKLOC19method3- LineInMethod: 34");
}
return (double)(double)(0.9343940675671085);

}

public static short TenKLOC1method0(double var0, TenKLOC23 var1, float var2){
 TenKLOC19 classObj = new TenKLOC19();
if( ((var0%(double)(0.21148302477364123))>=(var0+(double)(0.1708238021791475)))){
if( ((var2-(float)(0.4812913))!=(var2%(float)(0.0031635761)))){
var0 = (double)((var0+(double)(0.6491992154888727))-((var0*(double)(0.6101524498929073))+((var0-(double)(0.6186698173635952))/(double)(0.5726745761198921))));
}
}
if(((var2*(float)(0.34069496))<(var2-(float)(0.53142077)))){
var0 = TenKLOC23.TenKLOC23method1((int)(31),(byte)(0),null);

}
else{
 System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 11");
}
if( ((var0*(double)(0.9010873745989432))<(var0/(double)(0.6603034712763419)))){
System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 15");
}
for(int i = 0; i < 9; i++){
 f0[41] = (long)((((long)(772)/(long)(512))-((long)(45)+(long)(536)))-((long)(678)%(long)(321)));
}
if(((var2-(float)(0.40080374))!=(var2%(float)(0.5477782)))){
System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 29");
}
if(((((var2+(float)(0.7069178))>=(var2+(float)(0.80627066)))&&((var2-(float)(0.96389383))<((((var2*(float)(0.57547987))-(var2-(float)(0.19185692)))-(var2/(float)(0.67247146)))/(float)(0.024221659))))&&((var2*(float)(0.63826174))>(var2-(float)(0.67374665))))){
System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 37");
}
else{
 System.out.println("TenKLOC19 - TenKLOC1method0- LineInMethod: 41");
}
return (short)(short)(26827);

}


public static void main(String args[]){
TenKLOC19 obj = new TenKLOC19();
obj.TenKLOCInterface1Method0((int)(94),new TenKLOC29(),(short)(9928));
obj.TenKLOCInterface1Method1((int)(708),(byte)(10),"btkuojkemhkvcdezmpohlkflbpyxksyfrykdqhytuldmxicozj");
obj.TenKLOCInterface1Method2((double)(0.9919668205038635),(byte)(64),(int)(774));
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.2558627),(int)(453));
obj.TenKLOC19method0((byte)(76),'w',(double)(0.8703407318416785),new TenKLOC1(),(int)(372),(int)(321));
TenKLOC19method1((byte)(-101),(long)(518),new TenKLOC7());
obj.TenKLOC19method2((byte)(-123),new TenKLOC14(),(short)(3304),(short)(6055));
TenKLOC19method3(new TenKLOC22(),new TenKLOC8(),(byte)(-105));
TenKLOC1method0((double)(0.7718540238175181),new TenKLOC23(),(float)(0.19244546));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC19 obj = new TenKLOC19();
obj.TenKLOCInterface1Method0(i1,new TenKLOC29(),(short)(11301));
obj.TenKLOCInterface1Method1(i5,(byte)(-53),"mulaaoxjclvcbebuchthxoqxomocfapimhdyjektxxzrdvnyzfxcejhztiwequla");
obj.TenKLOCInterface1Method2((double)(0.2867747821104739),(byte)(114),i0);
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.055558205),i2);
obj.TenKLOC19method0((byte)(83),'v',(double)(0.004793769712973739),new TenKLOC1(),i4,i1);
TenKLOC19method1((byte)(37),(long)(660),new TenKLOC7());
obj.TenKLOC19method2((byte)(71),new TenKLOC14(),(short)(29109),(short)(30935));
TenKLOC19method3(new TenKLOC22(),new TenKLOC8(),(byte)(-120));
TenKLOC1method0((double)(0.6856832791529998),new TenKLOC23(),(float)(0.9693552));
}

}