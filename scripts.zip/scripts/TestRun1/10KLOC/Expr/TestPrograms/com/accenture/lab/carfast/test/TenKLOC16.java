package com.accenture.lab.carfast.test;


public class TenKLOC16 extends TenKLOC24 implements TenKLOCInterface2 {
double f0;
int[] f1= new int[54];
static long[] f2= new long[18];
TenKLOC26 f3;
static byte f4;


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC16 classObj = new TenKLOC16();
if((((var0+"rtnozwkjblyxnqilywgzbqsnsufurtoqilbbobprivcytthhfvrbepizswbqdlnhnewuhbeiliorcrunasyvdtecqhq")+(var0+"bjbnhgvdsf"))!=(var0+"lygnphvvejhhzd"))){
var2 = new TenKLOC7();
}
else{
 var1 = (short)((((var1%(short)(13561))+(var1/(short)(30343)))%(short)(14128))-(var1-(short)(24825)));
}
if((((var1+(short)(11850))==((var1/(short)(19812))+(var1/(short)(24206))))&&((var1+(short)(17752))<=(var1*(short)(28214))))){
f0 = (double)(((double)(0.9072541448946698)-(double)(0.7680447563415582))%(double)(0.8628899895288517));
}
else{
 f3 = new TenKLOC26();
var1 = f3.TenKLOC26method3(var0,null,(long)(112));

}
if( ((var1+(short)(15160))<(var1/(short)(12872)))){
if( ((var0+"pnpcohjzotquxk")!=(var0+"wdakfzugqbkfiwczinixgryxmlkbckjtlxdsepvyhtvnajlqfopt"))){
if( ((var0+"yniveirnzocmqfbybqhkgbgrkkepbjbncidqrikgcaay")!=(var0+"xhjtdrrilrqxpzncwilofgzlotpqeundgfcchupxkxddironknjykiqiaeivvabiserwnvnmgnyjjliyl"))){
System.out.println("TenKLOC16 - TenKLOCInterface2Method0- LineInMethod: 19");
}
}
}
if((((var1%(short)(14172))-((var1-(short)(23955))+(var1*(short)(27851))))!=((var1-(short)(2813))*(var1/(short)(12644))))){
System.out.println("TenKLOC16 - TenKLOCInterface2Method0- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC16 - TenKLOCInterface2Method0- LineInMethod: 28");
}
for(int i = 0; i < 5; i++){
 if( ((var0+"ttyshnutuemwshehjxueubjspxororpnlykvrxlkvtxotfoltcilzgdxbtsuezetrdxx")!=(var0+"krnasoxjfohhinuwkzqawkxhydlhrckwpoxpjyluoksasiuwdklixwuyvhtncrwpi"))){
System.out.println("TenKLOC16 - TenKLOCInterface2Method0- LineInMethod: 36");
}
}
if(((var0+"qicepxiplwepsbglijxdxjjeobvymtbbozqawloigzpjkyxeuaztuenuglphcqhsuqpsxrwticwhbtmznvpnwlzcetlfdiogr")!=(var0+"rlpwiznrlkeifngzfsbguidmdbzhncvkycgfdrjcliwsdsmrnlacftpmggmtljldjqfawzigjjbnqywk"))){
System.out.println("TenKLOC16 - TenKLOCInterface2Method0- LineInMethod: 45");
}
else{
 var1 = (short)((var1*(short)(9973))/(short)(30110));
}
if((((var0+"vuwnfpiloriejlzgovkrpbilyrfzhfgngdoxvyrkriafauwaixgyihprbx")+((var0+"xkzjnparafujhvkdkymuenhhmhkchxxlyzoqdtssttcvhoefzybbjwcfkqx")+(var0+"dfwoxoupgjjs")))!=((var0+"mpaepnvwmchyxcpiylfaxbgwmcqtgcqyvvazkvxwyaeopychcvrieuyfwf")+(var0+"mowntuwkbnbvyimgyhdunjhxbfknxaccqdbdrpkrttnbrbdhxqarp")))){
var0 = (String)(((var0+"blzvqcijhvyfqjjhxneyxzcczaonnkkgwhuqikcelurdsigrrzxwhxqtnammpcwxcxprkesviegitwqz")+(var0+"savyzuqqcnovvhplatrisxzaszyshvyakexqhqezvxcpfanptq"))+((var0+"qlcytvxoqohbnjqqwujjaekvcouzmrjdgmel")+(var0+"tcknqprixkmegl")));
}
else{
 f0 = (double)(((f0+(double)(0.5866904830228592))+(f0-(double)(0.34643689671646627)))-((double)(0.7388962829534236)+(double)(0.7015444421158148)));
}
return (short)var1;

}

public static float TenKLOC16method0(String var0, double var1, int var2){
 TenKLOC16 classObj = new TenKLOC16();
if( ((var0+"lkagkvkthmjmkiuziagxlzzimprpsdmmpvqpslplgpuymyznfuekljdibpwjzwdwknawkhof")==(var0+"duuefjuhvksjmunygjaynpudxhnhqcfsopwpqi"))){
if( (((var1%(double)(0.0901336089180994))==((var1-(double)(0.6938258007354197))*(var1+(double)(0.04462987151332165))))&&(((var1+(double)(0.905427611873748))<=(var1-(double)(0.24306680110009415)))&&((var1*(double)(0.4948442516018795))==(var1/(double)(0.10131701301200036)))))){
var0 = TenKLOC26.TenKLOC19method1((byte)(24),(long)(420),null);

}
}
if( ((var2*(int)(664))>((var2-(int)(93))+(var2-(int)(625))))){
if( ((var1+(double)(0.8119903250960149))>=(var1/(double)(0.8029965182089894)))){
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 10");
}
}
switch((var2+(int)(18))){
case 0:
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 13");
 break;
case 1:
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 19");
 break;
case 2:
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 25");
 break;
case 3:
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 32");
 break;
default :
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 35");
}
if(((var0+"tbxubjberzfuluizjmn")!=(((var0+"krbljdkjomfxudxiyxyuhdjqqidvqutatxodwwnnayqfjvwyvrih")+(var0+"ldylbtqhhxojororezuvmvtptiuobllpdtelzgurzymndvkvugdzmujmwybuxbcydcxogamepgstoguvmhwalxvwchddqmo"))+((var0+"winucawdjjltjcufthspgvqtnqgsxcdpaliomwzacmdomibxlblhzfyvekikyxajoidockgzfgfxagrwcwpwiguiceulwv")+(var0+"cbnwonaldaqspifdburbgduvykfkemtjywrqegxm"))))){
f2[10] = (long)(((long)(96)+(long)(1))*((long)(677)*(long)(756)));
}
else{
 f4 = (byte)((byte)(14)-(byte)(-19));
}
if(((((var0+"ggaddrii")+(((var0+"diziavpshapojhbxsmxmxkkvtofdiwgbhkzwqzmjpgrjsnurgpqjhhxvemvebvjbrqemqcrrqbl")+(var0+"xynufqmvqnfjdzuyplllqxjiwrv"))+(var0+"ycqvhquxymqmdnsdalsbakprkyccjvtykaxjzogzhdxbhqjuiqvlzqmkgaaibbeyyhdvlgiaskhncsljyjseexprvvxx")))+((var0+"ltilcgifadkmvzutmeexmswpqghczyzngoqsfromlipvcysxbuwaztebolxpdkii")+(var0+"thhfdhzmmauycwbcwqpdezjpbfaisncihueptbnyrhqvzgwxgvcaawafrnkzggva")))!=(var0+"ijovshhndxdaamptxvbsadcemxufzrvkxwhqkjejayvavpbdhszmlbuh"))){
System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 50");
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method0- LineInMethod: 51");
}
return (float)(float)(0.42162353);

}

public double TenKLOC16method1(String var0, long var1, byte var2, byte var3, float var4, char var5){
 TenKLOC16 classObj = new TenKLOC16();
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 3");
}
if((((var1-(long)(254))+(var1*(long)(742)))>=(var1/(long)(591)))){
TenKLOC26.TenKLOC19method1(var2,var1,null);
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 12");
}
if( ((var5*'b')>=(var5-'l'))){
System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 17");
}
if((((((var0+"bzkrawscighmtvfakszmnonxrvfbvciiiorsapzeqbfxbrnuxuywbghqypbsmfnarlwihboweajclfjubhqaywgvsvvkmptn")+((var0+"opdifhabhbcimyjmnlnzqicjctismy")+(((var0+"avvmivhytrswrjqbubwqrwpwpvfatolgfryxpxrwodxnpdy")+(var0+"nuzkntgposelumrhbsioesiqomawivufwlhrhazdhuxkwixmgenefkgotmzvtbw"))+(var0+"iodzdyehebddltyyevkbezxdpvdqop"))))+(var0+"nacskmyctwqbmgxgqeyoxcwqeyhvvgflvayjgt"))+(var0+"jdfhwekfuvlfjedelsfqnybdlxbsxrsolktetpnfyryyxyeibzinokmkicflcdynmwutczkejmjgphaldpqusv"))==(var0+"quxdlxgeacylainyepggdmzkklkntjxaotuzrxxfjyarvjaoergvhfxonzsorqsjybyvhfnmitchnvkrjpiqkhphgwtciuzb"))){
System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 24");
}
else{
 f3 = new TenKLOC3();
}
if( ((var1*(long)(660))==(var1*(long)(236)))){
if( ((var0+"voykjrckkmpeuufvsjlqrxmhiowqualgimwyupujqjkkxumkzey")==(var0+"tsdsebmhffkumywxdhxoaltuen"))){
if( (((var0+"rjigmsdfkbkphfsaclqtycjdvb")==(var0+"ekqrduksqxfsxtjnkufwigyjiavirchbbraqguwfaflfcvkgkvomwqeeqlboqegqygbo"))||((((var0+"fjcxquxgbxgpaaeokgxwcyquybagjavmgwjhiywyjetwcs")+(var0+"aneregnkbgnnhqknsgyynmbozggflfsxiykbrj"))+(var0+"ghiqjwshborcniw"))!=(var0+"vpyljloqmtxpddoucadcnxrstsfpahwdeqkhpidjtqzkojgfsbsietbjwafoyvymomq")))){
System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 33");
}
}
}
if(((var1*(long)(49))!=(var1/(long)(247)))){
var1 = (long)((((var1-(long)(209))*(((var1*(long)(168))%(long)(1))*(var1-(long)(523))))/(long)(680))+(var1-(long)(277)));
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 42");
}
if(((var5*'l')>=(var5+'x'))){
System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 47");
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method1- LineInMethod: 48");
}
for(int i = 0; i < 4; i++){
 if( ((var5%'n')!=(var5*'c'))){
var1 = (long)((var1+(long)(583))-(var1/(long)(705)));
}
}
return (double)(double)(0.8506839728854665);

}

public static int TenKLOC16method2(long var0, TenKLOC18 var1, float var2){
 TenKLOC16 classObj = new TenKLOC16();
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 3");
}
if(((((var2-(float)(0.20982581))<=((var2+(float)(0.95246226))%(float)(0.28701282)))&&(((var2/(float)(0.17880929))>=((var2*(float)(0.5042654))-(var2+(float)(0.2711748))))&&((var2*(float)(0.38955772))!=(var2%(float)(0.35543078)))))||((var2/(float)(0.034467995))>(var2+(float)(0.28319973))))){
System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 11");
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 12");
}
for(int i = 0; i < 7; i++){
 var1 = new TenKLOC18();
var1.TenKLOCInterface1Method0((int)(550),null,(short)(26771));
}
for(int i = 0; i < 6; i++){
 f4 = (byte)(((byte)(-122)%(byte)(108))*(((byte)(28)*(byte)(5))-((byte)(121)*(byte)(95))));
}
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 21");
}
for(int i = 0; i < 7; i++){
 if( ((((var2-(float)(0.14500743))>(var2+(float)(0.6733189)))&&((var2-(float)(0.1303736))==(var2*(float)(0.47436947))))&&((var2*(float)(0.99995387))!=(var2-(float)(0.49718058))))){
if( ((var0*(long)(372))<=(var0*(long)(188)))){
f4 = (byte)(((byte)(-53)*(byte)(80))*(f4*(byte)(-64)));
}
}
}
if( ((var0*(long)(404))>=(var0-(long)(410)))){
if( ((var2+(float)(0.20461524))==(var2-(float)(0.34101188)))){
System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 34");
}
}
if(((var2+(float)(0.33328652))>=((var2*(float)(0.5915566))*(var2+(float)(0.29880482))))){
System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 42");
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 44");
}
if(((var2%(float)(0.4991876))>(var2+(float)(0.9881613)))){
f4 = (byte)((byte)(116)-(byte)(30));
}
else{
 f2[12] = (long)(var0*(long)(356));
}
if((((var2-(float)(0.39404726))+(var2-(float)(0.015655696)))<=(var2%(float)(0.3246792)))){
f2[8] = (long)((var0-(long)(176))%(long)(500));
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method2- LineInMethod: 58");
}
return (int)(int)(157);

}

public static int TenKLOC16method3(char var0, TenKLOC17 var1, String var2, int var3, TenKLOC9 var4){
 TenKLOC16 classObj = new TenKLOC16();
for(int i = 0; i < 7; i++){
 var2 = (String)(((var2+"gpomckmpbiqngzthtvnqqwowxheoujiplgwgjivuflwxucumjfgwha")+((((var2+"gfcthvjnctwoimsokajqfezdfdtx")+(var2+"fzrrdtrpvsolbspevzrlokntudqimayoajembviafewkmhonfdfgjsptnjmcpflxcoqfaiheyhnjmpotlaqcchkbakymdy"))+(var2+"mlvnthpivgyhqufbgowddfvmiehkozk"))+(var2+"yncndakbxzjkxwczyejixhjqgfpcglmowbidrcjsvitdzicmdzqcwtsmcj")))+((var2+"wkxwlirnkpxtq")+(var2+"uihiurlvtqfbcwvqsqftukzkihqygbigjrxskyqiiklnyz")));
}
if(((var0+'m')==(var0-'j'))){
System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 8");
}
else{
 f4 = (byte)(((byte)(110)/(byte)(-51))-((byte)(-116)%(byte)(121)));
}
if((((var2+"llyutkylfqvgkpjzrluulfefuaiosazxeblfcouzamyhcxpomczolgopfrdpsokhbkonbudgyziqmnyopabyodjd")+(var2+"tdtcvhyrfqakgmnvryytphyqjqlrbedxsnwte"))!=(var2+"cxgccfexdtfjbkmtikchuuzgwksshjtilonaltznrmojgeyngqdfljsipkzphmbf"))){
var3 = (int)(126);
}
else{
 var4 = new TenKLOC9();
}
if( ((var3+(int)(587))<(var3/(int)(590)))){
if( ((var0-'l')>=(var0+'h'))){
if( ((var0%'w')<=(((var0-'t')*(var0+'e'))%'m'))){
System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 23");
}
}
}
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 26");
}
if( (((var3*(int)(288))%(int)(427))==(var3-(int)(558)))){
System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 30");
}
if((((var2+"einghjhpkceuuyoppaprqdqqefshoktbgnoexdur")!=(var2+"bscwwjbbdywamnpvkfdioxzjtpnmvlgk"))||((var2+"ghnelsqfmvbjmojenxhhpnbkefrebtreevktovsfwhemyqvfpnvkr")==(var2+"esqqqnrioamaq")))){
System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 36");
}
else{
 System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 37");
}
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 44");
}
if( ((var2+"scypscromdpalkbjbuyglfdwlqkfhydozbhmhhvf")!=(var2+"wuzqiknamducoyeeocsvcjseaqnoggbtsllpnjdqawrtmshgzifwgjlryafha"))){
System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 50");
}
for(int i = 0; i < 7; i++){
 System.out.println("TenKLOC16 - TenKLOC16method3- LineInMethod: 55");
}
return (int)var3;

}

public float TenKLOC24method0(String var0, float var1, String var2, short var3, byte var4){
 TenKLOC16 classObj = new TenKLOC16();
if(((var3*(short)(4611))!=(var3-(short)(11629)))){
f0 = (double)(((double)(0.053527971689593556)+(double)(0.29504281681923283))-((double)(0.6447719063306752)/(double)(0.13917487249973248)));
}
else{
 TenKLOC26.TenKLOC26method2(var4,'f','j');
}
if( ((((var0+var2)!=(var0+"gyhxdcvokjrmqgmjbjhxgnltopnxflhjgtxvz"))||((var2+"kwdjmoynfbipiegsnegbyiesrnmtyajgmovgnaa")==(var2+"yjmergavxpmvzpvkviettktizbnssslynkywkkewquczms")))||(((var0+"frfcvghpaswupyojoeqjecrxumovaphfagwdaotqewquygbctlpqlwzrdzlguvodvwqi")+(var2+"uahitgadvtkkmyglakpuofjxxigkjfyiyyrlmaoftelfbdvdnnzjzekfrogvsacudvdgtimpmuvqnaxee"))!=(var0+"koiywgctzkyhnrtbqqcaivkdhwtfsvder")))){
if( ((var3-(short)(8240))!=((var3*(short)(15244))*(var3%(short)(32091))))){
if( ((var2+"nxwnvzjdubcrsxcfyhjpzkbfftzikgsjktjxcfumnsjyxtplmxvydrunzcmuontvupibemzsehcplvaloddnysbryjqbs")==(var2+"hnqbdzblqxzzazeoeqkptysjpklcjgokgjuadlqclvoiogczkivpxmxtq"))){
System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 13");
}
}
}
if( ((var4+(byte)(-9))<=((var4+(byte)(-3))%(byte)(123)))){
var1 = (float)((var1*(float)(0.44165146))+((var1-(float)(0.10482925))-(var1*(float)(0.019017458))));
}
for(int i = 0; i < 1; i++){
 if( ((var3+(short)(29175))>((var3/(short)(12149))%(short)(16771)))){
System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 22");
}
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 28");
}
if(((var4*(byte)(-122))>=(var4*(byte)(-124)))){
System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 37");
}
else{
 System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 40");
}
if( ((var0+"kakxtenaoqacjqkcdqzppadkucevmsokrgaig")==(var2+"elpamkdtxirpfmnvnksffxdhewfyzhceydskfxotcsptmfdmmoaqhuuyxowxns"))){
System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 44");
}
if(((var0+var2)==(var2+"itzeszwfyypqhwaywszyskhsnqrgufqxjeqlfdhvmehrmtrfflj"))){
f3 = new TenKLOC3();
}
else{
 System.out.println("TenKLOC16 - TenKLOC24method0- LineInMethod: 54");
}
return (float)var1;

}


public static void main(String args[]){
TenKLOC16 obj = new TenKLOC16();
obj.TenKLOCInterface2Method0("uxvjerjccsythfvkqjitbbiqircauavwpndgzvnhfcnmvylzaresesmtipuxppofvwyg",(short)(9146),new TenKLOC7());
TenKLOC16method0("slptqvuporrhwkhblqfqsavvjreperazqiucshartifbdmtxtl",(double)(0.16560302091644674),(int)(490));
obj.TenKLOC16method1("igtuzkqwbiasxdoismssyzelhfthbancxbrcztlxfopojukauhyuzhdqmbsclyqbkiten",(long)(303),(byte)(57),(byte)(-112),(float)(0.605856),'a');
TenKLOC16method2((long)(240),new TenKLOC18(),(float)(0.6746826));
TenKLOC16method3('d',new TenKLOC17(),"outwdtnvuogavbii",(int)(289),new TenKLOC9());
obj.TenKLOC24method0("gjqazfyfaekcfnwnajyyswmrieydnzcoycilvfdgzwqdhvxoeighfjznsobshjsfjizlodjhz",(float)(0.32694536),"mjfsyripcpneurqirejsdcddfdcsomnozkmmdgytywpvxffcnxfqawuhqtuprfsivspnfakw",(short)(207),(byte)(8));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC16 obj = new TenKLOC16();
obj.TenKLOCInterface2Method0("zcuyrxruoahkmhdkqrivltdguxzvuzhdqcrxgcsdawbfencmbudkpbneiugmcfsxjzuqxxpvtthdoiwodikvxixioittxmycv",(short)(17938),new TenKLOC7());
TenKLOC16method0("frwqayoadtzrvsqvfx",(double)(0.7940261358148786),i5);
obj.TenKLOC16method1("gcmhwrjswqinzxkpgblfc",(long)(269),(byte)(-38),(byte)(2),(float)(0.85373044),'w');
TenKLOC16method2((long)(6),new TenKLOC18(),(float)(0.6518851));
TenKLOC16method3('p',new TenKLOC17(),"mnczzpdzivryiqyvbmdkzapgepnoielfrylrcvukyegokxxqlywbdpvrdotwfvzsrdxsalefpogcdrpzxkqhgautxokkqa",i2,new TenKLOC9());
obj.TenKLOC24method0("uubxamumubuiynhackjqvsgspyqyfhxwfpepbf",(float)(0.75891304),"ccabzgetquozflqpohbgmisutcuzrxqkujmtyarggrmjspdduncyzswmcgizkpuqrfwfyzgphwfpkqpfdcttvvytwftitr",(short)(2118),(byte)(114));
}

}