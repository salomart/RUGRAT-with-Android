package com.accenture.lab.carfast.test;


public interface TenKLOCInterface2
{
public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2);
}