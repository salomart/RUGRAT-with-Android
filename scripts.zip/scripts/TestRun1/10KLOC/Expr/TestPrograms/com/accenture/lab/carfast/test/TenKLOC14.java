package com.accenture.lab.carfast.test;


public class TenKLOC14 {
static long[] f0= new long[34];
static short f1;


public static Object TenKLOC14method0(char var0, float var1, double var2){
 TenKLOC14 classObj = new TenKLOC14();
if(((var1/(float)(0.4986049))==(var1+(float)(0.84878546)))){
var1 = (float)((var1-(float)(0.5829116))%(float)(0.30619848));
}
else{
 var0 = 'y';
}
if(((var1-(float)(0.9009614))>=(var1*(float)(0.030682325)))){
var0 = (char)((var0+'k')-(var0-'e'));
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 11");
}
if( ((var0+'e')<=(var0*'l'))){
if( (((var0/'b')<(var0+'n'))&&((var0+'j')>=(var0%'o')))){
if( ((var2*(double)(0.8127377240296113))<=(var2%(double)(0.054256148517180636)))){
System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 22");
}
}
}
if( ((((var2+(double)(0.9743317579555307))%(double)(0.6518425070963257))*(var2-(double)(0.09142168199568046)))<=(var2*(double)(0.9873820767351768)))){
var1 = (float)((var1*(float)(0.39516342))*(var1%(float)(0.25730133)));
}
for(int i = 0; i < 7; i++){
 if( ((var0*'e')>(var0/'f'))){
System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 34");
}
}
if(((var2/(double)(0.5667541325163387))>(var2/(double)(0.26223864835244537)))){
System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 43");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 45");
}
for(int i = 0; i < 0; i++){
 if( (((((var2-(double)(0.7378116796792585))%(double)(0.010146054991403974))*(var2*(double)(0.5467418272527463)))>(var2-(double)(0.7774089149548455)))&&(((var2%(double)(0.46253766428867094))-(var2*(double)(0.8788256827228613)))>=(var2%(double)(0.858566033784429))))){
System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 50");
}
}
for(int i = 0; i < 0; i++){
 var2 = (double)((var2/(double)(0.07135420545037219))*(var2*(double)(0.4103335419018628)));
}
for(int i = 0; i < 6; i++){
 if( ((var2/(double)(0.9819191422170523))<=(var2%(double)(0.28677156672915183)))){
var2 = (double)((var2/(double)(0.20830190106571755))-(var2*(double)(0.4505333854718353)));
}
}
if(((((var2%(double)(0.31058594109930904))>=(var2*(double)(0.8487941554580186)))&&((((var2%(double)(0.1882752932715659))/(double)(0.43042791907810796))!=(var2*(double)(0.9196351573604381)))&&((var2+(double)(0.9335741649485959))<=(var2-(double)(0.24908676074844227)))))&&((var2/(double)(0.8946169811248355))>((var2/(double)(0.46534680914026794))-(var2*(double)(0.21133299784411308)))))){
System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 64");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method0- LineInMethod: 68");
}
return (Object)null;

}

public double TenKLOC14method1(TenKLOC23 var0, String var1, float var2){
 TenKLOC14 classObj = new TenKLOC14();
if(((var1+"ukylqpvildaky")==((var1+"adjfybdkdfeuvchhphmnkpimeuhfhvwkarexluhpmcrklgyihxoiizkvuyhhrqiwepwafkxomsq")+(((var1+"ibbxwobmhgrtvhisvwsqofaylouzgdfzwajkfdsdqdcytcnqxcnkeybpttwykozrfzmrtkttefsonzxigmvbcoynfhzopjnfugbyy")+(var1+"jaekjyouelwnebjderpzdpgtbpdcjibonsnldtlisawucnjvcftqytulsnqqn"))+(var1+"olkesnshlqkzeuylpobormriuyhxnhcpbziwxsgkgqwjcgoalc"))))){
var0 = new TenKLOC23();
}
else{
 var0 = new TenKLOC23();
}
if( ((var2%(float)(0.98308647))>=(var2-(float)(0.56775177)))){
if( (((var1+"yvvpleekvrlrcn")==(var1+"wipgkesulxhpcfmwyjibxwvmjcgqabwofgqdkghzjxeywrqtkplulfalykitujoeoxraqhwzwdidiynpmibjceehofqrlazhbzqy"))||((var1+"hxxnczlfnfmabjhxibjrxiycciaxelh")==((var1+"cz")+(var1+"gga"))))){
if( ((((var2*(float)(0.4506511))+(var2-(float)(0.58691144)))/(float)(0.4935748))>=(((var2*(float)(0.58571833))-(var2/(float)(0.4363898)))+((var2+(float)(0.9167285))%(float)(0.49534506))))){
var1 = (String)((var1+"jgkcubjkpucyjwafmtrgxdinhwxxqhhkbebjytjojxillssadzxdkeyevthoqtetfwi")+(var1+"nrihcimfisxuuyudsklwjqcizmdgqsmfgzpiuhsuaudrerhffwesvbgakobsmcptkherfmsafkitkaokubrn"));
}
}
}
if(((var2/(float)(0.3054688))!=(var2+(float)(0.45421624)))){
System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 18");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 23");
}
if( ((var1+"nq")!=(var1+"ijtvkexmositllkejagulbiktkjrheyxtogiqepnvqlwjz"))){
var0 = new TenKLOC23();
var0.TenKLOCInterface4Method1((int)(670),(int)(1),(int)(743));
}
if(((var1+"njbmmcgmlzknjctkhvycoheudoqlhzvolzxbtbzffqazhlcdlcraevmfqvcyrrzknhexvartwksyetqr")==(var1+"omprthzisnqfmkzzbfscgqzljkmkdsrppdkaln"))){
var2 = (float)(((var2-(float)(0.310768))+(var2+(float)(0.67348635)))+((var2%(float)(0.40138865))-((var2-(float)(0.5007415))*(var2+(float)(0.03232068)))));
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 34");
}
for(int i = 0; i < 2; i++){
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 40");
}
if( ((var2*(float)(0.69202936))<(((((var2+(float)(0.17461109))*((var2+(float)(0.57307243))*(var2+(float)(0.22128654))))+(((var2*(float)(0.7960475))*(var2-(float)(0.6847483)))%(float)(0.16285455)))*(var2+(float)(0.65493196)))-(var2*(float)(0.4553483))))){
var2 = (float)(((var2-(float)(0.42441064))*(var2+(float)(0.5826184)))-((var2%(float)(0.5673036))-(var2*(float)(0.5318682))));
}
if( ((((var1+"vsbczeehakcuucmjqoqojphnhmttzqlpoujxqcjixaidvigfperziywtzrfsyavrrxemuipsrum")+((var1+"zsojdiisazpjnrzowzhfpefuibboimsmstnpqkrcubgjapab")+(var1+"dqavrhzwjreghungthuehfukkktdkgn")))!=(var1+"quaczgkpdswngrrwzhimsdcpvgluvbktyjodbkgwkwnbdpwjbailstitkczjgtzhpixbllesvzacezqyoihxausjhuqolecfs"))&&(((var1+"vckffjwbqtchzfvatnygdgjehotwggzikzkcpnueszcimfnlmkpyrqhyouwuppkmcwgutyqhswdmmockexi")==(var1+"cylknmnzyfxtovibjschjfekdwqfvhkpzsknxeeomvmbhkiuzmrrp"))||((var1+"hdptqdkvmqewcizvqjgjjifyflsyyaaxdawevgcgdlsqkauroupvgclclryqbttfevfbcyo")!=(var1+"rjzkjfngrjaeh"))))){
var2 = (float)((((var2*(float)(0.41207302))+(var2+(float)(0.9199132)))*((var2-(float)(0.94800603))-(var2%(float)(0.42888576))))-(var2%(float)(0.27695936)));
}
if( ((var1+"btqcvbmvovbxgxjlxftgsolvckihvpnbzuirbxrvziyelnlpaxmeygmcipinamodwejvqk")!=(var1+"ucfpgehpwlzirecdbsgbntwifyowvwqfuwlfd"))){
var2 = (float)((((var2*(float)(0.42919642))*((var2+(float)(0.815747))%(float)(0.33643615)))*(var2-(float)(0.69673586)))*((var2+(float)(0.14267886))-(var2+(float)(0.123515606))));
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 53");
}
if( (((var1+"gcfgvrhyrqwdtpxjkhmkanklmzloojsmppsqejnfeghgudibpzkvieyhnzsooxnzbinfvglrpbo")==(var1+"tcpkmlmjshwfujcuxejpquzkygeaakumlxhqozsoiwp"))&&((((var1+"etxsxxutycafussiyvoasluanghkgprundakysglvyiattukunbzdswzjdjxupfxlninzlrxwvz")+(var1+"gabkepgamelybgfagjkgkrlnviwynr"))+(var1+"yelarhyrotdxujfkeigbrtpquqjsxxnuojjwfhazrwdoniykpiwieytwotgy"))!=(var1+"fjaodanwannzfwgxumwltbhkkyanayhulskywohceipwwcvynzujzgbcyguvgwgmnfxkjzficpjrjrifqybgfsfjoxfywpzrsb")))){
var2 = (float)((var2+(float)(0.019830346))+(var2-(float)(0.34483856)));
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 59");
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 64");
}
if(((var2*(float)(0.3939395))<=((var2+(float)(0.91880006))%(float)(0.5709954)))){
var2 = (float)((var2-(float)(0.66377634))-(var2/(float)(0.034205914)));
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method1- LineInMethod: 71");
}
return (double)(double)(0.3467266476385302);

}

public String TenKLOC14method2(int var0, char var1, double var2){
 TenKLOC14 classObj = new TenKLOC14();
if( ((var2*(double)(0.04003545804998432))!=(var2+(double)(0.5957120434828574)))){
var0 = (int)((var0*(int)(579))%(int)(266));
}
if( ((var0*(int)(772))<=(var0/(int)(746)))){
if( ((var0+(int)(23))<=((var0-(int)(548))-(var0*(int)(335))))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 8");
}
}
if( ((var0%(int)(250))==(var0+(int)(395)))){
if( ((var0-(int)(33))!=(var0/(int)(602)))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 17");
}
}
if(((((var1*'v')+(var1%'a'))!=(var1-'h'))||(((var1/'a')<(var1/'z'))&&(((var1+'y')*(var1-'r'))!=(var1%'g'))))){
var1 = (char)((((var1+'z')%'l')-(var1-'f'))-(var1+'h'));
}
else{
 }
if( ((var1+'f')>=((var1+'l')+(var1/'c')))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 29");
}
for(int i = 0; i < 9; i++){
 if( ((var0*(int)(456))<(var0-(int)(87)))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 36");
}
}
if((((var1/'f')+(var1*'y'))!=(var1-'u'))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 41");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 45");
}
if( ((var0-(int)(230))<=(var0-(int)(747)))){
var2 = (double)(var2*(double)(0.41600309896795784));
}
if( ((var0+(int)(133))>=(var0-(int)(454)))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 52");
}
for(int i = 0; i < 5; i++){
 if( ((var1*'e')>(((var1%'n')-(((((var1%'z')*(var1+'t'))+(var1-'y'))%'h')-(var1+'r')))-(var1+'s')))){
var1 = (char)(var1-'p');
}
}
if( ((var2+(double)(0.9298341012787223))>=(var2+(double)(0.6506986699948594)))){
var2 = (double)((var2-(double)(0.8258373142029295))+(var2/(double)(0.14367903608010513)));
}
if(((((var1+'p')-(var1+'y'))%'n')<=(var1-'r'))){
System.out.println("TenKLOC14 - TenKLOC14method2- LineInMethod: 65");
}
else{
 var1 = (char)((var1-'s')/'y');
}
return (String)"gblzqtsdxdwaswsqmrrmvtouwuietdcwupikmitztxmpoonlbzxvikcbscexwpaxsrmxhodjhfrnhtcrrshrmashzkg";

}

public int TenKLOC14method3(float var0, byte var1, double var2, double var3, double var4){
 TenKLOC14 classObj = new TenKLOC14();
if(((var3*var4)<(var4-var3))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 5");
}
else{
 var3 = (double)(var3/(double)(0.17377400637824425));
}
for(int i = 0; i < 4; i++){
 }
if( (((var0+(float)(0.9501576))*((var0+(float)(0.6409228))*((var0+(float)(0.7466359))+(var0%(float)(0.36905414)))))<(var0*(float)(0.8504608)))){
if( (((var4*var2)+(var4%(double)(0.5059992012893141)))!=(var3%(double)(0.3247761701883273)))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 15");
}
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 18");
}
if( ((var0-(float)(0.5827597))<=((var0/(float)(0.19129282))*(var0-(float)(0.19018215))))){
var1 = (byte)((var1-(byte)(-26))-(((var1+(byte)(-86))*(var1*(byte)(42)))+(var1/(byte)(98))));
}
for(int i = 0; i < 8; i++){
 if( (((var1-(byte)(76))==(var1/(byte)(54)))&&((((var1/(byte)(-20))-(((var1-(byte)(8))*(var1+(byte)(93)))+(var1%(byte)(93))))*(var1-(byte)(-36)))>=(var1%(byte)(-102))))){
if( (((var2*var3)+(double)(0.9065922659624203))>=((var3%(double)(0.41676509908935444))-(var2*var3)))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 29");
}
}
}
if(((var4%(double)(0.11077985540698021))>(var2*(double)(0.8160572702652581)))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 38");
}
else{
 var0 = (float)((var0*(float)(0.8735328))+(var0-(float)(0.61527336)));
}
if((((var0/(float)(0.31828624))<=(var0%(float)(0.61896724)))&&(((var0+(float)(0.077899516))*(var0-(float)(0.729249)))<(var0/(float)(0.17331433))))){
var2 = (double)(((var2+var4)-(double)(0.4718568588824824))*(var4+(double)(0.04410598276630817)));
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 47");
}
if(((var1*(byte)(37))==(var1%(byte)(-65)))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 53");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 56");
}
for(int i = 0; i < 9; i++){
 if( ((var2%(double)(0.7715603190953487))<(var4/(double)(0.50756413280832)))){
System.out.println("TenKLOC14 - TenKLOC14method3- LineInMethod: 63");
}
}
return (int)(int)(333);

}

public static float TenKLOC14method4(long var0, String var1, String var2, long var3){
 TenKLOC14 classObj = new TenKLOC14();
if( ((var0-(long)(100))==((var3+var0)%(long)(219)))){
if( ((var1+"bajspudneojyqzzvlq")==(var1+"bnplldkbvjrywhwhtaqudwgpisrzderymyhxj"))){
if( (((var0-var3)+(var0/(long)(726)))<(var3-(long)(671)))){
f1 = (short)((((short)(4118)*(short)(3683))%(short)(11524))+((short)(24120)*(short)(28981)));
}
}
}
if( ((var0%(long)(56))>=(var0*var3))){
f1 = (short)(((((short)(10989)*(short)(26775))*((short)(30896)/(short)(1416)))%(short)(10008))-((short)(23314)+(short)(24529)));
}
if(((var2+"ryhmrpzkhtcjqsbgekbtgrpsmgbqaqieakucqwoezzwwzfmiceqpfdhkekxrhyhzrrlkqyhollsao")==(var2+"ydunofwhsnpyerfpeofjdtbwlpuhdbampblssnwmrhfnscukztl"))){
var3 = (long)(78);
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 15");
}
for(int i = 0; i < 3; i++){
 if( (((var0-(long)(303))+(var3*(long)(639)))==(f0[6]*f0[28]))){
System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 24");
}
}
if( ((f0[29]/(long)(101))!=(var0*var3))){
f1 = (short)(((short)(18743)-(short)(25072))/(short)(6746));
}
if( ((var0+(long)(467))<(((var3-var0)*(var3+(long)(46)))*(((var3+(long)(707))-(var3/(long)(226)))-((var0*var3)-(var3+(long)(728))))))){
System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 31");
}
if( ((var2+"vmatykvwsplwjeygxovweekkoawzwjszhpglxxmgaukaskljshqresicfowty")==(var2+var1))){
System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 34");
}
if( ((var0-(long)(395))>((var3/(long)(357))/(long)(203)))){
f0[13] = (long)(f0[13]+f0[19]);
}
if(((var2+var1)!=(((var1+"skeawemehegxnfbtghad")+((var2+var1)+((var1+var2)+(var2+"melqdfqdmwseuktwiyxtvhufyandhdyxvxtqbirqovwpgxfjbu"))))+(var2+var1)))){
System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 46");
}
else{
 var3 = (long)(var0/(long)(621));
}
for(int i = 0; i < 3; i++){
 var3 = (long)(var3+var0);
}
if(((var3-(long)(519))<=(var0%(long)(431)))){
System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 59");
}
else{
 System.out.println("TenKLOC14 - TenKLOC14method4- LineInMethod: 63");
}
return (float)(float)(0.64524513);

}


public static void main(String args[]){
TenKLOC14 obj = new TenKLOC14();
TenKLOC14method0('d',(float)(0.94112206),(double)(0.6140284987814999));
obj.TenKLOC14method1(new TenKLOC23(),"oqakyulexuudevttwsbidiegglosdctrepqtognuyfomzqvwhchsvktnktcedrvisecmravgx",(float)(0.72868544));
obj.TenKLOC14method2((int)(642),'h',(double)(0.7498985465082866));
obj.TenKLOC14method3((float)(0.72596604),(byte)(-36),(double)(0.7763646549710975),(double)(0.6495210558343962),(double)(0.9874218465626582));
TenKLOC14method4((long)(727),"nejvoeffxwqqiirdlklkpehfxxrsakycupngvrxa","uxsiwxgtjtqdclawauxyjmpmallmjbbdyhzfpjtopbvvtmycmlascdcddixnshown",(long)(306));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC14 obj = new TenKLOC14();
TenKLOC14method0('v',(float)(0.46817195),(double)(0.9162613903533467));
obj.TenKLOC14method1(new TenKLOC23(),"ycgsjgnmcygruosdupycxfzi",(float)(0.06047225));
obj.TenKLOC14method2(i2,'x',(double)(0.5499879269014114));
obj.TenKLOC14method3((float)(0.6655323),(byte)(-113),(double)(0.997348684226963),(double)(0.866832247331019),(double)(0.2057184524546969));
TenKLOC14method4((long)(406),"vnliooxnljtijgzcbgarlaqzvqtjcbtujxzrkojeuevxjwdponexkbffoilgwhfm","sxdlgjjcaoadjorywdylcjmwyxqyajozdizhefmwstintorwnckcitgdmgkifvjyxoceqeawustglnatmwwqpyfckllnrnadig",(long)(363));
}

}