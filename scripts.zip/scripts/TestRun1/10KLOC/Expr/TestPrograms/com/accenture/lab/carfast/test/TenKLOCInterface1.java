package com.accenture.lab.carfast.test;


public interface TenKLOCInterface1
{
public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2);
public String TenKLOCInterface1Method1(int var0, byte var1, String var2);
public Object TenKLOCInterface1Method2(double var0, byte var1, int var2);
public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2);
}