package com.accenture.lab.carfast.test;


public class TenKLOC9 extends TenKLOC16 implements TenKLOCInterface2 {
static short f0;
static short[] f1= new short[159];
long[] f2= new long[17];
float f3;
TenKLOC2[] f4= new TenKLOC2[167];
short[] f5= new short[66];


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC9 classObj = new TenKLOC9();
if( ((((var0+"ycosryfsyranxrqeujeayzbvmxsblkgecvgxbonnqubaawysunhbhtvcymqiyyp")+(var0+"maetzhercysqrlrwyctujtdtamdwamikgarq"))+(var0+"qtfsiyaohkjnkqutrghqcdztkraeyytzwlsrckxfckojgxfmhijxzmlpugiglbpzggqbilbjuovhkxxqnpszadsccpi"))!=(var0+"cumzzeadmwgvtjugiawoifyrprjaogwjetnfaqksalwzlnjlxjvrqlxminifmxgcvambfppzbqhvcxnexjnbknfzzlgdzrulrljk"))){
if( (((var1*(short)(30740))%(short)(8895))<=(var1*(short)(8650)))){
var2 = new TenKLOC7();
}
}
if((((var0+"xbimsnmspawcyaswcnetpywmwxdlgcghcwdfiqimyynhudbpjizlitcxee")!=(var0+"ieuredvprzidcvwvqhebddhrdqazpzlceqi"))||((var0+"lgtrfgx")==((var0+"vyeyuzpqlclsqnicvoauhfjpgnyptgrmajhykxenyijzsbcyqijbbsjopfgkocccuqbfulhkihylwfbdnvhniembheqton")+(var0+"nulfprmirtheivkuyeinmozrtwcrkvmzpvrztggzufwoycjdbyqiopbbbgtblreimqccietvxknoupoahdlcqqqwhxodihoobjsfh"))))){
f4[28] = new TenKLOC2();
var1 = f4[28].TenKLOCInterface2Method0(var0,var1,var2);

}
else{
 System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 11");
}
if((((((var1/(short)(4323))<(var1-(short)(12845)))&&((((f5[54]+f5[51])+(f5[45]/(short)(15242)))-((f5[62]*f5[54])+(f5[16]%(short)(18756))))>(var1*(short)(28744))))&&((var1+(short)(18482))==(f5[16]-f5[55])))||((var1*(short)(16746))<(var1*(short)(21560))))){
System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 19");
}
else{
 System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 21");
}
if( ((var0+"wrumkdraeukdrfmqyufzbiafhfhzdnqpdslskdwnzghrnfpvdlvp")==(var0+"petetbmyjvysvmafnhfxjqmaeor"))){
if( (((var0+"ickvtoclruhqjcimuaxtbwflewhxnvzbunxfzoqcuwgazrzlsmpbwzquojrglbqfdupklmquofc")==(var0+"agoftjhfzrwiiwffsjbprgaqtqnmshbnhrjukxhmipgdrxbvjcvyquhyadcvifjbptqodrjwqbqokoigbfll"))||(((var0+"wcdmzrynhpdpaxsybvgwcrmehwdklmvykenbcpswgsioggjsnngggklvezuutcuvyceoggstuyhgpjcoxpkpjfgvbecqkr")+(((var0+"jmcjmwxtgzvwkxgevvzjwddlzflnkgheelliqsjsiwmgpudbollwhacgezhknqcarneciptttgtdcmvmmjxoigncrgwudb")+((var0+"jvtuoldzegugthcwdjhmzftxienlhctr")+((var0+"vspimytuubqwymjvjnqzizdkkioebvtgjmzaygbpcvtfyejelxihmqsye")+(var0+"ovzjeumevswysatlfbnqhxglzlzinrzhhhbtqlnwllqpneuvwsyantjcebuajobsvkkdxiujwtwhtodzlqqyaspcpu"))))+((var0+"tjspneilnzuwhwtvhhunygaryuoscgqdnkdpqyrsutypdrivypkszncfboznjmoyfbftlupd")+(var0+"xryyuowvjtexowgaritugrbwyrqwvshzjjfpcxlrlkrtfiaxyxurrvsqzuorwligyxiczoowk"))))==((((((var0+"jxjtjyfnmefyqwyjoszayplfhxoigtbaiedpodcawhcahkrmrjluwhruufzfrvhcuovgkhivjlx")+(var0+"nlybllflnkguxmuhdqfcufuwjxperaacltmaeopfqkjfgpilasbadenkkefqofdeznvgiwlvj"))+(var0+"uftfgkemwmurezhnyrajtrebcnjsrcxpelthsffrsqmvhcca"))+(var0+"gcdgbtvoguuawrovglbhzvgnpkiqfdiftdizdwqylmwnssy"))+(var0+"fkhagensdltoqtmwvgfoomwbehatgflro"))+(var0+"ostfwkenzgrlbrdcoznihvwnymybnxaukrulfbt"))))){
f4[38] = new TenKLOC2();
}
}
for(int i = 0; i < 8; i++){
 if( ((var0+"xdhmizsavfijrevkhbreaitzwzlkfbhfdqkqzzuilcwusscrrrgzucmlnxbe")!=(((var0+"pipqgqckehqmiywyhimwn")+(var0+"uhephoiwoneheyhtphhomxsakuumdbbheglmtiafjagdufrxxtgjkmidrpaaxawjgfgowypbukyolikohswjgwnxgar"))+(var0+"mtvoyprfehcqpioozgwxhsnjlllhqbibtvtjfzwlfgmfrjigllkgbqrdupmnkgasmgrjyxvxindhqet")))){
var2 = new TenKLOC7();
}
}
for(int i = 0; i < 0; i++){
 f2[16] = (long)((f2[7]+f2[16])*(((long)(523)+(long)(600))%(long)(490)));
}
if((((var1%(short)(3144))*(var1+(short)(4083)))<=(var1-(short)(29791)))){
f2[8] = (long)(((long)(465)-(long)(702))*((long)(240)*(long)(464)));
}
else{
 System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 40");
}
if( ((var0+"hcydtmkprkldnjliklpzhwbdgfodv")!=(var0+"yeefwebwdfrwydxzyttqsvntqamejgtlfnapkrbszbqsjkrcvdhceacewiruxrcyreamaaxrifimyclflqicxmsfkbr"))){
System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 47");
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 54");
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC9 - TenKLOCInterface2Method0- LineInMethod: 57");
}
return (short)var1;

}

public static double TenKLOC9method0(String var0, String var1, int var2){
 TenKLOC9 classObj = new TenKLOC9();
switch((var2-(int)(77))){
case 0:
f1[80] = (short)(((short)(5089)%(short)(327))%(short)(13348));
 break;
case 1:
f0 = (short)((((short)(4980)%(short)(32678))-(((short)(11467)-(short)(6580))*((short)(17902)+(short)(18727))))-(f1[115]/(short)(11950)));
 break;
case 2:
var2 = (int)((var2%(int)(233))*(var2+(int)(218)));
 break;
case 3:
System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 12");
 break;
case 4:
System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 19");
 break;
case 5:
f0 = (short)(((short)(15158)+(short)(19825))-(f1[93]+f1[38]));
 break;
default :
var1 = "sczaljjvllhrwertaloxfgvocytfhdbwbkkqwcyydfvbnxp";
}
if( (((var2+(int)(259))+(var2-(int)(115)))<(var2/(int)(403)))){
f1[108] = (short)(((short)(30226)-(short)(15684))*((f1[90]-f0)%(short)(16538)));
}
if(((var2*(int)(300))<=(var2*(int)(265)))){
var2 = (int)((var2+(int)(481))*(var2%(int)(75)));
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 33");
}
if(((var1+"eybqzyuesfcnygxsmrlihpmbcfnvsxrfakmekovbwjch")==(var1+var0))){
var2 = (int)((var2-(int)(322))-((var2-(int)(345))%(int)(404)));
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 39");
}
if(((var1+"gyefprfpwpbzefxrhlfdypbr")==(var1+"yikwebrqmznquo"))){
f1[134] = (short)((((short)(8908)+(short)(7138))%(short)(14762))-(f1[36]+f0));
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 47");
}
if( ((var2*(int)(251))!=(var2+(int)(320)))){
if( ((((var0+var1)+(var1+"qsdswhupambp"))+((var1+var0)+(var1+"fqsltfcozxctqchhvlamxmhppffumkdxxakpmhasf")))!=(var0+var1))){
if( ((var1+var0)!=(var0+"rxupgoavxcsemekfeqnswbkswfipsyjtvdjovzffpplnhmglvguygicy"))){
System.out.println("TenKLOC9 - TenKLOC9method0- LineInMethod: 58");
}
}
}
return (double)(double)(0.0938672201681281);

}

public String TenKLOC9method1(char var0, char var1, long var2){
 TenKLOC9 classObj = new TenKLOC9();
for(int i = 0; i < 2; i++){
 f4[109] = new TenKLOC2();
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 7");
}
if( (((var1+'q')+((var1/'n')/'s'))==(var1+var0))){
if( ((((f2[3]-f2[2])-(f2[11]*f2[12]))==((var2-(long)(1))-(((var2*(long)(195))-((var2%(long)(654))*((var2/(long)(524))+(((var2/(long)(92))+(var2+(long)(67)))+(var2/(long)(497))))))%(long)(380))))||((((var2+(long)(424))-(var2*(long)(624)))+(var2-(long)(680)))!=(var2*(long)(169))))){
System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 13");
}
}
if(((var0-'d')<(var1+'t'))){
System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 19");
}
else{
 f2[0] = (long)((var2-(long)(290))*((var2*(long)(232))*(var2/(long)(553))));
}
if((((var1*var0)*(var1-'y'))!=((var1/'f')/'u'))){
System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 28");
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 33");
}
if((((var0-var1)<(var1-'s'))||((var1*'s')<=(var1*var0)))){
f2[10] = (long)((var2/(long)(431))-(f2[2]+f2[11]));
}
else{
 f2[10] = (long)(((var2*(long)(101))%(long)(37))-((var2-(long)(650))*(var2+(long)(764))));
}
if( (((var1+'m')!=(var0+var1))||(((var1+'l')-(var1+var0))==(var0*var1)))){
if( (((var1*'r')*(var1*var0))>=(var0*'y'))){
System.out.println("TenKLOC9 - TenKLOC9method1- LineInMethod: 44");
}
}
if( ((var2/(long)(400))<=(var2-(long)(563)))){
f4[120] = new TenKLOC2();
}
if( ((f2[7]/(long)(561))>=(var2*(long)(402)))){
f3 = (float)(((float)(0.82550776)%(float)(0.575669))+((float)(0.83187515)*(float)(0.82202476)));
}
if( ((var2*(long)(44))==((f2[1]%(long)(3))*(f2[1]+(long)(82))))){
f2[12] = (long)((var2*(long)(594))/(long)(310));
}
if( (((var1+'q')<=(var0/'q'))&&(((var0+var1)+(var0*var1))<=(var1/'p')))){
f5[29] = (short)(f5[57]*f5[39]);
}
return (String)"gzerfrbxrtvepjeuvtfgfnpdqcbkgtyqcupeghknkrvxlwdexz";

}

public Object TenKLOC9method2(String var0, double var1, String var2, char var3, char var4, String var5){
 TenKLOC9 classObj = new TenKLOC9();
if( ((var1*(double)(0.6921461497598779))<=(var1/(double)(0.37646509868708966)))){
f3 = (float)((f3/(float)(0.018454492))*((float)(0.44468606)-(float)(0.7566118)));
}
if(((var1%(double)(0.5456263791122787))<=(var1-(double)(0.7406520873428855)))){
TenKLOC2.TenKLOC2method3(null,(int)(83),var5,var2,(float)(0.18862331),(byte)(-71));
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 9");
}
for(int i = 0; i < 7; i++){
 if( (((var1+(double)(0.6411704143910448))!=(var1-(double)(0.6848036726533085)))&&((var1%(double)(0.42989762299303413))==((var1+(double)(0.7416442348046639))*(((var1/(double)(0.1427069909265839))-(var1*(double)(0.6225081878308756)))+(var1*(double)(0.8295342294755349))))))){
if( ((var1+(double)(0.8640840692762458))<(var1%(double)(0.2645197678938922)))){
if( (((var2+var0)!=(var2+"tspyqawcrizmuxuyucohrakexihqibdrbhkuifkcxmwqcdmjusx"))&&(((((var0+var5)+(var0+"tkrcjjw"))==(var0+"poowomkirtxkbvocrxsblwopljtgqttx"))&&((var0+"zoahakaqumelyndqmjkjazzobyvpwxzzwynwlzabdxvzx")!=(var0+var5)))&&((var0+"wukbrimpfnuczoppqzymsfrxasyqqidwqqcousdxotleuqrpynoislwwdy")==(var5+var2))))){
System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 22");
}
}
}
}
if((((((var1-(double)(0.28599757761345856))-(var1%(double)(0.5968091328762578)))/(double)(0.1082360959129004))-(var1*(double)(0.3679359513931818)))<=(var1/(double)(0.3452754466913823)))){
var0 = (String)(((var5+"yipypmvlruiryoxeansnsqawmtgbancskfodetovmqdngu")+((var2+var5)+(var0+var5)))+(var2+var0));
}
else{
 f3 = (float)((f3*(float)(0.56213397))-((float)(0.27672786)-(float)(0.5178301)));
}
if( ((((var1*(double)(0.04921231847734042))*((var1-(double)(0.45707969502774703))+(var1-(double)(0.9501389346137298))))-(var1*(double)(0.0675871857426994)))==(var1/(double)(0.020381394666027175)))){
System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 35");
}
if( ((var5+var2)==((((var2+var0)+((var2+"wjjtnmatrejytqenwxmsdzghaatilqiic")+(var0+var2)))+(var5+var2))+(var2+var5)))){
f5[28] = (short)(((short)(26261)/(short)(4574))*((short)(28800)-(short)(12506)));
}
if( ((((var1+(double)(0.43790890423683604))*(var1/(double)(0.9655465439811648)))!=(var1-(double)(0.4438284152147409)))||((var1+(double)(0.9827140449243094))==(var1/(double)(0.4497086724647037))))){
System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 45");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 51");
}
if(((var5+"vejgyctghpdqpmxkmcsebaizvfzyvqdczohyycy")==(var2+var5))){
System.out.println("TenKLOC9 - TenKLOC9method2- LineInMethod: 59");
}
else{
 f3 = (float)(((float)(0.2601934)-(float)(0.7121348))+((float)(0.873116)+(float)(0.92794335)));
}
return (Object)null;

}

public static String TenKLOC9method3(double var0, byte var1, float var2, long var3, char var4){
 TenKLOC9 classObj = new TenKLOC9();
if((((((var1*(byte)(123))+((var1%(byte)(-128))*(var1+(byte)(-72))))>=(var1*(byte)(-41)))&&((var1*(byte)(-3))<(var1+(byte)(-68))))&&(((var1+(byte)(-120))!=(var1*(byte)(-4)))&&(((var1+(byte)(8))<=((var1+(byte)(79))*(var1+(byte)(58))))||((var1-(byte)(-94))==(var1-(byte)(-60))))))){
var3 = (long)((var3+(long)(221))-(var3-(long)(265)));
}
else{
 var4 = TenKLOC2.TenKLOC2method2(var1,var2,(short)(9150));

}
if( ((var3/(long)(724))==(var3*(long)(282)))){
if( ((((((var0%(double)(0.5308633742372549))-((var0-(double)(0.7303645470166966))+((var0/(double)(0.072751555268745))+(var0-(double)(0.27261107003816776)))))/(double)(0.20619919474658677))-(var0+(double)(0.4383080133993488)))>(((var0/(double)(0.216690925662553))*((((var0-(double)(0.39101134686862626))+(var0-(double)(0.5234161447955736)))*((var0+(double)(4.4030676151118886E-4))-(((var0/(double)(0.2420268815771882))-(var0*(double)(0.4726128250036268)))+((var0*(double)(0.9060108725219996))+(var0%(double)(0.8942400455977813))))))+((var0*(double)(0.012946020895550636))*((var0+(double)(0.14311125961621263))*(var0+(double)(0.8783088373793392))))))-(var0+(double)(0.9758379443748517))))&&((var0%(double)(0.5659704614874335))>(var0+(double)(0.44486363042629695))))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 11");
}
}
if((((((var3+(long)(128))*(var3%(long)(570)))*(var3/(long)(43)))+(var3*(long)(486)))>(var3%(long)(292)))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 20");
}
for(int i = 0; i < 7; i++){
 if( ((var3-(long)(714))==(var3*(long)(105)))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 27");
}
}
if( ((((var3*(long)(87))>(var3-(long)(103)))||((var3+(long)(606))>=(var3*(long)(509))))&&(((var3-(long)(655))>(var3*(long)(491)))&&((var3/(long)(163))==(var3-(long)(621)))))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 31");
}
if(((var4-'d')!=(((var4/'l')*(var4-'f'))+(var4*'d')))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 39");
}
else{
 System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 43");
}
if( ((var4+'o')!=(var4%'m'))){
if( (((var4/'i')%'p')!=(var4+'c'))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 49");
}
}
if(((var1-(byte)(46))<=(var1*(byte)(24)))){
System.out.println("TenKLOC9 - TenKLOC9method3- LineInMethod: 54");
}
else{
 f0 = (short)((((short)(8295)-(short)(13725))-((short)(17124)+(short)(21715)))-((short)(26242)*(short)(30504)));
}
return (String)"eisqnstlcqpmqwyuppmbqqkmbrvkca";

}

public float TenKLOC24method0(String var0, float var1, String var2, short var3, byte var4){
 TenKLOC9 classObj = new TenKLOC9();
if( ((f3-(float)(0.7802376))!=(var1+(float)(0.7689539)))){
if( ((var3-(short)(565))>(f5[62]%(short)(25980)))){
if( (((var0+var2)!=(var2+"njr"))&&((((var2+var0)+(var0+"xvtrexqrrteawplflwcfatrqgygjrvybyazftkqzejxzyubc"))+(var2+"uiopfgtmjdonisgrkilbewwsfnqjsmyfkilgzjwltadmmvarlzqlvukpeaoktiflsmulroihnsbqthzxmiilgmedhxprjetjkfr"))!=(var2+"fshpqlrnwzexzyswyofwwfrjnyceglxrimzqidhxriibrqhzlqzgccbeghlfyfubfwswrembmddcsnssprni")))){
System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 7");
}
}
}
if( (((var0+"pbhgwxtfmrnbaqnpzihngcdvulzpvvomkdjivycokxbspetwauynnesbqunwpnsalhqng")!=((var2+var0)+((var0+"iqfnjrjocnokgrptkvuvbdroavhdnseehpqbionkvwkbjtqfjkmfvngilrajzwxjdvywnlyfe")+(var2+"gwoiobjrjrbxsrllstysjyyojwsnbtzvbp"))))||((((var2+"enhwhhwywvduvehmc")==(var0+"byqzvwqsykzgydplsoiiqzlxodohtklzjooo"))&&((var0+"qwwhaifoynvdb")==(var0+"upfgpeep")))&&((var2+var0)!=((var2+"btrjmqsbumyvcfjbzsddpeqbnaaqkcnsxtsuqwlwiemotillxujvxuwgamllmyuxryddigwszxwudtxohdnoqwgjjpydvsgmjeaw")+(var0+"grlycoezxjmxkhpdjdvbymioopstar")))))){
f4[84] = new TenKLOC2();
var3 = f4[84].TenKLOCInterface2Method0(var2,var3,null);

}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 15");
}
if( (((var2+"rubyebijf")==((var0+"jsmcxwmdlwrhsykknzeozvfimuhdahgzevoborsdlhwwqomsrfvsxzvjuuwzjn")+(var0+"dotsexpesoenzdcqpqygtgftkgprazditrnzutgakkkjycsoxmgkusqzsrcxfsjlhprkyhobnkupyjiehzezbszstjba")))&&((((var0+var2)+((var2+"zzjzmscztufrwywey")+(var2+var0)))+(var2+var0))==(var0+var2)))){
f5[17] = (short)((var3+(short)(32038))*(var3%(short)(13565)));
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 22");
}
if( (((var4-(byte)(49))!=(var4*(byte)(86)))&&((var4+(byte)(57))<(var4-(byte)(70))))){
var4 = (byte)((var4+(byte)(105))%(byte)(71));
}
if( (((var1*(float)(0.86909354))<(var1-(float)(0.27356392)))&&((var1*(float)(0.8762743))<=(var1%(float)(0.3641767))))){
var3 = (short)((var3/(short)(25010))*(var3%(short)(16556)));
}
if( (((f3-(float)(0.15266442))+(f3-(float)(0.86457443)))>=(var1/(float)(0.47530788)))){
System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 32");
}
if(((var3/(short)(635))>(var3-(short)(9310)))){
System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 37");
}
else{
 var3 = (short)((var3%(short)(6148))%(short)(30473));
}
if( ((var0+"tpgyywaulpwxjfrglfythqjhnxmvuguibesxhdzifyvlszndfmiuzefohboohfneodlfoaumdzfdluurimis")==(var2+var0))){
var2 = (String)((var2+"omtwqp")+(var0+var2));
}
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 48");
}
if((((f3*(float)(0.9084978))*(f3*(float)(0.39314353)))>=(var1/(float)(0.031725287)))){
System.out.println("TenKLOC9 - TenKLOC24method0- LineInMethod: 56");
}
else{
 var2 = (String)(((var2+"bhdaerovmidwhitttpcrngoki")+((var2+"gpacjlobneou")+(var0+"klbiwmhpqwknnxdftvqjlhpwifxqqzmctjfrsqgwcjaokjkqj")))+(var2+"lkwiagtzftsmxtozafzsyxrsaqcssaejprrzcbmxvebpsgrbhxyphkqjueuebsazmpzrfi"));
}
return (float)var1;

}


public static void main(String args[]){
TenKLOC9 obj = new TenKLOC9();
obj.TenKLOCInterface2Method0("jzfcbnhgnubtmlwlvbghdikq",(short)(97),new TenKLOC7());
TenKLOC9method0("ocbppdqjsg","tgvegtgfthxuuocdbawzmlpqddipzeejlnpapdser",(int)(119));
obj.TenKLOC9method1('q','j',(long)(30));
obj.TenKLOC9method2("uafrhekxuzakxcebqupyqrfjyldyavxxbcwysqygcrkxtttrbqktamxxhapgnkdchidhoopfhifzzwyi",(double)(0.25718383979713655),"bofkdixcxqnbnnkqfmbnccedjtxdmqbvrua",'p','c',"rpozyfagwwbssbwajmuoetjqpzwptbqfshodtlcvtcwlwevfvnsclhygahltowdwfopinolwrkkehrbvh");
TenKLOC9method3((double)(0.6599732347434807),(byte)(120),(float)(0.6421537),(long)(640),'y');
obj.TenKLOC24method0("wlrueszfuswy",(float)(0.13578647),"cblctolenvpojrvspaamvlipyljkcdxvymcnbsmlujgtyeohswhztabnoyycupfauyvdzubqv",(short)(17142),(byte)(64));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC9 obj = new TenKLOC9();
obj.TenKLOCInterface2Method0("ouyhhfsxnzhqvvajgpjjzqsmaonkohpufkxzvsdsdpepqlquyczsawajaepemyzsuzqeaykcgtznfjjpqrdxkcvgwwqu",(short)(31466),new TenKLOC7());
TenKLOC9method0("mcjwcvecolxiqxnajpqymsknjtwxkovywgdlgiadvznaslclpbmdankclljlaydiywhaqhseuuoqcqwfyrsekmfoc","vgsextzm",i5);
obj.TenKLOC9method1('l','n',(long)(645));
obj.TenKLOC9method2("hfgbfueiyzfnryobslvavssmndnfsisyqantfjqqdjzmvatioyjq",(double)(0.42786636552427304),"jclkcotmwsanltzkvwjnwozbraagndyqbwbgbgvjhcstaruiwbobqebcaumbdiehgxhjiiccrexabuqrvgjsnerxqgwbkxt",'t','p',"ebsshcgfhtrflmehvxhymifpqjjpvqiyhjnyeprtqwabki");
TenKLOC9method3((double)(0.8970390903057243),(byte)(63),(float)(0.6041977),(long)(403),'y');
obj.TenKLOC24method0("hpysvrwcfbtaptgtegtwvjqvznhogdbgyajljumhsg",(float)(0.7631617),"knsuwrnrkrp",(short)(17190),(byte)(117));
}

}