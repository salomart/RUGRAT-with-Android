package com.accenture.lab.carfast.test;


public class TenKLOC11 extends TenKLOC5 {
static TenKLOC17 f0;
double f1;
static float[] f2= new float[187];


public static byte TenKLOC11method0(String var0, String var1, float var2){
 TenKLOC11 classObj = new TenKLOC11();
if( ((var2*(float)(0.97121143))<(var2+(float)(0.45801425)))){
if( ((var2-(float)(0.31857854))<=(var2-(float)(0.66454875)))){
var2 = (float)((f2[101]-f2[1])/(float)(0.039335668));
}
}
if(((var2-(float)(0.5430301))<=((var2/(float)(0.6951428))-((var2/(float)(0.15694171))%(float)(0.050486982))))){
f2[165] = (float)((var2%(float)(0.41105896))*(f2[131]-f2[121]));
}
else{
 var2 = TenKLOC17.TenKLOC17method2(var2,(byte)(117),(short)(6554),(short)(1658),(double)(0.1383949498580449),(long)(242));

}
if(((f2[49]%(float)(0.8319661))<(f2[123]+f2[132]))){
f0 = new TenKLOC17();
}
else{
 System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 17");
}
if(((((var1+"abwlohfynfbpvyswe")+(var1+"txwmoadcuxzramnrxemdubktywoymfuiremqoyshlfhpmskwmqdodwzvugnpuilsikkfsafvgqrizlmdjegancxlgrubvapkfcv"))+(var1+var0))!=(var0+var1))){
var2 = (float)(((var2+(float)(0.25899673))%(float)(0.48281693))-(var2-(float)(0.09779632)));
}
else{
 f2[170] = (float)(((var2-(float)(0.7208452))+((var2%(float)(0.0421378))%(float)(0.5268731)))-((var2*(float)(0.9355503))-(var2*(float)(0.4835229))));
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 30");
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 36");
}
for(int i = 0; i < 1; i++){
 if( ((var2*(float)(0.71818316))!=((f2[163]-f2[99])+((f2[20]-f2[18])+(f2[160]*f2[146]))))){
if( (((var2%(float)(0.73289907))+((((var2%(float)(0.29888463))+(var2*(float)(0.7522594)))/(float)(0.42283666))-(var2*(float)(0.83598936))))<(var2*(float)(0.5092038)))){
System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 44");
}
}
}
for(int i = 0; i < 9; i++){
 if( (((f2[155]-f2[94])+((f2[115]*f2[119])+(f2[122]-f2[175])))==((var2-(float)(0.91925997))%(float)(0.7343966)))){
System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 51");
}
}
if( ((f2[90]+f2[117])<(f2[130]/(float)(0.018627465)))){
System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 55");
}
if(((var0+var1)==(var1+"xbjnukrvbxgoterudfjevuxmkopvcpreqgwrfxvyysn"))){
f2[152] = (float)((var2*(float)(0.47157085))/(float)(0.12584078));
}
else{
 System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 63");
}
if( ((((var2*(float)(0.3487013))/(float)(0.21227252))==(((f2[27]/(float)(0.1509164))/(float)(0.47929305))+(f2[12]+f2[131])))&&((var2-(float)(0.8437595))>(f2[55]-f2[8])))){
System.out.println("TenKLOC11 - TenKLOC11method0- LineInMethod: 66");
}
return (byte)(byte)(-65);

}

public Object TenKLOC11method1(char var0, int var1, byte var2){
 TenKLOC11 classObj = new TenKLOC11();
for(int i = 0; i < 2; i++){
 if( ((((var2+(byte)(-57))+(var2-(byte)(-106)))+(var2-(byte)(-98)))==(var2-(byte)(-116)))){
var2 = (byte)(55);
}
}
switch((var1-(int)(466))){
case 0:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 7");
 break;
case 1:
f1 = (double)((double)(0.08670690156153049)*(double)(0.4745976472183566));
 break;
case 2:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 13");
 break;
default :
f1 = (double)((double)(0.9537360675448793)*(double)(0.08667834120389528));
}
if(((var1+(int)(648))>(var1/(int)(716)))){
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 21");
}
else{
 System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 24");
}
switch((var1/(int)(702))){
case 0:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 30");
 break;
case 1:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 37");
 break;
case 2:
var2 = (byte)((var2-(byte)(48))-((var2*(byte)(99))*(var2+(byte)(6))));
 break;
case 3:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 46");
 break;
default :
f1 = (double)((f1+(double)(0.015963112332348484))-((double)(0.12525591733854158)*(double)(0.5583852344414607)));
}
if((((var2+(byte)(83))>=(var2*(byte)(-123)))||((var2*(byte)(14))>(var2-(byte)(-12))))){
var1 = (int)(var1-(int)(589));
}
else{
 var2 = (byte)((var2+(byte)(-91))*((var2/(byte)(-25))+(var2-(byte)(32))));
}
if( (((var0-'t')*(var0-'e'))<=((var0-'b')-((var0*'y')-(var0*'a'))))){
if( ((var1*(int)(163))>=(var1-(int)(143)))){
f1 = (double)(((f1*(double)(0.9051577743264473))%(double)(0.18659375642884313))-((double)(0.43303558412859455)/(double)(0.6839564706362723)));
}
}
switch((var1-(int)(612))){
case 0:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 64");
 break;
case 1:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 68");
 break;
case 2:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 74");
 break;
case 3:
System.out.println("TenKLOC11 - TenKLOC11method1- LineInMethod: 81");
 break;
default :
f1 = (double)(((double)(0.7667692455951092)%(double)(0.924256805628998))+((double)(0.30605602057820847)+(double)(0.7928410014553966)));
}
return (Object)null;

}

public short TenKLOC11method2(char var0, String var1, float var2){
 TenKLOC11 classObj = new TenKLOC11();
for(int i = 0; i < 4; i++){
 if( (((var2+(float)(0.9375572))-(var2*(float)(0.12496853)))>(var2*(float)(0.58672106)))){
TenKLOC17.TenKLOC17method2(var2,(byte)(-2),(short)(17869),(short)(21518),(double)(0.13452879686763586),(long)(323));
}
}
for(int i = 0; i < 9; i++){
 if( (((var0*'b')+(var0/'t'))>(var0%'o'))){
if( ((var2+(float)(0.0018869638))>=(var2-(float)(0.54538405)))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 12");
}
}
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 19");
}
if(((var2-(float)(0.020201206))>((var2*(float)(0.39698744))+(var2+(float)(0.9196085))))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 28");
}
else{
 f1 = (double)(((double)(0.6106496312519716)+(double)(0.7189570218627487))%(double)(0.357009196566063));
}
if( ((var0+'k')<=((((var0+'d')%'x')*(var0+'c'))-(var0+'q')))){
f1 = (double)(((double)(0.49795146992362793)%(double)(0.7175656636598325))/(double)(0.26966255756243684));
}
if((((var0-'n')==(((var0*'c')*(var0+'h'))/'t'))||((var0*'o')<=(var0/'f')))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 38");
}
else{
 f1 = (double)((((double)(0.6679879283211201)-(double)(0.7328483829299037))*((double)(0.8503826662754705)/(double)(0.09843695097375038)))%(double)(0.22058229723698397));
}
if( ((((var0-'w')*(var0+'p'))%'s')<=(var0*'z'))){
f1 = (double)((double)(0.05780231353178633)*(double)(0.4783006752596103));
}
for(int i = 0; i < 6; i++){
 if( ((((var1+"ijnmznianaupgudlajqkqkjslfges")+((var1+"brodg")+(var1+"aqwrm")))+(var1+"zzdkgi"))==(var1+"tqswbhparxedgzjiufaqstjwqusmqwqcreobxblohvjctuwyaasmwfusodfbtaqidaurpvirmza"))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 49");
}
}
if( ((var1+"qtacrhpprakytankjdzcinqukthsbswjqnpdntiixberodoypvs")==((var1+"lpqdfavynf")+(((var1+"iboixwoftwzmxjodtmzaqejxowznghguebpojhcqrmyvuazomtvupxpttgmjmudwjsgjmhyhsyliplrkjyyfhvmnacwchafdtmr")+(var1+"vzzhfcjogrxncsmr"))+(var1+"uyppncwmlaajlvujfbnddtdhzfgnckrj"))))){
if( ((((var2-(float)(0.037542224))*(var2/(float)(0.39910322)))<=(var2+(float)(0.9756523)))&&((var2-(float)(0.2767926))!=(var2*(float)(0.7646561))))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 57");
}
}
for(int i = 0; i < 8; i++){
 if( (((var1+"anclafjdnqddkyonuvghtuqrcqvgevbmbjjxybmpaadpeshl")==(var1+"bghzftpkxnrqzvgpitcahgclgatgutzcrkkonwowkd"))&&((var1+"gwobdiitnpaesrqgosihwknulwxdgo")!=(var1+"ebouitrvcgmrmhreupetyoazooisvupsvbzzncdaxmxnxaelswpkgrdiqnuvqijlmowefuwrtxhsjwluyjabbgajhfscywhuqeg")))){
System.out.println("TenKLOC11 - TenKLOC11method2- LineInMethod: 66");
}
}
return (short)(short)(27258);

}

public double TenKLOC11method3(short var0, float var1, long var2, int var3, short var4, short var5){
 TenKLOC11 classObj = new TenKLOC11();
switch((var3-(int)(87))){
case 0:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 3");
 break;
case 1:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 6");
 break;
case 2:
var3 = (int)((((var3-(int)(316))%(int)(482))-(var3*(int)(550)))%(int)(588));
 break;
default :
var2 = (long)(94);
}
switch((var3+(int)(623))){
case 0:
f1 = (double)(((double)(0.6797248118883154)*(double)(0.09896901390410862))+((double)(0.5153466290116651)*(double)(0.7950195658299191)));
 break;
case 1:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 21");
 break;
default :
var5 = (short)(var4%(short)(16865));
}
for(int i = 0; i < 0; i++){
 var5 = (short)((var5+var0)/(short)(29370));
}
if((((((var2+(long)(202))*((((((var2*(long)(516))+(var2-(long)(217)))-(var2*(long)(70)))/(long)(368))*(var2*(long)(487)))-(var2/(long)(148))))-(var2*(long)(287)))-(var2*(long)(297)))<=(var2+(long)(701)))){
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 33");
}
else{
 f1 = (double)((((double)(0.5549879612526472)*(double)(0.953986787058245))-((double)(0.722780929942232)%(double)(0.26797649273060686)))/(double)(0.7369454837162795));
}
for(int i = 0; i < 3; i++){
 if( ((var3+(int)(322))<(var3%(int)(202)))){
var2 = (long)(var2+(long)(0));
}
}
if(((var1%(float)(0.32379955))<=(var1*(float)(0.8051236)))){
f1 = (double)((f1*(double)(0.4721569681627902))+(((double)(0.9244566802094449)*(double)(0.5403822614862596))/(double)(0.3766311510150441)));
}
else{
 System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 45");
}
if( ((var2*(long)(13))>=(var2*(long)(213)))){
f1 = (double)((f1%(double)(0.27225818476426433))+(((double)(0.5553387635807537)*(double)(0.9460029648180039))-((double)(0.525951262972843)-(double)(0.41944262181854197))));
}
switch((var3+(int)(162))){
case 0:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 52");
 break;
case 1:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 57");
 break;
case 2:
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 62");
 break;
case 3:
var4 = (short)((var0%(short)(4115))-((var5-var4)+(var4-(short)(25702))));
 break;
default :
System.out.println("TenKLOC11 - TenKLOC11method3- LineInMethod: 71");
}
return (double)(double)(0.805588510519924);

}

public static char TenKLOC5method1(long var0, float var1, double var2){
 TenKLOC11 classObj = new TenKLOC11();
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 3");
}
if( ((var1+(float)(0.13144535))!=((var1%(float)(0.57905114))*(var1*(float)(0.6939911))))){
var2 = (double)(((var2+(double)(0.5621310309122353))+(var2*(double)(0.7765027182730574)))*(var2%(double)(0.17895597946670727)));
}
if(((var2*(double)(0.3450576176570268))!=(var2+(double)(0.514864569564685)))){
f0 = new TenKLOC17();
var2 = f0.TenKLOC17method4((short)(20661),null,(short)(17634),'g',var2);

}
else{
 var0 = (long)(((var0%(long)(390))-((var0-(long)(765))+(var0/(long)(339))))-(var0*(long)(770)));
}
if( ((f2[175]+f2[66])>=((var1*(float)(0.16993642))*(var1+(float)(0.27677125))))){
if( (((var0/(long)(623))<=(var0*(long)(110)))&&((var0+(long)(416))>=(var0*(long)(62))))){
if( (((var1-(float)(0.18099809))+(var1-(float)(0.710069)))>=(var1/(float)(0.12559325)))){
System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 19");
}
}
}
if( ((var2*(double)(0.5036122383494869))<=((var2+(double)(0.9003750992078906))%(double)(0.22135216821107906)))){
f2[147] = (float)(f2[135]*f2[169]);
}
for(int i = 0; i < 1; i++){
 var0 = (long)((var0-(long)(236))-(var0*(long)(246)));
}
for(int i = 0; i < 2; i++){
 if( ((var1-(float)(0.18118042))<(f2[123]/(float)(0.9544467)))){
var0 = (long)((var0+(long)(36))*(var0%(long)(330)));
}
}
if( ((var1-(float)(0.9482477))<(var1-(float)(0.2945763)))){
var2 = (double)(var2-(double)(0.699358667201997));
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 40");
}
if(((var2/(double)(0.29810960372096795))==(var2-(double)(0.601166828332199)))){
System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 45");
}
else{
 System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 47");
}
if( ((var2%(double)(0.25651456268561534))>=(var2+(double)(0.5568843192295361)))){
System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 50");
}
if(((((var0/(long)(683))-(var0+(long)(87)))-(var0%(long)(533)))==(var0%(long)(33)))){
System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 57");
}
else{
 System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 58");
}
if(((var0-(long)(607))<(var0%(long)(382)))){
System.out.println("TenKLOC11 - TenKLOC5method1- LineInMethod: 67");
}
else{
 f2[33] = (float)((var1/(float)(0.28512347))*(f2[22]-f2[68]));
}
return (char)'p';

}


public static void main(String args[]){
TenKLOC11 obj = new TenKLOC11();
TenKLOC11method0("epgyvzwabr","fizhrkrwltbzcaertjvjlzgk",(float)(0.02269578));
obj.TenKLOC11method1('f',(int)(373),(byte)(18));
obj.TenKLOC11method2('f',"qetvxzzfbdabuivabgfvzcsykgtznf",(float)(0.9294598));
obj.TenKLOC11method3((short)(16957),(float)(0.13408375),(long)(678),(int)(655),(short)(21160),(short)(3718));
TenKLOC5method1((long)(479),(float)(0.32788777),(double)(0.31445417436730416));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC11 obj = new TenKLOC11();
TenKLOC11method0("gmoapbruivvwetbamybulhefetlmaetephdfbuyozajfxwugzoiiufopufenjndgkvegrsxbiafvwfptyzrdbqyxlcraqmbdyect","rehgffuwsreorhmxfpidqcnwtqrmckwftwqboisrmurwwwxqcwk",(float)(0.37741876));
obj.TenKLOC11method1('l',i0,(byte)(107));
obj.TenKLOC11method2('e',"vaxiwhgiokbcstpguecnwjvewjqkpzlimstmfyunddnavrvrlptogbssvzivczihzioujtknbyaqozskkceypyj",(float)(0.66364145));
obj.TenKLOC11method3((short)(15193),(float)(0.90885013),(long)(370),i6,(short)(22251),(short)(13011));
TenKLOC5method1((long)(131),(float)(0.96823186),(double)(0.26913915103920083));
}

}