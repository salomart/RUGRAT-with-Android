package com.accenture.lab.carfast.test;


public class TenKLOC0 extends TenKLOC29 {
static double[] f0= new double[25];
byte f1;


public static byte TenKLOC0method0(String var0, double var1, char var2){
 TenKLOC0 classObj = new TenKLOC0();
if( (((var2*'o')+(((var2*'r')%'l')*((var2*'r')+(var2%'t'))))>(var2*'n'))){
if( ((var1+(double)(0.20681453512745795))<=(f0[8]%(double)(0.15437657990201847)))){
f0[1] = (double)((var1+(double)(0.578168020856168))/(double)(0.06125876233233862));
}
}
if((((var1-(double)(0.1575302512993707))*((var1*(double)(0.883246493541652))/(double)(0.35386756129864794)))>(f0[6]*f0[5]))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 10");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 13");
}
if( ((var2-'k')!=(var2%'o'))){
if( ((var2+'c')>(var2+'d'))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 19");
}
}
for(int i = 0; i < 4; i++){
 f0[11] = (double)((var1*(double)(0.8134507697100146))+(var1/(double)(0.6314932472463821)));
}
if( ((var0+"trevtyypwfxubyqufzhbqwpxhwvuxykdwzqehduugwduwrhizbkegaglenhgjraalvybxwz")==(var0+"okrrjmpehhcjrtlkgeurvkybleqzetecrfkvqqiledozyayuolqtdhpkmgcotbvtvirakvgzmifkdnbsxctygtiemhdbksddtzo"))){
f0[10] = (double)((f0[12]-f0[15])*(var1+(double)(0.01116659772886941)));
}
if( (((var0+"yvtrvuywnxfcjmrvv")==(var0+"pvfcwpbjgmketrvjchxwcgrkcykbkokutkmwiydlhmcenmmgvivg"))&&(((var0+"iuzxyfokhi")!=(var0+"idinbciuvyibgobesxesgqoujvyqluaraxknbgpbkhwtavjqfsjhv"))&&(((((var0+"lzbjil")+(var0+"xldhh"))+(var0+"dxcdrecvinxlnmjkglhxcxwtrhliumeexnfrrblqrjivuoypqhffibzclrtzdjrsfwmsgiunxrtergdoqshslvxhq"))!=(var0+"mozdmmjffkwnjuheyyenevujeubgnufbahppcgflxkjzarhiejotnpjgvmcqukhantdhxvll"))&&((((var0+"qivywawijxdeybafsksyuvmlnkcnzpnbkqvazyavopkqwcvzcxsonahynaiookqjtbdkyjxjavttamfqzicgxdbcmsjikmt")+(var0+"dulcyppzaduipxcsrqvx"))+(var0+"tegqhzdqcqeykyilgeeqrtobcbfwuldqhcqxsosmltyjqicwvucjkhjvhjnbettfuopgegupqzjc"))!=((var0+"xkpsgwwugpnjcikcaencnzqmdltvhehmwfcwirmybfovepclzoicfwiaylxdgmtpnebizhetcdtgwvvvmhzcmfukjddvpqb")+(var0+"qtrmxhlqhbdlpwdjzclfhejvvrscqkaodnwwstytunucbfbezwivgvjvryvlfsnlnsswqeagklynlpvxyjcrrolhjtoiv"))))))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 31");
}
if(((var2/'v')<=(var2%'x'))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 38");
}
else{
 }
if(((((var0+"asclznvmedceptveveyazmxplenwpoycgjavfekuflfyjpewzwkmwmscfyuircupgvuyitwmsj")+(var0+"txxrabzdnyxlnmkhalcnnvycxashmnkqobymv"))==(var0+"zkvuramndzngyuguplnbewidvdppiikdcdkta"))&&(((var0+"nmltozadmpfbwvmflehqdewhghrcwvsftubpsmimpjtntjlbgusxbspovkmicqfqyxehynudzrdykattorzj")!=(var0+"nqyslbafwvrutjommvdvzbkxerpcstdxupsihzyyzaqdohsitzmanjfxxkkebpzsxkabkyadxsfvimiiyanfr"))||((var0+"auwyjpfdshspqusopzbofdzywbaekyzhasxgwlqjeczflkpekdarptroaavkhibnmev")==(var0+"yotnzcimdntgdeyeibreiesvkyofdzbxzbexdnjiu"))))){
f0[17] = (double)((var1*(double)(0.22308761817071743))-(var1/(double)(0.02939492825171719)));
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 46");
}
if(((((var0+"gauiwlfjaxzwrfceklyexitbfyufejzib")==(((var0+"puqswojpfqxxqdyjekgnapmxxhsyrhfqtygnipxvlcnumcfkcwaqdnsjelmrrgqzxxmaryhepkks")+(var0+"hgvtclhtyskgfgbgsgmthowjewgaxcqdf"))+((var0+"ljjdvqyaygwmpksjmgozgpwuhcunfsisfrsprvxzqktvmvdopsced")+(var0+"aqqakavzoppwgdeqhqtdju"))))&&((((var0+"nypqppotglmkpjxarvhsdlritzsftifwtysndxcxycabdymyhbtynqflmuhwurfkeznmytwqxyfoyxnigrj")+(var0+"cjjuvsotqblndxurocydjtalvplrezqzyyjhwtiyjtgcreykgqfjwvgyohopx"))!=(var0+"adchqgnzolbozxeafwdzohqeyrdpcaqqohuvmofak"))&&((var0+"baugbspnklvvbqzmlfogipyeynbvengxugcickxwdsfdsuvkyonajuahpphggvzscwtuvbjqxgxfevucgxll")!=((var0+"wsduopdjzpdkizabcovyehehwpjvbgzgxb")+(var0+"iudvkjeimmzawhcwehnenxxvdrmgzqwduzxgxedbzsjnxztcsosnrwpsramogkpjjuhtcnuslswaqgomxirvbmokppqyqhkby")))))&&((var0+"yywxbjrbzvwkzsircszkaxpwsfvvlydmchvpnmyb")==(var0+"av")))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 54");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 59");
}
if( ((var0+"fujwcfsmpikcquaidqdmnisbxmwbchplunoyefcreq")!=(var0+"hdeyradpjwctrfkbpapgpfwupcoifeawkmxtymxbashbmgqxhgefknuz"))){
f0[2] = (double)(f0[16]/(double)(0.8686667638487975));
}
if( (((var1%(double)(0.18127938404648014))>=((var1-(double)(0.7483938312604709))%(double)(0.7121736667550943)))||((f0[6]*f0[23])<((var1+(double)(0.8823318168380344))-(var1*(double)(0.33240269285103297)))))){
System.out.println("TenKLOC0 - TenKLOC0method0- LineInMethod: 66");
}
return (byte)(byte)(-13);

}

public static Object TenKLOC0method1(double var0, TenKLOC14 var1, long var2){
 TenKLOC0 classObj = new TenKLOC0();
for(int i = 0; i < 5; i++){
 if( (((var0-(double)(0.641550857074522))+(var0-(double)(0.4382729771342345)))<(var0+(double)(0.2552368940462123)))){
if( ((var2*(long)(516))!=((var2+(long)(524))*(var2+(long)(527))))){
if( ((((var2+(long)(572))<=((((var2-(long)(663))%(long)(393))-(var2-(long)(768)))/(long)(362)))||((var2-(long)(687))==(var2+(long)(301))))&&(((((var2-(long)(12))*(var2%(long)(204)))/(long)(331))*(((var2/(long)(531))%(long)(559))*(((var2%(long)(119))+(var2-(long)(144)))/(long)(481))))>(var2+(long)(619))))){
var1 = new TenKLOC14();
var0 = var1.TenKLOC14method1(null,"pmucxsxliwvybyvgtxlshyskarjgwvviiscuxamqvxxlmixunmlodmrttuvuwfbjrdmpuuiewfefuwqtjvfeaoxmrwkcx",(float)(0.4319927));

}
}
}
}
if(((var2*(long)(275))<=(var2*(long)(330)))){
var0 = (double)(((var0%(double)(0.6538568889558855))%(double)(0.3556227924143247))%(double)(0.4944374176165762));
}
else{
 var0 = (double)((var0-(double)(0.22379435790253488))-(var0*(double)(0.8137520527206652)));
}
if(((var0-(double)(0.6201125083118298))!=(var0+(double)(0.8816685851075493)))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 20");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 24");
}
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 27");
}
if( ((((var2/(long)(495))-(var2*(long)(117)))==(var2+(long)(710)))&&((var2*(long)(163))<(var2+(long)(649))))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 34");
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 37");
}
if( ((var2*(long)(260))<=(var2+(long)(519)))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 44");
}
if( ((var2+(long)(1))>(var2-(long)(177)))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 49");
}
if( ((var2*(long)(366))>=(var2*(long)(314)))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 55");
}
if((((f0[23]+f0[17])*(f0[20]-f0[10]))>((var0*(double)(0.5073918588887981))+(var0*(double)(0.9214153818204815))))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 60");
}
else{
 f0[22] = (double)((var0%(double)(0.8188836171660357))+(f0[12]*f0[22]));
}
if(((var0+(double)(0.06575868515139982))>=((f0[15]*f0[20])%(double)(0.7801052308418324)))){
System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 67");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method1- LineInMethod: 72");
}
return (Object)var1;

}

public float TenKLOC0method2(short var0, double var1, long var2){
 TenKLOC0 classObj = new TenKLOC0();
for(int i = 0; i < 4; i++){
 }
if( ((var1+(double)(0.8649263838892611))!=(var1+(double)(0.33421801269258067)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 5");
}
for(int i = 0; i < 5; i++){
 if( ((var2-(long)(82))>=(var2-(long)(402)))){
if( ((var1-(double)(0.3262413193658774))==((var1/(double)(0.7776202624930999))/(double)(0.33944865305729144)))){
var1 = (double)((var1-(double)(0.4345626166600386))%(double)(0.049169437452322384));
}
}
}
if( (((var2/(long)(47))<(var2-(long)(292)))&&(((var2+(long)(163))!=((var2-(long)(141))/(long)(482)))&&((var2+(long)(351))<=(var2+(long)(450)))))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 16");
}
if( ((var1-(double)(0.14490626815318775))>=(var1%(double)(0.7998211282658445)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 21");
}
if( ((((var0*(short)(5596))-(var0+(short)(13844)))*((var0/(short)(17387))-((var0-(short)(22771))+(var0%(short)(20944)))))<(var0+(short)(30695)))){
if( (((var0-(short)(8934))+(var0*(short)(18624)))<=((var0*(short)(25856))+((var0+(short)(3039))%(short)(25867))))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 30");
}
}
if(((((((var1*(double)(0.891525790143658))*(var1%(double)(0.529226004779662)))+(var1%(double)(0.8463225121215627)))-(var1/(double)(0.9264799736298157)))<=(((var1*(double)(0.8228200970999067))+(var1/(double)(0.9372685994716954)))+((var1+(double)(0.5923554793140631))/(double)(0.43449533436427845))))||(((var1-(double)(0.8746874299823115))<(var1%(double)(0.8545998007735901)))&&((((var1/(double)(0.6943245124310403))-(var1+(double)(0.02028245650537297)))+(var1%(double)(0.06988121253984614)))!=((((var1-(double)(0.8086406148459131))*(var1/(double)(0.6298148750515246)))*((var1*(double)(0.3643568349527423))*(var1/(double)(0.6258154391706907))))-(var1+(double)(0.7107171403467158))))))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 35");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 36");
}
if( ((var2*(long)(320))<((var2%(long)(412))/(long)(727)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 39");
}
if(((var1*(double)(0.8031852199896632))>=(var1-(double)(0.40326558056114936)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 45");
}
else{
 var1 = (double)((var1*(double)(0.8764980305482981))*(var1*(double)(0.1412754866866277)));
}
if( ((((var2*(long)(623))+(var2/(long)(536)))/(long)(599))!=(var2/(long)(165)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 53");
}
if((((var1+(double)(0.4222196287075678))>=((var1-(double)(0.6564534139923829))+(var1*(double)(0.1598251911475994))))&&(((var1%(double)(0.21012351116557348))>(var1-(double)(0.947116409871049)))&&(((var1+(double)(0.931153091739364))+(var1/(double)(0.6742984364267057)))<((var1+(double)(0.4455723085747967))*(var1%(double)(0.9040202761971621))))))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 61");
}
else{
 System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 62");
}
if(((var0%(short)(17067))>=(var0*(short)(29670)))){
System.out.println("TenKLOC0 - TenKLOC0method2- LineInMethod: 67");
}
else{
 var1 = (double)((var1-(double)(0.5628799028964313))+(var1-(double)(0.09890605971013977)));
}
return (float)(float)(0.9646989);

}

public long TenKLOC0method3(String var0, int var1, TenKLOC29 var2, double var3){
 TenKLOC0 classObj = new TenKLOC0();
if( ((var0+"culdzcakfyppppeibygidykbzbpnporjmqqiuuukdhiawcqyvhkyojadyifookykcgzgbnwxjkpnhmfoqsqb")!=(var0+"mjiocnrbuylohmsmld"))){
if( (((var1%(int)(75))<(var1*(int)(218)))&&(((var1+(int)(480))-(var1+(int)(105)))<((var1+(int)(393))-(var1-(int)(532)))))){
if( ((var1+(int)(234))==(var1*(int)(130)))){
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 7");
}
}
}
for(int i = 0; i < 7; i++){
 if( (((var3*(double)(0.5592050393656374))<(var3*(double)(0.6308486829588102)))&&((var3*(double)(0.05722296068663879))!=(var3*(double)(0.22570403809738937))))){
var0 = (String)((var0+"sfparjumwzi")+(var0+"qpuupvmapecojuxujeqydieogovaoztvaiqzvwgrxsnakvknbvf"));
}
}
switch((var1-(int)(280))){
case 0:
var3 = (double)((var3+(double)(0.6178987752643178))+(var3%(double)(0.6004985843205843)));
 break;
case 1:
var1 = (int)(var1*(int)(105));
 break;
case 2:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 22");
 break;
case 3:
TenKLOC29.TenKLOC29method0(var3,var1,var0);
 break;
case 4:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 30");
 break;
case 5:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 37");
 break;
case 6:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 42");
 break;
default :
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 48");
}
for(int i = 0; i < 2; i++){
 System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 51");
}
switch((var1-(int)(140))){
case 0:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 58");
 break;
case 1:
f1 = (byte)(((byte)(-42)-(byte)(107))%(byte)(67));
 break;
case 2:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 67");
 break;
case 3:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 71");
 break;
case 4:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 77");
 break;
case 5:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 82");
 break;
case 6:
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 85");
 break;
case 7:
f1 = (byte)((((byte)(35)*(byte)(46))*((byte)(-80)*(byte)(-65)))/(byte)(81));
 break;
default :
System.out.println("TenKLOC0 - TenKLOC0method3- LineInMethod: 94");
}
return (long)(long)(446);

}

public static byte TenKLOC29method2(TenKLOC29 var0, float var1, TenKLOC4 var2){
 TenKLOC0 classObj = new TenKLOC0();
if(((var1/(float)(0.8189204))!=(var1%(float)(0.7499099)))){
f0[6] = (double)(((double)(0.6465080833913631)*(double)(0.42229315406294565))*((double)(0.7543818527705136)%(double)(0.8643591871399423)));
}
else{
 var1 = TenKLOC29.TenKLOC29method1((long)(384),(byte)(-26),null,"shiphxnrumnprarxonvkojotguqksatxklwns",(long)(723));

}
if( (((var1-(float)(0.082819104))-(var1+(float)(0.3346359)))!=(var1*(float)(0.80755717)))){
System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 9");
}
if(((var1/(float)(0.020958126))>=(var1%(float)(0.7051511)))){
var0 = new TenKLOC29();
}
else{
 f0[1] = (double)(((((double)(0.863692235057179)*(double)(0.6586944493588299))-((double)(0.3926450261257859)-(double)(0.21412012666009395)))*((double)(0.4547930763710377)+(double)(0.33135713413373313)))/(double)(0.8497781935675649));
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 22");
}
for(int i = 0; i < 3; i++){
 if( ((var1*(float)(0.38322037))==(var1*(float)(0.9101556)))){
System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 27");
}
}
for(int i = 0; i < 3; i++){
 f0[18] = (double)((((double)(0.9274364139988485)-(double)(0.6809624912870154))*(((double)(0.36461511408085023)%(double)(0.7005946868739986))-((double)(0.7681497235624694)-(double)(0.30099020520590203))))%(double)(0.40423466373404326));
}
if(((var1/(float)(0.8290325))>=(var1/(float)(0.87066644)))){
var1 = (float)((var1/(float)(0.11521274))-(var1*(float)(0.34163433)));
}
else{
 f0[17] = (double)(((double)(0.8377144171202161)*(double)(0.36096967894003906))+((double)(0.6068383416365489)%(double)(0.9641925453533984)));
}
for(int i = 0; i < 9; i++){
 if( ((var1*(float)(0.7953247))>(var1%(float)(0.20836282)))){
if( (((var1+(float)(0.4568079))<(var1-(float)(0.5449738)))||(((((var1-(float)(0.8509507))-((var1-(float)(0.8984899))+(((var1-(float)(0.1593222))+(var1-(float)(0.29272664)))%(float)(0.9598634))))-((var1*(float)(0.7632145))*(var1/(float)(0.42905122))))*(var1+(float)(0.61724377)))==((var1+(float)(0.25530583))-(var1*(float)(0.3087538)))))){
if( ((var1*(float)(0.600481))<=(var1+(float)(0.2575779)))){
System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 48");
}
}
}
}
if(((var1*(float)(0.7445439))==(var1%(float)(0.5141193)))){
f0[14] = (double)(((double)(0.17367816359874855)+(double)(0.962721262050861))/(double)(0.009733631756047356));
}
else{
 f0[24] = (double)((((double)(0.4921893802188947)/(double)(0.5278142161872265))/(double)(0.2558310092480406))-(((double)(0.9303499153383821)*(double)(0.8128263402642832))-(((double)(0.7890944187527932)%(double)(0.07060852736505885))+((double)(0.10367118121061958)*(double)(0.41815913868943044)))));
}
for(int i = 0; i < 5; i++){
 if( ((var1*(float)(0.56037873))>=(var1*(float)(0.10092676)))){
var0 = new TenKLOC0();
}
}
if( ((var1+(float)(0.6513965))>(var1/(float)(0.1966567)))){
System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 65");
}
if(((var1+(float)(0.015928328))!=(var1/(float)(0.99743813)))){
var2 = new TenKLOC4();
}
else{
 System.out.println("TenKLOC0 - TenKLOC29method2- LineInMethod: 71");
}
return (byte)(byte)(-84);

}


public static void main(String args[]){
TenKLOC0 obj = new TenKLOC0();
TenKLOC0method0("ulusubytvegpwxnttpvqbouavaztothpwqxuwjczhadfzxskolmyh",(double)(0.44699528668421085),'a');
TenKLOC0method1((double)(0.4384386803867423),new TenKLOC14(),(long)(533));
obj.TenKLOC0method2((short)(8905),(double)(0.5732114175683021),(long)(561));
obj.TenKLOC0method3("jvgubyvnpdyrprgvdbqvlnzinkvjgskblicqufhvasxwqtgd",(int)(559),new TenKLOC29(),(double)(0.9834653920549999));
TenKLOC29method2(new TenKLOC29(),(float)(0.91873336),new TenKLOC4());
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC0 obj = new TenKLOC0();
TenKLOC0method0("diyarbyvajbkhvfnkclynbrtzvffiqvxsxgidtfklcwdhtgntannrfpnvfircixxbhaiwptpqfxcobnldjpaqpyiowjiezazidnf",(double)(0.18647471237650426),'j');
TenKLOC0method1((double)(0.09935882884107394),new TenKLOC14(),(long)(102));
obj.TenKLOC0method2((short)(21042),(double)(0.9857225633957866),(long)(268));
obj.TenKLOC0method3("eralqlqnuiwljgjtbpbfsxlticzgibgzkitgnmwfjlmdugzlbizkacbfcagjbzqmyaoiazqzcnhshhdpb",i3,new TenKLOC29(),(double)(0.9143294171858862));
TenKLOC29method2(new TenKLOC29(),(float)(0.39220655),new TenKLOC4());
}

}