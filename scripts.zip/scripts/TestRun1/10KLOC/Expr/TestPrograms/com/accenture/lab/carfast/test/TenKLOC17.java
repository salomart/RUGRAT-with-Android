package com.accenture.lab.carfast.test;


public class TenKLOC17 implements TenKLOCInterface2 {
int[] f0= new int[161];
static float[] f1= new float[158];
TenKLOC0 f2;
static float f3;
long[] f4= new long[74];
static char[] f5= new char[127];


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC17 classObj = new TenKLOC17();
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 3");
}
if( ((var1*(short)(32199))>=(var1%(short)(15904)))){
System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 6");
}
for(int i = 0; i < 8; i++){
 if( ((var0+"ypdsnqusajgvaxyjxwxecbzifrnbfgoupcsanenqfdj")==((var0+"skimbjaidrecqlrlusalwguclabqhtxujvtzn")+(var0+"gczwbdxrxjbwkiwiifgrgzatwvdckwzlyofjqelmastvulczcqpktkmqgwdgimvuzwazcaduyjixlvkq")))){
var0 = (String)((var0+"ebpsekbykqfwlwxhnqxwlurkmolzcaihf")+(var0+"vdbwkwcytstjavmwekdqqykgdbzmfsvkvxvqafftirigmrnphqrotw"));
}
}
for(int i = 0; i < 7; i++){
 if( ((var0+"yfvxoiqhmxzosfuu")==((var0+"igvtawxkvbxeyaldwltmcjechyqr")+(var0+"hrcqtwbvpzytikrezomqaunprfk")))){
if( (((var0+"ldesosnkluvphoahywrlustvxpjlhlemippvkhrzhfddsbnsayprgdyqtepbogdxrtvdmqxndmwxyizrzdjahkjhyftofvtn")==(var0+"hwriwhwqkqoxgnkpekzioxmczifohvekgeieiofxdywybcjjkhygiljpncksuvmdzdttthjeabnbuqee"))||((var0+"oblk")==(((var0+"hrydlfsccjrizhvamxuzknqvfzhxqinfsydgeuuoolgqroqizxofufdlpiqfnqvrintdbd")+(var0+"fqhvegxokbtxviijpsezdwlyhkfxntohifdldpaktblnuqgimpdhuyegtenzoicyqdyrrliqwjzrc"))+(var0+"kgrcyuticqajsxyfanjnncvdnwmhjzutxvigrrcpzjyopqevcjips"))))){
if( (((var1*(short)(26908))%(short)(9392))==(var1+(short)(20758)))){
var2 = new TenKLOC7();
var2.TenKLOCInterface2Method0(var0,var1,var2);
}
}
}
}
if(((var0+"qeehppthmbtdmehrhqvkjrujtovu")==(var0+"sjnjptbnsj"))){
System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 29");
}
else{
 System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 32");
}
for(int i = 0; i < 2; i++){
 if( ((var0+"vylmahxgxcpgrrcesyfmwlejujufovrmtnrwwvrdztmatnodjybdytwrkuoswughdburxyginxvqvmlybpzlzcqwwmsxrtovnqj")==(var0+"zlhqbntyefnrqtqbrnxqxoyqmmfcafbumjdcrboid"))){
System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 38");
}
}
for(int i = 0; i < 7; i++){
 if( ((var0+"gzveglqnbxgbwwzpmudfybvueaoltkkpdmexvktvjaxwkxlyvyvbbiifxdmlchsbpuqkvrkoqfackfeetrtmxxol")==(var0+"umlbriycellwcprpidgpxuoguhieheuuhaivrqeqpedjvcqiboyfiokaqemzcfxjwneptvhbikbcfdcyaremij"))){
System.out.println("TenKLOC17 - TenKLOCInterface2Method0- LineInMethod: 45");
}
}
for(int i = 0; i < 1; i++){
 if( (((var1*(short)(28396))>=(var1-(short)(22106)))&&((var1-(short)(11859))>=(var1-(short)(14351))))){
f2 = new TenKLOC0();
}
}
if( ((((((var0+"sosgedmzvxegigdhvzvavjloqimpgewvscjubsxdnlaql")+(var0+"roribzqwfmtdwwnqzffzssjmycmh"))==(var0+"swpfwacvifgfyvfqrqyuqjlfarvuagnrxxbxmfbzowanctuaqusymdevywmrkrpzzhyochxxtu"))||(((((var0+"gounwrl")+(var0+"kjoqdmzecqquxoydyhatmfoqxpqzolidwq"))+(var0+"bluagqxjahvdinvefhedpeelmhcsyqruvxwdwixjodgxyttmedhfuvltsirjmciowfzizsrh"))+(var0+"avxc"))!=(var0+"dmsp")))&&(((var0+"dokyzuaeb")+(var0+"hlegfatgpzpcojk"))!=((var0+"imfzqrpdwupywsmeagwgxdchgcjooeimgxwkdj")+(var0+"oahrlixhwivyf"))))||((var0+"xrsrskfkoudpdetzrfnzdbjzgwieneebnsadvetqwmgfb")!=((var0+"bagprcbvhyzbsjwnhqminzeeebbijzjecn")+(var0+"owdjzzzyahrooezzfmuzdssjybsxxiakzdgchxddnyxjlilcgxkhupdzkfkaxxlfbvrkjqfrlrq"))))){
var1 = (short)((var1/(short)(26904))*(var1-(short)(1780)));
}
return (short)var1;

}

public short TenKLOC17method0(short var0, byte var1, String var2){
 TenKLOC17 classObj = new TenKLOC17();
for(int i = 0; i < 5; i++){
 f2 = new TenKLOC0();
}
if( ((var0-(short)(11647))<((var0+(short)(27049))+((var0+(short)(31217))+(var0+(short)(30915)))))){
var2 = "dwypxqtcnqlqbpliorvsakmwrxulossczyjrtzuzvwsqqenudtadompwgwibqmevqrjlibnvlgrvwpuftwsetcwkgvndfagn";
}
for(int i = 0; i < 2; i++){
 if( ((((var0-(short)(22242))<=(var0+(short)(8619)))||((var0-(short)(21183))<=((var0+(short)(48))/(short)(31552))))&&((var0%(short)(8636))>=((var0+(short)(18270))+(var0*(short)(13732)))))){
if( (((var2+"zkmwndcceniqldasybdbtgpcmoqnsneopysnzwxyly")+(var2+"vkrqboygcmjnstwslvtqgkmamyrtjtyuuxkaddqdjqxeylzlineipiccicegk"))!=((var2+"kfeobblmcgvyrwspnhlqpgqmpcozd")+(var2+"tmsldcsfjljmdioyqqzhapxjterykocdckokyabkiypbahdnbnhjlrff")))){
f2 = new TenKLOC0();
}
}
}
if(((((var0+(short)(32517))>(var0-(short)(12952)))&&(((((var0+(short)(18467))-(var0*(short)(28077)))<(var0*(short)(30247)))&&((var0*(short)(2951))>(var0*(short)(11290))))&&(((var0+(short)(30256))-(var0/(short)(32369)))<=(var0%(short)(15049)))))||((var0+(short)(21437))>(var0/(short)(26815))))){
System.out.println("TenKLOC17 - TenKLOC17method0- LineInMethod: 17");
}
else{
 f0[100] = (int)(((int)(602)+(int)(742))*(((int)(539)%(int)(695))%(int)(597)));
}
if( ((var1*(byte)(-99))==(var1%(byte)(120)))){
var2 = (String)(var2+"jijbtdbjearvgjxkhalcibgehqzyfwghkngwknjeqpemmnmzkqyoybnogkpkg");
}
if( ((var0*(short)(28350))<=((var0/(short)(3432))+(((var0+(short)(12229))%(short)(21969))*(var0+(short)(567)))))){
if( ((var2+"vyrwmheqyksdwrbsublnjvscrnjawpocfylfwfnjcfvfeninqrmzklggkptsvwysybojvafadnrbxwaawdzkxilku")==(var2+"mgwyttlpokdlcnozryczhaymyeymwhjbxnynodhwdhgcrrhtuttuwroyycbwwbkrdrfeufpthhslmdznuvqq"))){
f2 = new TenKLOC0();
}
}
for(int i = 0; i < 1; i++){
 if( (((var0*(short)(25560))%(short)(947))<(((var0*(short)(18116))+(var0*(short)(8808)))*((var0*(short)(17870))+(var0/(short)(3143)))))){
System.out.println("TenKLOC17 - TenKLOC17method0- LineInMethod: 34");
}
}
if( ((var0-(short)(6298))<(var0/(short)(21911)))){
f4[68] = (long)(((long)(237)/(long)(108))%(long)(229));
}
if(((var2+"mrnmxaeqguepkdntmfhaduzeqsautpysevzinffhbfsacegnmfvgleyhubedqmvawmvcfmagayscbw")!=((var2+"eepiynawvxfwvdrmoxrldrdskbgoxuvym")+(var2+"fbcryqadxhzhgboezqnnrjcxtlhnuqapgfoveuudvqsgdeddtikyidyvylchvrjvatympykyvykoihqfhpxjyxzl")))){
System.out.println("TenKLOC17 - TenKLOC17method0- LineInMethod: 42");
}
else{
 var1 = (byte)(((var1*(byte)(-119))/(byte)(-118))/(byte)(-10));
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC17 - TenKLOC17method0- LineInMethod: 50");
}
if(((((var2+"isgzjrbstmeghtihowcds")+((var2+"qjocponwdrdfj")+(var2+"hhfblfnhpfcdakwriquqnolehoyhldijkmsffiaafivhrggawcpghtlzildkcefvxmrqaqwlhgzrmetihcverwugbrgqhvanx")))+(var2+"wxsseibzywiftpgxhzyhqkotzrnrsvkhthgcffyadhgjargupcigjhxfmkuhs"))!=((var2+"ibarmasbsaxeddghrllyywwrevvtujtvdm")+((var2+"augrwkgecoyjzadnshqbotloefwsatrmmjvxwfdspipmktbqvnwfqmbaqxphsjvl")+(((var2+"kayjpwutkxvdwkqkvqd")+(var2+"juasslttgzdbmvtptwis"))+(var2+"iytswagtnmeaiuxiivnbglmlupeyltlpiwrilibhjivnxhuiqrq")))))){
f4[45] = (long)((f4[46]*f4[41])*(((long)(387)-(long)(463))+((long)(100)+(long)(712))));
}
else{
 var0 = (short)((var0*(short)(13316))/(short)(3388));
}
return (short)var0;

}

public short TenKLOC17method1(long var0, char var1, TenKLOC27 var2){
 TenKLOC17 classObj = new TenKLOC17();
if( ((((var1+'m')%'j')*(var1*'y'))>=(var1*'q'))){
f2 = new TenKLOC0();
f2.TenKLOC0method3("qeqbwppurnidiqxyloccys",(int)(455),null,(double)(0.23150899847328454));
}
for(int i = 0; i < 8; i++){
 if( ((var0+(long)(409))>=(var0*(long)(574)))){
if( (((f4[51]*f4[60])==(f4[21]+f4[69]))||((var0+(long)(328))<=(((var0/(long)(381))-(var0*(long)(42)))*(var0-(long)(269)))))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 10");
}
}
}
if((((var1+'v')<(var1%'y'))||(((var1+'w')+(var1/'g'))<(var1-'s')))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 18");
}
else{
 var2 = new TenKLOC27();
}
if(((var1%'i')<(var1-'e'))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 32");
}
if( ((var1-'c')>(var1/'e'))){
if( ((((var0+(long)(447))+(var0%(long)(241)))>=((var0+(long)(468))*(var0-(long)(272))))&&(((var0*(long)(305))*(var0-(long)(310)))!=(var0/(long)(85))))){
f4[30] = (long)(var0/(long)(148));
}
}
if( ((var1%'i')>((var1*'l')+(var1-'i')))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 41");
}
if((((var0*(long)(283))-(var0/(long)(453)))>=(var0*(long)(348)))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 47");
}
else{
 System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 49");
}
if( ((var0+(long)(263))<((var0*(long)(617))*((var0*(long)(528))-((var0+(long)(381))-(var0*(long)(514))))))){
System.out.println("TenKLOC17 - TenKLOC17method1- LineInMethod: 55");
}
return (short)(short)(19640);

}

public static float TenKLOC17method2(float var0, byte var1, short var2, short var3, double var4, long var5){
 TenKLOC17 classObj = new TenKLOC17();
if(((var3+var2)<=(var3-var2))){
var4 = (double)((var4+(double)(0.5331312699036991))/(double)(0.9009086434600705));
}
else{
 f3 = (float)(var0-(float)(0.7325888));
}
for(int i = 0; i < 9; i++){
 f5[66] = (char)(('o'*'r')%'c');
}
if((((var5*(long)(181))*(var5+(long)(648)))<=(var5+(long)(628)))){
System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 14");
}
else{
 f3 = (float)(var0*(float)(0.40960532));
}
if( (((var2-(short)(3026))<((((var2+(short)(20119))+(var3*var2))/(short)(24223))/(short)(15194)))||((var3*(short)(13416))==(var3+(short)(16592))))){
if( ((((var4*(double)(0.3935018124391375))+(var4/(double)(0.9545532744019866)))-(var4*(double)(0.22356957458694016)))==(var4*(double)(0.30397794422680213)))){
System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 23");
}
}
if( ((var3/(short)(24637))!=((var3/(short)(15367))*((var2%(short)(15346))*(var3+var2))))){
if( (((var4+(double)(0.3404843102877855))+(var4-(double)(0.8078337004602308)))>=(var4+(double)(0.6959537472327229)))){
classObj.f2 = new TenKLOC0();
classObj.f2.TenKLOC0method2(var3,var4,var5);
}
}
if((((var3+var2)<=(var3/(short)(10880)))&&(((var3/(short)(12223))-(var2*(short)(5513)))>(var3-var2)))){
System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 36");
}
else{
 System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 39");
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 44");
}
for(int i = 0; i < 0; i++){
 f3 = (float)(f1[133]*f1[104]);
}
for(int i = 0; i < 3; i++){
 if( ((var3-(short)(17306))!=(var3+var2))){
System.out.println("TenKLOC17 - TenKLOC17method2- LineInMethod: 53");
}
}
return (float)var0;

}

public String TenKLOC17method3(short var0, TenKLOC14 var1, long var2, short var3, long var4){
 TenKLOC17 classObj = new TenKLOC17();
if(((f4[21]-f4[21])<(var4/(long)(477)))){
f2 = new TenKLOC0();
f2.TenKLOC0method3("auajbzuhfloza",(int)(271),null,(double)(0.5901202134329793));
}
else{
 var2 = (long)(((f4[12]%(long)(611))+(f4[53]-f4[10]))+(var4-var2));
}
if((((var0-var3)+(var3-var0))<=(var3*var0))){
f4[55] = (long)((var4-(long)(759))*(f4[59]-f4[0]));
}
else{
 System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 12");
}
if( (((var4+var2)/(long)(95))>=(var4+(long)(257)))){
if( ((((var0-(short)(12010))/(short)(10139))-(var0+var3))==(var3/(short)(19820)))){
if( ((((var3-(short)(18094))+(var3*(short)(31585)))<((var0%(short)(25443))/(short)(10182)))&&(((var3*(short)(26564))*(var3+(short)(1863)))>=((var0/(short)(12518))-((var0*(short)(22828))-(var0*var3)))))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 23");
}
}
}
if( ((var3/(short)(12446))>=(var0-(short)(12799)))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 28");
}
if( ((var0+var3)<(var3*(short)(24510)))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 34");
}
if( ((var2%(long)(636))<=(var4+var2))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 38");
}
for(int i = 0; i < 2; i++){
 System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 45");
}
if(((var3*var0)!=(var3+(short)(22944)))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 50");
}
else{
 var4 = (long)(((var2-var4)+(var4-(long)(155)))-(var4/(long)(179)));
}
if(((var4%(long)(336))<=(var4-var2))){
System.out.println("TenKLOC17 - TenKLOC17method3- LineInMethod: 57");
}
else{
 var2 = (long)(var2+(long)(724));
}
return (String)"mewsyrdxerjrnrkwribt";

}

public double TenKLOC17method4(short var0, TenKLOC17 var1, short var2, char var3, double var4){
 TenKLOC17 classObj = new TenKLOC17();
if(((((var0*var2)>=(var0*(short)(32106)))||((var0+(short)(19469))==(var0+var2)))&&((var2/(short)(12724))<(var0-(short)(17916))))){
System.out.println("TenKLOC17 - TenKLOC17method4- LineInMethod: 5");
}
else{
 var4 = (double)((var4*(double)(0.6361501072501322))*(var4-(double)(0.7731235457572109)));
}
if(((var3%'f')!=(var3%'b'))){
f2 = new TenKLOC0();
}
else{
 var1 = new TenKLOC17();
var4 = var1.TenKLOC17method4(var0,var1,var2,var3,var4);

}
for(int i = 0; i < 1; i++){
 if( (((var2*(short)(1525))-(var0%(short)(6527)))!=((var0-var2)*(var2/(short)(24339))))){
System.out.println("TenKLOC17 - TenKLOC17method4- LineInMethod: 17");
}
}
if( ((var0-(short)(8361))>(var2+var0))){
var4 = (double)((var4+(double)(0.9888421581130237))*(var4*(double)(0.07479308276261398)));
}
for(int i = 0; i < 2; i++){
 if( ((var4-(double)(0.8107180080736872))>=(var4%(double)(0.2537944216446436)))){
if( (((var3*'h')*(var3+'a'))>(var3%'x'))){
System.out.println("TenKLOC17 - TenKLOC17method4- LineInMethod: 29");
}
}
}
if(((var3*'s')<=(var3-'o'))){
System.out.println("TenKLOC17 - TenKLOC17method4- LineInMethod: 35");
}
else{
 f2 = new TenKLOC0();
}
for(int i = 0; i < 6; i++){
 if( (((((var3%'v')*(var3+'x'))+(var3-'t'))!=(var3-'q'))&&((var3/'b')>=(var3+'k')))){
f0[3] = (int)((int)(670)*(int)(574));
}
}
for(int i = 0; i < 4; i++){
 if( ((var4/(double)(0.9525930523039977))>=(var4-(double)(0.4349920907999112)))){
if( ((var4%(double)(0.41059029359943655))>((var4+(double)(0.2947687721972322))+((var4/(double)(0.7154462825683049))-(var4/(double)(0.4049573800243137)))))){
System.out.println("TenKLOC17 - TenKLOC17method4- LineInMethod: 52");
}
}
}
return (double)var4;

}


public static void main(String args[]){
TenKLOC17 obj = new TenKLOC17();
obj.TenKLOCInterface2Method0("sahqyqcsooelkpestrolqcsyevxdgdirasiwagdagmokuogywqmltrhervqowztfgxuxct",(short)(22207),new TenKLOC7());
obj.TenKLOC17method0((short)(7520),(byte)(-9),"qeonuwaeopzzeytekiinhjkhrkgvnwerubucgqusexzbktytqdgqxldyoybkzdqwmfuyesxtbdquizelvfgkcjzdqvfdocwlejeje");
obj.TenKLOC17method1((long)(502),'t',new TenKLOC27());
TenKLOC17method2((float)(0.6805685),(byte)(-54),(short)(6681),(short)(30493),(double)(0.17273913154395093),(long)(507));
obj.TenKLOC17method3((short)(29090),new TenKLOC14(),(long)(126),(short)(20218),(long)(564));
obj.TenKLOC17method4((short)(22557),new TenKLOC17(),(short)(10486),'d',(double)(0.8993586864666727));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC17 obj = new TenKLOC17();
obj.TenKLOCInterface2Method0("avkbrbyvntjaksmhankbzziekbaocpsltnkdnqsoaskytqccwiwurf",(short)(14569),new TenKLOC7());
obj.TenKLOC17method0((short)(6581),(byte)(-1),"piyerfzrtfdonwwbhcbfxvpwipwxvdxmckbzfwlnmtyokhveoliwdniizzrnjatscjupptancemlmsfofzlbsq");
obj.TenKLOC17method1((long)(116),'b',new TenKLOC27());
TenKLOC17method2((float)(0.23121047),(byte)(53),(short)(10511),(short)(14327),(double)(0.6393501761901255),(long)(591));
obj.TenKLOC17method3((short)(24008),new TenKLOC14(),(long)(394),(short)(14892),(long)(281));
obj.TenKLOC17method4((short)(18881),new TenKLOC17(),(short)(23534),'p',(double)(0.8479201286580301));
}

}