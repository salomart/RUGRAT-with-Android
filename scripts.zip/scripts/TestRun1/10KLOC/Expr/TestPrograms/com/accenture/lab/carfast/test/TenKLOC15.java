package com.accenture.lab.carfast.test;


public class TenKLOC15 extends TenKLOC11 implements TenKLOCInterface1 {
TenKLOC8 f0;
static long f1;


public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 9; i++){
 if( ((var0*(int)(92))<=(var0/(int)(46)))){
if( (((var2-(short)(28215))==(var2/(short)(10222)))||(((var2-(short)(21133))<=(var2/(short)(29402)))||((var2%(short)(14006))>=((var2*(short)(18668))+(var2/(short)(2037))))))){
var0 = (int)(693);
}
}
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 9");
}
if((((var0+(int)(100))!=((var0+(int)(499))+(var0/(int)(640))))&&((var0%(int)(200))!=((var0*(int)(562))+(var0*(int)(762)))))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 19");
}
switch((var0-(int)(44))){
case 0:
System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 24");
 break;
case 1:
System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 30");
 break;
case 2:
System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 37");
 break;
case 3:
System.out.println("TenKLOC15 - TenKLOCInterface1Method0- LineInMethod: 43");
 break;
default :
var2 = (short)((var2+(short)(31380))-((var2*(short)(1880))*(var2+(short)(18374))));
}
return (short)var2;

}

public String TenKLOCInterface1Method1(int var0, byte var1, String var2){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 4; i++){
 if( ((var1+(byte)(36))<((var1-(byte)(107))-(var1*(byte)(13))))){
if( ((var0-(int)(713))==(var0+(int)(24)))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method1- LineInMethod: 7");
}
}
}
if( (((var1%(byte)(55))*(var1-(byte)(-114)))!=(var1%(byte)(-48)))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method1- LineInMethod: 14");
}
if( ((((var0*(int)(16))+((((var0+(int)(433))/(int)(555))-(var0+(int)(517)))%(int)(352)))%(int)(680))!=(var0+(int)(597)))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method1- LineInMethod: 20");
}
for(int i = 0; i < 9; i++){
 if( ((var0*(int)(559))!=(var0%(int)(366)))){
f0 = new TenKLOC8();
}
}
if( ((var2+"uunmhazxwolwqtdrmdiuphtshbqpsubrjpydfqygbeqfrbqtgcdipwxlzxdojbnwsdxeyjjnkmsofatcvrspzqgum")==(var2+"frelglzqxgltgpayukgvsfiiwdnydzrhjmjbrzxqnvsqawcllfqiafdnwgckwlugbbklv"))){
if( (((var1+(byte)(41))<(var1+(byte)(112)))&&(((var1*(byte)(81))%(byte)(-88))==(var1*(byte)(13))))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method1- LineInMethod: 33");
}
}
return (String)var2;

}

public Object TenKLOCInterface1Method2(double var0, byte var1, int var2){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 3; i++){
 if( ((var2+(int)(206))>((var2%(int)(762))-(var2*(int)(119))))){
if( ((var2+(int)(110))<(((((var2-(int)(26))*(var2+(int)(63)))*(var2/(int)(612)))/(int)(252))-(var2*(int)(98))))){
if( ((var1+(byte)(42))>(var1*(byte)(-114)))){
TenKLOC8.TenKLOC8method0(var1,'n',(long)(745),(short)(26932),(short)(5202));
}
}
}
}
if(((var2-(int)(187))<(var2-(int)(565)))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method2- LineInMethod: 14");
}
else{
 System.out.println("TenKLOC15 - TenKLOCInterface1Method2- LineInMethod: 19");
}
if( ((var1*(byte)(59))>=(var1+(byte)(8)))){
var2 = (int)((var2+(int)(164))-(var2+(int)(430)));
}
if( ((((var1+(byte)(29))>(var1*(byte)(78)))&&((((var1-(byte)(72))+(var1*(byte)(91)))/(byte)(-127))==(var1+(byte)(76))))&&(((var1*(byte)(-96))<(var1*(byte)(-100)))||((var1+(byte)(74))==(var1%(byte)(84)))))){
var1 = (byte)((var1+(byte)(28))*(var1-(byte)(122)));
}
switch((var2/(int)(505))){
case 0:
System.out.println("TenKLOC15 - TenKLOCInterface1Method2- LineInMethod: 31");
 break;
case 1:
f0 = new TenKLOC8();
 break;
case 2:
System.out.println("TenKLOC15 - TenKLOCInterface1Method2- LineInMethod: 40");
 break;
case 3:
System.out.println("TenKLOC15 - TenKLOCInterface1Method2- LineInMethod: 43");
 break;
case 4:
var1 = (byte)((var1%(byte)(39))+(var1*(byte)(66)));
 break;
default :
var0 = (double)((var0%(double)(0.46631988376160727))*((((var0*(double)(0.4796203487808339))-((var0*(double)(0.6871838661575619))%(double)(0.373111707626533)))+(var0-(double)(0.287568661316836)))*(var0/(double)(0.10554295872277342))));
}
return (Object)null;

}

public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 7; i++){
 var2 = (int)(((((var2%(int)(173))*(var2-(int)(510)))+((var2-(int)(129))/(int)(409)))+(var2*(int)(483)))+(var2-(int)(546)));
}
if( (((var1+(float)(0.55649805))>((var1+(float)(0.24431068))+(var1*(float)(0.40690792))))&&((var1%(float)(0.14703959))<=(var1*(float)(0.5530726))))){
if( ((var2+(int)(441))!=(var2-(int)(670)))){
if( (((var2*(int)(669))>(var2%(int)(294)))||((((var2+(int)(260))>(var2*(int)(315)))&&(((((var2+(int)(347))*(var2-(int)(556)))==(var2+(int)(561)))&&(((((var2+(int)(263))-(var2+(int)(357)))%(int)(218))%(int)(406))!=(var2*(int)(534))))&&(((var2/(int)(502))>=(var2*(int)(413)))&&((var2-(int)(504))>=(var2/(int)(477))))))&&((var2-(int)(163))<(var2-(int)(138)))))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method3- LineInMethod: 11");
}
}
}
if(((var2*(int)(616))>(var2%(int)(2)))){
var2 = (int)(var2+(int)(679));
}
else{
 System.out.println("TenKLOC15 - TenKLOCInterface1Method3- LineInMethod: 21");
}
if( ((var2*(int)(518))<(var2*(int)(411)))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method3- LineInMethod: 28");
}
if( (((var1*(float)(0.77263564))<=(var1%(float)(0.18642253)))&&((var1*(float)(0.49624866))<(var1%(float)(0.16730958))))){
System.out.println("TenKLOC15 - TenKLOCInterface1Method3- LineInMethod: 31");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC15 - TenKLOCInterface1Method3- LineInMethod: 38");
}
return (double)(double)(0.3595218426397836);

}

public byte TenKLOC15method0(byte var0, byte var1, long var2, String var3, int var4){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC15 - TenKLOC15method0- LineInMethod: 3");
}
switch((var4-(int)(367))){
case 0:
var0 = TenKLOC8.TenKLOC8method0(var1,'q',var2,(short)(28032),(short)(29317));

 break;
case 1:
System.out.println("TenKLOC15 - TenKLOC15method0- LineInMethod: 12");
 break;
case 2:
System.out.println("TenKLOC15 - TenKLOC15method0- LineInMethod: 16");
 break;
case 3:
System.out.println("TenKLOC15 - TenKLOC15method0- LineInMethod: 22");
 break;
default :
System.out.println("TenKLOC15 - TenKLOC15method0- LineInMethod: 25");
}
if( (((var2+(long)(277))+(var2*(long)(342)))==(var2*(long)(608)))){
if( ((((var3+"ochfkf")+((var3+"sylswtkkomhihztvifrkuysdw")+(var3+"yozlcmhmavesjfgubrzhuqvmpucybbdurttzzlpvzniliiontcktkoqyxjxehdaizvcxtsztqwopkzvmzswkotcxomj")))==(var3+"quwohojrpcgsrq"))&&((var3+"fuoisqytrujvhlxjldjprunnhurwyvcfedmhiyvrkjethxjpvi")!=(var3+"ftbuqdontfrxgumlgzpcgj")))){
f0 = new TenKLOC8();
}
}
for(int i = 0; i < 8; i++){
 f0 = new TenKLOC8();
}
return (byte)var0;

}

public float TenKLOC15method1(float var0, float var1, long var2, double var3, int var4, int var5){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 5; i++){
 if( ((((var2+(long)(747))!=((var2+(long)(306))-((var2*(long)(388))-(var2*(long)(588)))))||((var2-(long)(171))<(var2-(long)(95))))&&((var2%(long)(62))==(var2*(long)(482))))){
if( ((((var4+var5)>=(var4+(int)(297)))&&((var5+(int)(186))>((var4%(int)(554))-(var5-var4))))&&((((((var4/(int)(77))<(var4+(int)(636)))&&((var4%(int)(497))<=(var4*(int)(428))))||(((var5+(int)(536))!=(var5+var4))||((((var5+(int)(452))-(var4*(int)(103)))*(var5+var4))<=((var5*(int)(694))%(int)(628)))))&&((var5+var4)!=(var4+var5)))&&((var5*var4)>=(var5/(int)(236)))))){
System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 7");
}
}
}
if(((var5-var4)==(var4-var5))){
var1 = (float)(0.7990634);
}
else{
 System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 16");
}
switch(((var4-(int)(135))+(var5-(int)(99)))){
case 0:
System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 20");
 break;
case 1:
System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 23");
 break;
case 2:
System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 29");
 break;
case 3:
System.out.println("TenKLOC15 - TenKLOC15method1- LineInMethod: 33");
 break;
default :
f0 = new TenKLOC8();
}
return (float)var1;

}

public byte TenKLOC15method2(int var0, float var1, double var2){
 TenKLOC15 classObj = new TenKLOC15();
switch((var0-(int)(517))){
case 0:
System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 3");
 break;
case 1:
f0 = new TenKLOC8();
 break;
case 2:
f0 = new TenKLOC8();
 break;
default :
f0 = new TenKLOC8();
f0.TenKLOC8method4((short)(27921),'i','m');
}
for(int i = 0; i < 2; i++){
 System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 16");
}
switch((var0-(int)(704))){
case 0:
f0 = new TenKLOC8();
 break;
case 1:
System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 26");
 break;
case 2:
System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 31");
 break;
case 3:
System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 36");
 break;
default :
System.out.println("TenKLOC15 - TenKLOC15method2- LineInMethod: 41");
}
return (byte)(byte)(-98);

}

public short TenKLOC15method3(short var0, byte var1, float var2){
 TenKLOC15 classObj = new TenKLOC15();
if( (((var2-(float)(0.14466846))<=(var2/(float)(0.80714023)))||((var2-(float)(0.28421474))>=(var2/(float)(0.16937506))))){
System.out.println("TenKLOC15 - TenKLOC15method3- LineInMethod: 3");
}
if(((var2*(float)(0.51073664))>=(var2/(float)(0.19765705)))){
f0 = new TenKLOC8();
}
else{
 System.out.println("TenKLOC15 - TenKLOC15method3- LineInMethod: 9");
}
if( ((var0-(short)(534))<=(var0%(short)(2425)))){
f0 = new TenKLOC8();
}
for(int i = 0; i < 0; i++){
 if( (((var0%(short)(14450))*(var0-(short)(23500)))<=((var0/(short)(2621))/(short)(6681)))){
var1 = (byte)((var1+(byte)(-96))%(byte)(-30));
}
}
if((((var1+(byte)(124))+(var1*(byte)(11)))>=(var1-(byte)(-91)))){
var2 = (float)(0.04828173);
}
else{
 System.out.println("TenKLOC15 - TenKLOC15method3- LineInMethod: 25");
}
if( ((((var0-(short)(28578))%(short)(3049))==(var0*(short)(21873)))||((var0*(short)(19583))<=(var0-(short)(62))))){
System.out.println("TenKLOC15 - TenKLOC15method3- LineInMethod: 29");
}
for(int i = 0; i < 4; i++){
 if( (((var1-(byte)(18))-(var1/(byte)(52)))!=(var1-(byte)(-68)))){
if( ((var0-(short)(18544))<(((var0*(short)(16452))+(var0*(short)(12181)))+(((var0*(short)(29368))+(var0%(short)(4787)))*(var0-(short)(13696)))))){
if( ((var1*(byte)(-21))>(var1*(byte)(-51)))){
System.out.println("TenKLOC15 - TenKLOC15method3- LineInMethod: 41");
}
}
}
}
return (short)var0;

}

public static byte TenKLOC11method0(String var0, String var1, float var2){
 TenKLOC15 classObj = new TenKLOC15();
for(int i = 0; i < 2; i++){
 if( ((var0+var1)==(var1+"qyvpim"))){
if( ((var1+"bgnitzmbewdhkeqwxkzynucimofdcckqvyttddzwbasjsobbpjwrbelwzeolicmcwdxqfzkjmvbkmzkjrxswlislmlfyasa")!=((var0+var1)+((((var1+"hcjmscqsjiptabdiayafmafehepjovzbttwmncirwnayzbmtqyydjuhzqrkuttbbeucaxuijdhcnkwfdexkweaxdmaeeowlhblr")+(var0+"fjocepsxoptmay"))+(var1+"bqoxfryjyysoktyoqcpnxrbfkuksjyihqmhcsyjhklbxzribqghbxyonokiodygzgglpzrckp"))+(var1+"dpwlehinyu"))))){
if( ((var0+var1)==(var1+var0))){
System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 9");
}
}
}
}
if(((var0+"kzilnsmvwsytmpvwhyfuucevouazddckpsjlafydljuguelbx")!=(var0+var1))){
var2 = (float)((var2%(float)(0.23299152))*(var2+(float)(0.5481422)));
}
else{
 TenKLOC8.TenKLOC8method3((long)(240),'c',(int)(606));
}
for(int i = 0; i < 2; i++){
 f1 = (long)(((long)(541)/(long)(155))-((long)(389)-(long)(332)));
}
if(((var2*(float)(0.0106034875))<=(var2/(float)(0.47899216)))){
var2 = (float)((var2*(float)(0.21580577))+(var2-(float)(0.16170579)));
}
else{
 System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 24");
}
if( ((var0+"nsibgzllzwdknvfrklzyjtifuyyhqpykvhedxdgpbbddhtnrhecnasdzwjtmsibkfcnebmyixmprohfyeklqgycoijdcsi")==((var0+"kawqecbnbjganjvlgeunqj")+(((((var0+var1)+(var0+"wcgdpxwzlsarfzhm"))+((var1+"wwsugkrahbyolxmppnvwimzglmdmmdgtm")+(var1+"nkkcfqyomkzisxifytlqgsgwhnwyrhnizzilxgzqqimtewnodmcazfwpdpoobhghincpkbkcxccaztkuhmzecvznbqodiihus")))+(var0+"wvuvqoerqgqrhisvdefmprsmlbloosucfzxzmykbvddctzpkpwegyfxxijvumutalfoktwytbjzovwasiibz"))+(var1+"ktfglxjusknabxebvuyoepzqmfcsbsxijig"))))){
System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 29");
}
if( ((var1+"orvonkaavqlcugicitnjyypzkjhh")==(var0+var1))){
System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 32");
}
if(((var2-(float)(0.2721765))<=(var2*(float)(0.92639256)))){
System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 40");
}
else{
 System.out.println("TenKLOC15 - TenKLOC11method0- LineInMethod: 44");
}
return (byte)(byte)(80);

}


public static void main(String args[]){
TenKLOC15 obj = new TenKLOC15();
obj.TenKLOCInterface1Method0((int)(621),new TenKLOC29(),(short)(16590));
obj.TenKLOCInterface1Method1((int)(736),(byte)(80),"lxvfaeoyhtltpguhpnbiorodtmrvpyjqfqzejavxdzxxgcmjuutnrtolufohowsyeofogebpfsarodabend");
obj.TenKLOCInterface1Method2((double)(0.40951824043784213),(byte)(61),(int)(711));
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.7458426),(int)(629));
obj.TenKLOC15method0((byte)(-115),(byte)(-63),(long)(394),"ckfvjospkvdvcfnkaukcqugkzclzbzuibmrobxfmg",(int)(411));
obj.TenKLOC15method1((float)(0.14363682),(float)(0.19447982),(long)(488),(double)(0.1798852056464012),(int)(275),(int)(279));
obj.TenKLOC15method2((int)(636),(float)(0.9278822),(double)(0.9257288030105182));
obj.TenKLOC15method3((short)(10816),(byte)(-15),(float)(0.83390075));
TenKLOC11method0("bcxfbvrtizgjpaewkmacizdbebmyqhviqov","rpjphrtgsjcerzsfnokudutoxcjuiixkjxcxhaeadkmomckxzmegqnodg",(float)(0.89172035));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC15 obj = new TenKLOC15();
obj.TenKLOCInterface1Method0(i0,new TenKLOC29(),(short)(20220));
obj.TenKLOCInterface1Method1(i0,(byte)(-28),"jkobfizvtcjhxtxtmkaqfsgyxptgty");
obj.TenKLOCInterface1Method2((double)(0.9570208570089013),(byte)(-73),i5);
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.49211472),i1);
obj.TenKLOC15method0((byte)(-82),(byte)(-48),(long)(715),"eofrirtopshbgunzvhfeyaiceevbnngdjslhdnancbpvqjbkvtovmaasecrgs",i4);
obj.TenKLOC15method1((float)(0.36542046),(float)(0.71084964),(long)(211),(double)(0.8618909609512189),i1,i2);
obj.TenKLOC15method2(i2,(float)(0.6712083),(double)(0.9864486480424771));
obj.TenKLOC15method3((short)(16709),(byte)(-46),(float)(0.7227069));
TenKLOC11method0("ngutexpltotzomosxqssbujvgbixgwlsvptdcznlicpztlbfuytwfwqpgubusbonjaofinqracxbdrirhgtcjunizisviqabtq","kxmglyrvzmfauevnyjdkjoptltedovmd",(float)(0.5004802));
}

}