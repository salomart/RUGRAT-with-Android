package com.accenture.lab.carfast.test;


public class TenKLOC3 extends TenKLOC26 implements TenKLOCInterface4 {
static char f0;
static float f1;
static char[] f2= new char[36];
static String f3;
static int f4;


public long TenKLOCInterface4Method0(int var0, long var1, short var2, String var3, double var4, double var5){
 TenKLOC3 classObj = new TenKLOC3();
if(((((var2%(short)(28470))*(var2*(short)(32220)))-((var2+(short)(14899))+(var2+(short)(23920))))>=(var2+(short)(19240)))){
System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 5");
}
else{
 System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 8");
}
switch((var0*(int)(196))){
case 0:
var3 = (String)(var3+"szgmybwykvzjifmamzowxakhflvfbgsrrjxusufrsxjxzeekxlpskrrrkacfmczhoceqkdyohwofdzxcnb");
 break;
case 1:
var0 = (int)((var0*(int)(480))*(var0*(int)(35)));
 break;
case 2:
var4 = (double)(0.7843958214916733);
 break;
case 3:
System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 23");
 break;
case 4:
var2 = (short)(((var2+(short)(1928))%(short)(17938))-(var2/(short)(8583)));
 break;
case 5:
System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 33");
 break;
case 6:
System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 37");
 break;
default :
System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 41");
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC3 - TenKLOCInterface4Method0- LineInMethod: 47");
}
return (long)var1;

}

public double TenKLOCInterface4Method1(int var0, int var1, int var2){
 TenKLOC3 classObj = new TenKLOC3();
for(int i = 0; i < 0; i++){
 if( (((var2*(int)(55))!=(var0%(int)(233)))&&((var0-(int)(762))>(var1-var2)))){
if( (((var1+var2)+(var2/(int)(412)))==((var2*var0)-(var2%(int)(71))))){
if( (((var0*(int)(123))-(var0/(int)(40)))>(var2-(int)(760)))){
}
}
}
}
if( ((var1*var0)!=(var1-var0))){
System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 11");
}
switch(((var1+(int)(337))/(int)(240))){
case 0:
System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 16");
 break;
case 1:
var1 = (int)((var2*var1)+(var0+var1));
 break;
case 2:
System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 26");
 break;
default :
System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 31");
}
if( ((var2+(int)(53))<=(var1%(int)(300)))){
var2 = (int)((var0+var1)*(var1%(int)(275)));
}
if( ((var0/(int)(156))<=(var1-(int)(693)))){
System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 37");
}
if(((var1*var2)<(var0+var2))){
var1 = (int)(var0-var1);
}
else{
 System.out.println("TenKLOC3 - TenKLOCInterface4Method1- LineInMethod: 44");
}
if(((var1+(int)(14))<=((var2-var1)*(var1-var2)))){
var1 = (int)(var1+var0);
}
else{
 var1 = (int)((var2-var1)/(int)(218));
}
return (double)(double)(0.05850835121403175);

}

public static short TenKLOC3method0(short var0, TenKLOC12 var1, double var2, byte var3){
 TenKLOC3 classObj = new TenKLOC3();
if(((var0*(short)(8947))>(var0%(short)(21085)))){
System.out.println("TenKLOC3 - TenKLOC3method0- LineInMethod: 5");
}
else{
 var0 = (short)((var0+(short)(18231))-((var0-(short)(8867))*(var0-(short)(21161))));
}
if((((var2*(double)(0.7935300550838226))%(double)(0.8147786828744397))!=(var2%(double)(0.2532543310508608)))){
System.out.println("TenKLOC3 - TenKLOC3method0- LineInMethod: 15");
}
else{
 System.out.println("TenKLOC3 - TenKLOC3method0- LineInMethod: 17");
}
for(int i = 0; i < 6; i++){
 if( (((var0-(short)(4011))-((var0+(short)(113))*(var0%(short)(3659))))>(var0*(short)(6352)))){
if( ((var2*(double)(0.5614351431144446))==(var2+(double)(0.3588596297223988)))){
System.out.println("TenKLOC3 - TenKLOC3method0- LineInMethod: 27");
}
}
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC3 - TenKLOC3method0- LineInMethod: 32");
}
for(int i = 0; i < 2; i++){
 var2 = (double)((var2%(double)(0.4133789864043135))-(((var2-(double)(0.40052527250690806))%(double)(0.8535523470026706))%(double)(0.294271103940985)));
}
if(((((var3-(byte)(40))*(var3*(byte)(29)))==(var3-(byte)(-64)))&&((((var3-(byte)(-112))==(var3*(byte)(13)))||((var3-(byte)(18))>=((var3-(byte)(-98))-(var3-(byte)(-26)))))&&(((var3-(byte)(29))/(byte)(-106))!=(var3-(byte)(-57)))))){
f2[16] = (char)((f2[22]%'g')+(((((('m'-'g')%'u')-('y'/'u'))%'d')/'f')/'b'));
}
else{
 var3 = (byte)((var3+(byte)(-71))*(var3-(byte)(-2)));
}
for(int i = 0; i < 9; i++){
 if( ((var0+(short)(26668))<(var0-(short)(4659)))){
var1 = new TenKLOC12();
var1.TenKLOCInterface1Method0((int)(84),null,var0);
}
}
return (short)var0;

}

public int TenKLOC3method1(int var0, long var1, TenKLOC2 var2){
 TenKLOC3 classObj = new TenKLOC3();
if( ((var1+(long)(629))<=((var1*(long)(647))-(var1-(long)(207))))){
if( ((var0%(int)(4))>=(var0-(int)(210)))){
if( (((var1*(long)(404))-(var1+(long)(21)))==(((var1+(long)(420))%(long)(327))-((var1/(long)(698))-(var1-(long)(220)))))){
var2 = new TenKLOC2();
}
}
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 10");
}
for(int i = 0; i < 6; i++){
 if( ((var1+(long)(576))<(var1+(long)(317)))){
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 19");
}
}
for(int i = 0; i < 5; i++){
 var0 = (int)(((var0%(int)(664))-(var0*(int)(215)))+(var0%(int)(54)));
}
if(((var1/(long)(415))>=(var1*(long)(242)))){
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 27");
}
else{
 var1 = (long)(var1/(long)(728));
}
for(int i = 0; i < 5; i++){
 if( (((var0%(int)(7))+(var0+(int)(234)))>(var0+(int)(747)))){
var2 = new TenKLOC2();
var2.TenKLOC2method0((short)(32082),"nvbmcxffmmsinprbzovghrrvudwcltbywrgbzo",(short)(17978));
}
}
switch((var0-(int)(709))){
case 0:
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 36");
 break;
case 1:
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 40");
 break;
case 2:
var1 = (long)((var1*(long)(572))-((var1*(long)(501))+(var1*(long)(588))));
 break;
case 3:
var1 = (long)(((var1*(long)(276))-(var1+(long)(549)))+(var1/(long)(253)));
 break;
case 4:
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 51");
 break;
case 5:
var1 = (long)((var1+(long)(701))+(var1-(long)(232)));
 break;
case 6:
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 60");
 break;
case 7:
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 63");
 break;
default :
System.out.println("TenKLOC3 - TenKLOC3method1- LineInMethod: 69");
}
return (int)var0;

}

public static long TenKLOC3method2(long var0, int var1, short var2){
 TenKLOC3 classObj = new TenKLOC3();
if(((var0/(long)(685))>(var0/(long)(649)))){
var0 = (long)((var0%(long)(761))+(var0-(long)(407)));
}
else{
 }
if( ((var2%(short)(3526))!=(var2-(short)(32393)))){
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 8");
}
if( ((var0+(long)(459))<(var0+(long)(433)))){
if( ((var1-(int)(693))<=((f4%(int)(169))+(f4+(int)(333))))){
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 15");
}
}
for(int i = 0; i < 2; i++){
 if( (((var2-(short)(15910))/(short)(17478))>((((var2/(short)(11454))%(short)(30646))-((var2/(short)(15734))%(short)(22310)))/(short)(17298)))){
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 24");
}
}
switch((var1*(int)(449))){
case 0:
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 31");
 break;
case 1:
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 37");
 break;
case 2:
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 41");
 break;
case 3:
f0 = (char)(('x'*'a')*(('b'+'p')%'f'));
 break;
case 4:
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 49");
 break;
default :
System.out.println("TenKLOC3 - TenKLOC3method2- LineInMethod: 53");
}
return (long)var0;

}

public static int TenKLOC3method3(float var0, long var1, byte var2, long var3, float var4){
 TenKLOC3 classObj = new TenKLOC3();
if( ((var4*(float)(0.61833566))==(var4+(float)(0.12896001)))){
if( ((var0*(float)(0.84871674))>=(var0-(float)(0.60851705)))){
if( ((f1/(float)(0.7736979))<(f1+(float)(0.6863275)))){
}
}
}
if((((var2+(byte)(-70))+(var2/(byte)(-23)))>=(var2*(byte)(-125)))){
System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 11");
}
else{
 System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 16");
}
if((((var2-(byte)(-108))<(var2+(byte)(77)))||((((var2+(byte)(7))/(byte)(33))>=(var2*(byte)(26)))||((var2-(byte)(-82))<=(var2%(byte)(106)))))){
System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 24");
}
else{
 System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 26");
}
if(((var1%(long)(262))<=((var1%(long)(378))%(long)(684)))){
System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 33");
}
else{
 var0 = (float)((var4/(float)(0.32830852))*(var4%(float)(0.20093459)));
}
if((((var0*(float)(0.26599878))<(f1%(float)(0.9172729)))&&((var4-var0)>=(var4+(float)(0.7062875))))){
System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 40");
}
else{
 var2 = (byte)((var2+(byte)(61))%(byte)(121));
}
if((((var3%(long)(402))!=(var3*(long)(25)))&&(((var3/(long)(294))%(long)(463))!=(var1-(long)(364))))){
System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 47");
}
else{
 System.out.println("TenKLOC3 - TenKLOC3method3- LineInMethod: 49");
}
return (int)(int)(372);

}

public static byte TenKLOC26method0(byte var0, byte var1, long var2, byte var3, double var4, double var5){
 TenKLOC3 classObj = new TenKLOC3();
for(int i = 0; i < 1; i++){
 if( ((var1-var3)==(var3+var0))){
if( ((var2*(long)(126))>(var2-(long)(35)))){
if( ((var4-var5)>=(var5*(double)(0.6318844114125447)))){
f3 = (String)((("zmhwkkygvuasdmrmligflgilrethywmjclmfjdnbayjptitepwamztjkgfukuabxikgvgeeekfuisrwskx"+"exhipljnvzvjtxppvacrrmwjdvmabdgswlh")+("tveaznmstbmggorcnjzdzaktrzydzpmglexkcpwhkpvdo"+"ubbikreyqfmd"))+("ldpvqwlmhncodgctajftrvrgkceoltgxkoskxigkkfnlsgkumzlsxyocfgojytrnvgirl"+"fiqiwqvweifsejqdhlxkmahcdbkwfqsdrbkgarmfoabjqxtqagv"));
}
}
}
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC3 - TenKLOC26method0- LineInMethod: 12");
}
if( ((var2+(long)(272))!=(var2-(long)(598)))){
var2 = (long)(271);
}
if( ((var3*var1)>=(((var3-var0)/(byte)(33))+(var0*(byte)(-74))))){
f1 = (float)((f1%(float)(0.5749852))+((float)(0.40541488)-(float)(0.65414655)));
}
for(int i = 0; i < 6; i++){
 if( ((var5*(double)(0.6978551407117857))>=(var5-var4))){
var5 = (double)((var4+(double)(0.27939575810290107))*(var4*(double)(0.8018399556365875)));
}
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC3 - TenKLOC26method0- LineInMethod: 26");
}
if( ((var3+(byte)(-55))<=(var1/(byte)(-119)))){
System.out.println("TenKLOC3 - TenKLOC26method0- LineInMethod: 33");
}
if((((var5+var4)-((var5/(double)(0.25369853659206354))-((var4-var5)%(double)(0.36789331336634146))))>=(var4*(double)(0.20948854886978918)))){
var3 = (byte)(((var3-(byte)(75))*(var3%(byte)(-108)))%(byte)(91));
}
else{
 System.out.println("TenKLOC3 - TenKLOC26method0- LineInMethod: 42");
}
for(int i = 0; i < 9; i++){
 if( ((var3+(byte)(-106))<((var3-var0)%(byte)(-47)))){
System.out.println("TenKLOC3 - TenKLOC26method0- LineInMethod: 51");
}
}
return (byte)var3;

}


public static void main(String args[]){
TenKLOC3 obj = new TenKLOC3();
obj.TenKLOCInterface4Method0((int)(388),(long)(466),(short)(7024),"aistlbvretewstmndrazjdbznzsejjhnhhvinilqfhkhaerkvynxhbftpfalyohaefphlcjdurznfo",(double)(0.7799956183629114),(double)(0.2541567578773811));
obj.TenKLOCInterface4Method1((int)(775),(int)(84),(int)(120));
TenKLOC3method0((short)(29953),new TenKLOC12(),(double)(0.7783476080358518),(byte)(-21));
obj.TenKLOC3method1((int)(569),(long)(262),new TenKLOC2());
TenKLOC3method2((long)(697),(int)(96),(short)(7729));
TenKLOC3method3((float)(0.13428593),(long)(190),(byte)(-82),(long)(404),(float)(0.80979025));
TenKLOC26method0((byte)(-81),(byte)(77),(long)(352),(byte)(20),(double)(0.558098436187485),(double)(0.0707795589361584));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC3 obj = new TenKLOC3();
obj.TenKLOCInterface4Method0(i5,(long)(133),(short)(6504),"ibvusctuhaldurrwydeiwnjiwulzzvqgufsiqefbowdrzziskdfxpbrfotcuvgu",(double)(0.4734833324142418),(double)(0.30381985477982065));
obj.TenKLOCInterface4Method1(i5,i4,i0);
TenKLOC3method0((short)(31821),new TenKLOC12(),(double)(0.10746342881485338),(byte)(32));
obj.TenKLOC3method1(i0,(long)(293),new TenKLOC2());
TenKLOC3method2((long)(94),i6,(short)(15780));
TenKLOC3method3((float)(0.68525547),(long)(702),(byte)(-68),(long)(276),(float)(0.4729156));
TenKLOC26method0((byte)(118),(byte)(41),(long)(503),(byte)(-15),(double)(0.3842768927372473),(double)(0.08382465353233715));
}

}