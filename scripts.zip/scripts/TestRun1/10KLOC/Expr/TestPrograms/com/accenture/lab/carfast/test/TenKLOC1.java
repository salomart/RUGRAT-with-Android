package com.accenture.lab.carfast.test;


public class TenKLOC1 {
char[] f0= new char[27];
short[] f1= new short[171];


public static short TenKLOC1method0(double var0, TenKLOC23 var1, float var2){
 TenKLOC1 classObj = new TenKLOC1();
if(((((var2-(float)(0.011671424))+(var2*(float)(0.75521076)))!=(var2-(float)(0.8568606)))&&((var2-(float)(0.66352266))!=(var2-(float)(0.013297737))))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 5");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 9");
}
if( ((((var0-(double)(0.47103699013973177))<=(var0/(double)(0.394061669147308)))&&((var0+(double)(0.9886295439495963))<=((var0-(double)(0.1708990108605688))*(var0-(double)(0.3492340385103827)))))&&((var0-(double)(0.9824702289587258))<=(var0+(double)(0.0762254313581332))))){
if( (((var0%(double)(0.231007701040867))*(((var0/(double)(0.7143707522904215))-((var0*(double)(0.9193042883599623))+(var0-(double)(0.027622387242207447))))/(double)(0.43775032879349907)))>(var0/(double)(0.06695178993701068)))){
if( ((var2-(float)(0.9142049))==(var2*(float)(0.0652886)))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 17");
}
}
}
if( ((var0*(double)(0.146847375137653))!=(var0*(double)(0.9245711050821795)))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 23");
}
if( (((((var0%(double)(0.7328737993042184))+(var0/(double)(0.8093009511942667)))+(var0+(double)(0.8369566185966084)))<(var0-(double)(0.48756086027311973)))&&((var0%(double)(0.001926169706359282))>=((var0*(double)(0.6082783971702358))*(var0+(double)(0.8962502841868257)))))){
var2 = (float)((var2*(float)(0.50331336))/(float)(0.054754674));
}
if( (((var2%(float)(0.8448795))!=(var2+(float)(0.7644069)))&&(((var2*(float)(0.07326192))==(var2%(float)(0.73711634)))||((var2%(float)(0.0496549))>=(((var2+(float)(0.20872283))/(float)(0.6248103))/(float)(0.09414345)))))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 32");
}
if((((var0+(double)(0.4326213782946259))<=(var0*(double)(0.7277518715785638)))&&((var0+(double)(0.7582741258891423))!=(var0-(double)(0.8033981345633253))))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 40");
}
else{
 TenKLOC23.TenKLOC23method3((long)(196),'o','p');
}
for(int i = 0; i < 7; i++){
 var0 = (double)(((var0/(double)(0.020750620460602498))%(double)(0.9338388814692872))+(var0*(double)(0.9852300199387268)));
}
if( ((var2+(float)(0.7454596))!=(var2+(float)(0.87478656)))){
var2 = (float)((((var2-(float)(0.51204675))*(var2*(float)(0.69095135)))-(var2-(float)(0.32554924)))-(var2+(float)(0.40955514)));
}
for(int i = 0; i < 1; i++){
 if( ((var0-(double)(0.5892124797559173))<(var0+(double)(0.9517659758162629)))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 53");
}
}
if( ((var2*(float)(0.801896))==(var2/(float)(0.92105347)))){
System.out.println("TenKLOC1 - TenKLOC1method0- LineInMethod: 57");
}
if( (((var2+(float)(0.3683362))/(float)(0.377133))==(var2%(float)(0.026934624)))){
var1 = new TenKLOC23();
}
for(int i = 0; i < 3; i++){
 if( (((var0-(double)(0.7891029616005405))!=((var0*(double)(0.17606577962207404))*(((var0+(double)(0.7545963209305547))-(var0/(double)(0.8999654203217121)))*(var0*(double)(0.9841812984526563)))))&&((var0+(double)(0.11048027804258986))==(var0*(double)(0.5707206131987607))))){
var2 = (float)((var2-(float)(0.44376457))-(var2+(float)(0.8037598)));
}
}
return (short)(short)(19389);

}

public static double TenKLOC1method1(char var0, char var1, TenKLOC16 var2){
 TenKLOC1 classObj = new TenKLOC1();
if(((var1/'o')>=(var1*var0))){
var0 = (char)((var1+var0)*(var0-var1));
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 6");
}
if( ((var0-var1)==(var1/'b'))){
if( ((var1*var0)<=(var0+var1))){
var1 = 'm';
}
}
for(int i = 0; i < 2; i++){
 System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 17");
}
if( ((var1/'m')!=(var1+var0))){
if( (((((var0/'g')+(var1%'a'))<=(var1%'v'))||((var0-var1)>=(var1%'a')))||((var0+'i')>=(var0+'z')))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 24");
}
}
if( (((((var1/'r')>=(var0+'k'))||((var0%'p')<=(var0*var1)))&&(((var1*'e')>(var0-var1))&&((((var1*'h')!=(var1*var0))&&(((var0-'d')%'x')<(var0+'u')))&&(((var0+var1)/'x')>=(var1/'y')))))||((var1*'b')!=(var0+'w')))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 29");
}
if(((var0-var1)>(var0+'z'))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 35");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 37");
}
if(((var0*'y')==(var1/'n'))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 44");
}
else{
 var0 = (char)((var0%'a')-((var0+'l')+(var1-var0)));
}
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 51");
}
if( ((var1*'s')<=(var1+'g'))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 56");
}
for(int i = 0; i < 8; i++){
 if( ((var0-var1)>=(var0-'y'))){
var1 = (char)((var0*'b')-(var0%'b'));
}
}
if(((((var0*'p')+((var0-'u')*(var1-'c')))<((var1*'l')+(var0+var1)))||((var1/'i')>=((var1%'a')+(var1-var0))))){
System.out.println("TenKLOC1 - TenKLOC1method1- LineInMethod: 69");
}
else{
 var2 = new TenKLOC16();
}
return (double)(double)(0.8299491709682477);

}

public static byte TenKLOC1method2(TenKLOC7 var0, short var1, byte var2, float var3, short var4){
 TenKLOC1 classObj = new TenKLOC1();
if( ((var2*(byte)(-37))>(((var2+(byte)(-87))+(var2/(byte)(103)))/(byte)(88)))){
if( ((((var4*(short)(26440))*(var1*(short)(12441)))+(var1-var4))==(var4*(short)(6757)))){
if( (((var1+(short)(20259))==(var4-var1))||(((var1-(short)(23068))*((var4+var1)/(short)(4715)))>(var1*var4)))){
System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 7");
}
}
}
for(int i = 0; i < 9; i++){
 if( ((var3-(float)(0.6167303))==(var3-(float)(0.6407131)))){
var4 = (short)(var1*(short)(28363));
}
}
if( ((((var2%(byte)(99))/(byte)(-81))<=(var2+(byte)(96)))||(((var2-(byte)(-16))+(var2*(byte)(62)))!=(var2+(byte)(58))))){
var0 = new TenKLOC7();
var0.TenKLOCInterface2Method0("sluvxvhklfnuxrxq",var4,var0);
}
if(((var2-(byte)(30))<=(var2-(byte)(-38)))){
System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 24");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 26");
}
if( ((var1*var4)>((var4*var1)+(short)(7513)))){
System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 32");
}
if( ((var3/(float)(0.6464325))!=(var3-(float)(0.116659224)))){
var1 = (short)((var4+(short)(6713))-(var4*var1));
}
if( ((var1%(short)(26834))<(var1+var4))){
var2 = (byte)((var2%(byte)(-92))*((var2/(byte)(97))*(var2-(byte)(114))));
}
for(int i = 0; i < 7; i++){
 if( (((var2+(byte)(-59))+((var2-(byte)(62))*(var2+(byte)(54))))<=((var2/(byte)(-25))*(((var2-(byte)(38))%(byte)(-35))*(var2+(byte)(-40)))))){
System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 46");
}
}
for(int i = 0; i < 3; i++){
 if( ((var2-(byte)(-49))<=((var2*(byte)(26))*(var2*(byte)(82))))){
var0 = new TenKLOC7();
}
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC1 - TenKLOC1method2- LineInMethod: 58");
}
if(((var1+(short)(6886))>(var1/(short)(12366)))){
var3 = (float)((var3-(float)(0.4212703))*(var3+(float)(0.94623476)));
}
else{
 var2 = (byte)(var2-(byte)(71));
}
return (byte)var2;

}

public Object TenKLOC1method3(double var0, short var1, byte var2){
 TenKLOC1 classObj = new TenKLOC1();
if((((var2+(byte)(-78))-((var2-(byte)(66))*(var2/(byte)(24))))<(var2+(byte)(-9)))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 5");
}
else{
 var0 = (double)(0.536418152716035);
}
if( ((var2+(byte)(-36))>=(var2/(byte)(-115)))){
if( ((var0*(double)(0.3682090041326541))<=(var0*(double)(0.43411231519349325)))){
var0 = (double)((var0/(double)(0.538635884631048))*(var0-(double)(0.049081027531365895)));
}
}
if(((var2+(byte)(121))<=(var2+(byte)(-22)))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 21");
}
if( (((var0%(double)(0.09653021688009511))==(var0/(double)(0.7084274358735878)))&&(((var0/(double)(0.9860221547461215))*(var0+(double)(0.5361161397469736)))>((var0+(double)(0.2015873315480965))-(var0/(double)(0.5060921223416829)))))){
if( ((var1+(short)(29355))<(var1/(short)(45)))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 28");
}
}
if(((((var2/(byte)(127))*(((var2*(byte)(24))-(var2%(byte)(-38)))-((var2-(byte)(113))+(var2+(byte)(1)))))-(var2+(byte)(98)))>=(var2*(byte)(113)))){
f1[46] = (short)(var1*(short)(26765));
}
else{
 f0[5] = (char)((('d'/'s')-('j'*'r'))*(('l'*'s')+('s'/'s')));
}
if( ((var0*(double)(0.8605309348900892))>((((var0+(double)(0.8073842311937374))+(var0-(double)(0.2649763967140233)))-(var0+(double)(0.7237870028728447)))/(double)(0.4703120107457939)))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 39");
}
if( (((var2-(byte)(55))<(var2+(byte)(45)))||(((var2-(byte)(-124))-(var2+(byte)(107)))>=(var2%(byte)(-60))))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 44");
}
if((((((f1[64]*f1[34])*(f1[61]/(short)(32177)))!=(f1[74]/(short)(20162)))||(((f1[79]%(short)(12893))*(f1[64]/(short)(15115)))<(f1[49]/(short)(24801))))&&((var1+(short)(9093))>=((f1[34]-f1[78])%(short)(18301))))){
var0 = (double)((((((var0-(double)(0.7581954588282213))-((var0-(double)(0.750684892493563))+(var0*(double)(0.6530091426152199))))+((var0/(double)(0.5485323218639981))+(var0%(double)(0.5667855123450704))))-(var0%(double)(0.45934103784874936)))-(var0-(double)(0.07926171375643931)))/(double)(0.12014329902606813));
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 54");
}
if( (((var0*(double)(0.6988668658588592))<(var0-(double)(0.05232626498850623)))&&((var0+(double)(0.025788792884510414))==(var0%(double)(0.6214753649726393))))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 61");
}
if(((var2/(byte)(-91))!=(((var2*(byte)(-33))+(var2*(byte)(-115)))%(byte)(-123)))){
System.out.println("TenKLOC1 - TenKLOC1method3- LineInMethod: 67");
}
else{
 f1[100] = (short)((var1/(short)(9935))-(f1[18]-f1[125]));
}
return (Object)null;

}

public static String TenKLOC1method4(byte var0, double var1, String var2, short var3){
 TenKLOC1 classObj = new TenKLOC1();
if( ((var3*(short)(27215))==(var3%(short)(17065)))){
if( ((((((var0-(byte)(116))-(var0/(byte)(-33)))+(var0+(byte)(-76)))-(var0%(byte)(-23)))-(var0*(byte)(108)))!=(var0-(byte)(-8)))){
if( ((var2+"zftybynslnbbjgvkig")!=(var2+"izedrtfngpkysoxpqanfyqgkizlgmpohezsdjwosfbymjzvrhobomtiniuqowmlrntpxnujzwjvrkjy"))){
var0 = (byte)((var0-(byte)(-22))-(var0*(byte)(-15)));
}
}
}
if( (((((var1+(double)(0.5050227039316202))-(var1/(double)(0.750582986637559)))%(double)(0.3383082660641028))/(double)(0.2079424472560948))!=(var1-(double)(0.3078716481229462)))){
var2 = (String)(var2+"jucgoubkoyvhxajbwnaz");
}
for(int i = 0; i < 3; i++){
 }
if(((var0*(byte)(56))>(var0+(byte)(102)))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 17");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 18");
}
if( ((var2+"pdueovlduyxbvvojmclbnunpjweozxhljxrgcekmgkwxehneahldjlkeomqvnovocrlpmegentdkvsdsvsek")==(var2+"vyisjalsnizwosdphpskxrvskfkkqp"))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 23");
}
if(((var2+"kkyrpsgeyujiygycjlhtnm")!=(var2+"lqepkfismbmamahldvuazchvgxygwvecaktzhdxwgqcmoddvkiwxvwhpmfrjypubmjwzsnz"))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 30");
}
else{
 var0 = (byte)((var0-(byte)(-97))-((var0*(byte)(16))/(byte)(80)));
}
if((((var2+"rsqkvnankztdnyiwfpokevzahanilsnzkkwecsayuzoehnwpejjeifdvgudhr")==(var2+"xdiojdfvvvkbnyfzttffekzpqguspcgrauwayrkteygzgvrkllumvgsfmtoamcqe"))&&((var2+"bmdasfohjnzltebtsg")!=(var2+"riiirybbeqylolzzrmjojjbeimtmduzhgz")))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 39");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 42");
}
if( ((var0*(byte)(109))>=(var0+(byte)(-88)))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 48");
}
if(((var3+(short)(20720))>=(var3+(short)(22831)))){
var0 = (byte)(((var0*(byte)(-84))*((var0-(byte)(-19))-((var0%(byte)(5))%(byte)(79))))+(var0+(byte)(-48)));
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 54");
}
if(((var1+(double)(0.6040542387314803))==(((var1-(double)(0.39727552586049997))%(double)(0.05271718323607966))-((var1/(double)(0.46677153730032195))+(var1*(double)(0.4641879535357759)))))){
var0 = (byte)((var0*(byte)(-126))-(var0+(byte)(96)));
}
else{
 var3 = (short)((var3%(short)(20783))%(short)(16857));
}
if(((var2+"pkssatewwbluzmrhwgqragrmecwidhjtognpgzcuefkivxstijmnpzblxppab")==((var2+"lzpfaekfnvanladndukrlsffanifsrxlikevlvvqnajfnajyhzifjppycddqkjvfuyffbpdxadnwtwzyesookwdwssmwlkiqwan")+(var2+"cmrrtxsgdjxnxinzrbtcbrntrovdnskkadpzncdeobwhlznubfglaqpwfgtmscdwyywlpknejcimbbdpkj")))){
System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 66");
}
else{
 System.out.println("TenKLOC1 - TenKLOC1method4- LineInMethod: 69");
}
return (String)var2;

}


public static void main(String args[]){
TenKLOC1 obj = new TenKLOC1();
TenKLOC1method0((double)(0.9373666320633733),new TenKLOC23(),(float)(0.40257317));
TenKLOC1method1('n','i',new TenKLOC16());
TenKLOC1method2(new TenKLOC7(),(short)(23698),(byte)(65),(float)(0.9929431),(short)(9954));
obj.TenKLOC1method3((double)(0.7790439096771515),(short)(2408),(byte)(123));
TenKLOC1method4((byte)(37),(double)(0.6073129223684781),"mhyjhorvjegqmyxkdemqvldnokfodfhxdxtdewupyijmnknmm",(short)(2069));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC1 obj = new TenKLOC1();
TenKLOC1method0((double)(0.2532831458991688),new TenKLOC23(),(float)(0.9076819));
TenKLOC1method1('b','e',new TenKLOC16());
TenKLOC1method2(new TenKLOC7(),(short)(25597),(byte)(100),(float)(0.92369074),(short)(22429));
obj.TenKLOC1method3((double)(0.6686887513071988),(short)(2567),(byte)(20));
TenKLOC1method4((byte)(-52),(double)(0.11032117805372998),"ruh",(short)(20993));
}

}