package com.accenture.lab.carfast.test;


public interface TenKLOCInterface0
{
public long TenKLOCInterface0Method0(float var0, char var1, short var2, String var3, TenKLOC16 var4);
public char TenKLOCInterface0Method1(int var0, TenKLOC20 var1, String var2);
public byte TenKLOCInterface0Method2(TenKLOC15 var0, short var1, long var2, char var3, int var4, long var5);
}