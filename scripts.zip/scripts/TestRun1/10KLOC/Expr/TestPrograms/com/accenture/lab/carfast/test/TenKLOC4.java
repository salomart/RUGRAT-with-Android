package com.accenture.lab.carfast.test;


public class TenKLOC4 implements TenKLOCInterface2 {
static double f0;
char f1;
static short[] f2= new short[61];
static double f3;
static double f4;


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC4 classObj = new TenKLOC4();
for(int i = 0; i < 1; i++){
 if( ((var1-(short)(22166))!=(var1*(short)(6304)))){
if( ((var1-(short)(7004))<=((var1/(short)(3717))/(short)(7137)))){
if( ((var0+"dmcgrmfakqiosoqqkyjpmuzhcpmlkdtrbnmlhxdi")!=(var0+"parpdoqmbzxfcqgafwntbstaajfxmqprfuicuvzueoqzdtklljsxvwxtnnumgwfoqtzczacaitxevbtbnnoxxexdeoq"))){
f1 = (char)(('z'*'u')*('v'+'q'));
}
}
}
}
for(int i = 0; i < 4; i++){
 f1 = (char)('j'%'b');
}
if( ((var1*(short)(1544))>=(var1%(short)(15687)))){
System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 15");
}
if(((var1-(short)(19466))>(var1%(short)(1778)))){
var2 = new TenKLOC7();
var1 = var2.TenKLOCInterface2Method0(var0,var1,var2);

}
else{
 f1 = (char)((('x'+'b')+('a'-'e'))-('g'%'s'));
}
if( (((var1/(short)(12467))==((var1%(short)(599))%(short)(19415)))&&((var1/(short)(15527))==(var1/(short)(7766))))){
System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 24");
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 27");
}
for(int i = 0; i < 9; i++){
 if( ((var0+"haicfnykyieyfssvqcxqeaxspcgdtpltujnnfxvvbh")!=(var0+"gbyzamhpzqqxymwpgfvqwbeqtepyexkzxpehzgwjrtbtzl"))){
System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 35");
}
}
if((((var0+"nbpgdyjzczqcbzvnirkkrrjndscavaczrxnijhwatugcjmrxyraqjelpfcrmyrtprgtqxvwxbamjounsjre")==(((var0+"choiqgwtrwnuxuqpsaclz")+((var0+"ljoffqnjpezkosnxywy")+(var0+"rghxrlfszmecxvzy")))+(var0+"cvxndsepmrgpjdokmffdzcaywgdieabyavwwjdstsmiorqd")))||((var0+"jhqukejlwupcjtgpbyxxgqtznzcpbwyjglqbnasxt")==(var0+"dvpmqccsbriprgdtbzgjthqyvdyhfjpyehfndaqyznxrebgbebi")))){
f1 = (char)((f1/'j')-('x'*'g'));
}
else{
 f1 = (char)(('l'+'h')*(f1/'h'));
}
if(((var1-(short)(6338))<(var1+(short)(24603)))){
f1 = (char)(('z'-'b')-('r'*'f'));
}
else{
 System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 49");
}
if( ((var1%(short)(7235))!=((var1+(short)(28253))+(var1/(short)(5143))))){
System.out.println("TenKLOC4 - TenKLOCInterface2Method0- LineInMethod: 55");
}
return (short)var1;

}

public static double TenKLOC4method0(int var0, String var1, byte var2, double var3){
 TenKLOC4 classObj = new TenKLOC4();
if( ((var0*(int)(346))!=((var0+(int)(294))+(var0+(int)(161))))){
if( (((var1+"mqvhiwlzzpuh")==(var1+"fbikrpigjjpacktljadrvcwyckpflcjkqssduuh"))&&((var1+"jqndthzljopyjjeuxwjobrixkjeansgmzhaxvlebjlffweyryrqoedwrsbw")!=(var1+"rqdxkvwywwxcddskrejdesdepwytdgyougnpssueihwcpaaoxjbbtrtlpcxfhtwefkjjqccdksdoufhdmdqyytbhjxwjabnlth")))){
if( ((var1+"vkyxykefvyqxkcwknejugaajtevshlbtksdmmwsnuqejprsxwqoclkhguojnzoemadpe")==(var1+"xqpszotobsfsivhxrccwityyutypiltttllkoaohzomvkjzjahqqjmmotbxdqtsyahlxnaenpnetzbgn"))){
}
}
}
if( (((var2-(byte)(58))!=((var2*(byte)(-99))-((var2-(byte)(-40))+(var2-(byte)(82)))))&&((var2+(byte)(48))>(var2+(byte)(57))))){
var1 = (String)(var1+"xnyvpcktsw");
}
if( ((var1+"nokkgrhpzvantsaitxrhagbcfpbzaiv")!=(var1+"bbgkwqsufxbwbzlmovqfkyridzu"))){
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 12");
}
if( ((var1+"rwqargaauojoxoduhpwxvsqzdborcagywdwjyawyvvfgkuyfgykzywsmudgmcgslimbvfxemyzznsjefvnukgywenunswzemvou")==(var1+"cwhyiqfarpbrxjfpzpknkmatfihzevekxrxlfwpmrlamziwufntljlkegboqddgorfgo"))){
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 17");
}
switch(((var0*(int)(577))-(var0-(int)(561)))){
case 0:
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 21");
 break;
case 1:
f2[14] = (short)(((short)(12005)*(short)(27325))*(f2[33]-f2[57]));
 break;
case 2:
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 31");
 break;
case 3:
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 36");
 break;
case 4:
var0 = (int)((var0-(int)(343))%(int)(572));
 break;
case 5:
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 42");
 break;
case 6:
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 45");
 break;
case 7:
f3 = (double)((var3*(double)(0.34296742943940994))*(var3+(double)(0.5355767452988898)));
 break;
default :
System.out.println("TenKLOC4 - TenKLOC4method0- LineInMethod: 55");
}
return (double)var3;

}

public short TenKLOC4method1(TenKLOC29 var0, byte var1, double var2){
 TenKLOC4 classObj = new TenKLOC4();
if( ((var2*(double)(0.5930384445623024))>=((var2+(double)(0.6786318189162622))+(((((var2+(double)(0.3856184163599725))+(((var2*(double)(0.9558107537421752))*(var2*(double)(0.8213527337703737)))-(var2+(double)(0.8768495842398156))))-(var2/(double)(0.543259397046538)))-(var2%(double)(0.12811094575014603)))/(double)(0.33869168302420793))))){
var1 = (byte)(((var1/(byte)(84))-(var1*(byte)(114)))-(var1+(byte)(-92)));
}
if( (((var2-(double)(0.6400357647460624))+((var2+(double)(0.7748663994360819))*(((var2+(double)(0.48444727401464505))%(double)(0.35604867483721625))+((var2-(double)(0.2088701028169535))*(var2-(double)(0.16524273939102718))))))>((var2+(double)(0.9603844974642931))%(double)(0.6196709974276652)))){
System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 6");
}
for(int i = 0; i < 8; i++){
 var2 = (double)(0.04785435193742371);
}
if((((var2-(double)(0.5591703464612476))<(var2/(double)(0.760470313400649)))&&((var2-(double)(0.9796472916461356))==(var2-(double)(0.36753814344328106))))){
System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 17");
}
else{
 System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 19");
}
if( (((var2%(double)(0.42724608419722376))<((var2-(double)(0.5069806029429957))-(var2-(double)(0.6762964617600651))))&&(((var2+(double)(0.3904138819066776))+((var2*(double)(0.34043107079281243))+((var2+(double)(0.9344520403722482))*(var2%(double)(0.6484612647684604)))))<(var2-(double)(0.5211804650422023))))){
if( ((var1%(byte)(117))==(var1+(byte)(73)))){
if( ((var2+(double)(0.8576875820891408))==((var2+(double)(0.4868279920157602))-(var2/(double)(0.020435455881095632))))){
System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 29");
}
}
}
if((((var1*(byte)(-115))-(var1*(byte)(-91)))>=((var1*(byte)(-99))+(var1/(byte)(-39))))){
var0 = new TenKLOC0();
}
else{
 System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 36");
}
for(int i = 0; i < 6; i++){
 var1 = (byte)(((var1*(byte)(-24))*(var1+(byte)(-87)))%(byte)(33));
}
if((((var1*(byte)(25))*(var1+(byte)(-101)))!=(var1*(byte)(-118)))){
System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 47");
}
else{
 System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 49");
}
if(((var2*(double)(0.6544053608988949))>(var2+(double)(0.9098936241071809)))){
var2 = (double)((var2%(double)(0.11800532548744547))%(double)(0.8769994255345621));
}
else{
 System.out.println("TenKLOC4 - TenKLOC4method1- LineInMethod: 57");
}
return (short)(short)(2673);

}

public static Object TenKLOC4method2(double var0, short var1, String var2){
 TenKLOC4 classObj = new TenKLOC4();
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 3");
}
if( ((var2+"cwkkxhovaeansoinwqugbbbbdhujhhdewd")!=(var2+"yylkrmvqgfszfmoebrvjikjaeksmdpaynmtsdttx"))){
if( ((((var2+"kpewskwxtdmwhuxywylxgwopvedjklthm")!=((var2+"ddtvugrakapgrgnnjcmcuxrmxyscjdtgeob")+(var2+"eatwplsjkdptycwxuqksedl")))&&((var2+"lukolpiajevqrmbhcznidgkfospfbjnlhmpdiyrqmeozrgcjgbnzwmlhasvc")==(var2+"ndsqersdgpfcttsibeeuzfogkbthpueazkwacnhuodfdfeawphlvnhzkzk")))&&((((var2+"fyryixfuezvmnkybsrncproqsrqqgwhvfj")+(var2+"oaaolkflptflhsjxwoddizxwixlmefdkojxgnlbcfyozdalksdwphalhzuebvgvajdferti"))+(var2+"yvaqoyxkyqkaqtunuwak"))==(var2+"crcyrxtpnyxxxrdpjfaveuzetalbefrltnitqquyjlfkxgvjyvilnljgzvgzwqhchnssbkrolqoaghamlkcm")))){
if( ((var0/(double)(0.836959003593923))<=(f3%(double)(0.2605102446879315)))){
System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 11");
}
}
}
if( ((((var1%(short)(16289))-(var1+(short)(30426)))+(var1+(short)(12564)))==(var1-(short)(14789)))){
f0 = (double)(((var0*(double)(0.39285807274341156))*(var0+(double)(0.8398332363043534)))*(var0-(double)(0.6757273781022481)));
}
if((((var0+(double)(0.7762269116052781))-(var0*(double)(0.22024592138693944)))>(var0/(double)(0.48425280104427504)))){
System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 22");
}
else{
 }
for(int i = 0; i < 3; i++){
 if( ((f2[12]%(short)(25887))>(f2[13]-f2[18]))){
System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 30");
}
}
if(((var2+"mzfdzpabrrahxuzqxpasjigdrlvvsqtllkqjjlmmuodtqocyulwygeotsksoqbmosbp")==(var2+"lfihlhiwhkawssksayayblqgjwfrjmeijdijxumjicvgmttxazwjjuvhknguecotlfhygshwgipxodvxxgeosdzkmlxl"))){
f3 = (double)(var0+(double)(0.2116492845683393));
}
else{
 f3 = (double)((f0/(double)(0.334163666191861))%(double)(0.26093291264471774));
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 41");
}
if( (((var0-(double)(0.7778525133951623))-(var0*(double)(0.285875383989177)))!=(((var0-(double)(0.23795651809279517))*((var0*(double)(0.45721594919694886))/(double)(0.1626832060687824)))/(double)(0.4922279705869217)))){
System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 46");
}
if(((var1+(short)(27359))!=(var1+(short)(3579)))){
System.out.println("TenKLOC4 - TenKLOC4method2- LineInMethod: 53");
}
else{
 f0 = (double)((var0%(double)(0.12915355719882915))-(var0/(double)(0.9599022991542598)));
}
return (Object)null;

}

public char TenKLOC4method3(float var0, long var1, byte var2){
 TenKLOC4 classObj = new TenKLOC4();
for(int i = 0; i < 3; i++){
 if( (((var0+(float)(0.44123667))%(float)(0.9761161))!=((var0*(float)(0.7656071))/(float)(0.2745797)))){
if( ((var2*(byte)(3))==(var2-(byte)(-106)))){
System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 7");
}
}
}
for(int i = 0; i < 6; i++){
 if( (((var2*(byte)(-67))<=(var2-(byte)(61)))&&((var2-(byte)(9))!=(var2/(byte)(110))))){
if( ((var0-(float)(0.25952607))==(var0%(float)(0.21819699)))){
}
}
}
if(((var1/(long)(385))>=((var1*(long)(438))+(var1-(long)(154))))){
var2 = (byte)((var2/(byte)(-90))/(byte)(-59));
}
else{
 System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 19");
}
if( ((((var0+(float)(0.40471923))==(var0-(float)(0.33582413)))&&(((var0-(float)(0.121649444))-(var0%(float)(0.30283684)))==(var0*(float)(0.8399772))))||(((var0*(float)(0.8590295))*(var0*(float)(0.36078167)))<=(var0-(float)(0.04519373))))){
f1 = (char)(('x'-'e')%'s');
}
if( ((var0-(float)(0.47618347))>=(var0+(float)(0.78377366)))){
System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 28");
}
if( (((((var1*(long)(563))*(var1-(long)(66)))!=((var1+(long)(89))/(long)(577)))&&(((var1-(long)(501))*(var1/(long)(48)))!=(var1/(long)(717))))||((var1*(long)(620))<((var1-(long)(206))*(var1+(long)(491)))))){
System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 32");
}
for(int i = 0; i < 8; i++){
 System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 36");
}
if( ((var2*(byte)(-56))==(var2%(byte)(103)))){
System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 43");
}
for(int i = 0; i < 8; i++){
 if( (((((var1*(long)(425))*((((var1/(long)(546))-(var1%(long)(322)))-(var1-(long)(628)))-(((var1/(long)(321))*(var1-(long)(564)))+(var1-(long)(11)))))-((var1-(long)(535))+(var1/(long)(369))))-((var1*(long)(510))+(var1/(long)(726))))==(var1+(long)(696)))){
System.out.println("TenKLOC4 - TenKLOC4method3- LineInMethod: 52");
}
}
if(((var1/(long)(205))>(var1+(long)(581)))){
var0 = (float)(((var0/(float)(0.54837006))+(var0/(float)(0.065214336)))*(var0%(float)(0.75141805)));
}
else{
 var0 = (float)((var0*(float)(0.41348517))*(var0+(float)(0.272133)));
}
return (char)'z';

}

public static String TenKLOC4method4(int var0, float var1, short var2, long var3){
 TenKLOC4 classObj = new TenKLOC4();
for(int i = 0; i < 5; i++){
 }
if( ((((var3-(long)(452))+(var3/(long)(609)))<=(var3*(long)(441)))&&(((var3+(long)(27))!=(var3%(long)(393)))&&(((var3-(long)(552))>(var3-(long)(484)))&&((((var3-(long)(767))>(var3-(long)(183)))||(((var3/(long)(27))!=(var3+(long)(128)))&&((var3*(long)(40))==((var3-(long)(481))%(long)(271)))))&&((var3*(long)(109))!=(var3+(long)(191)))))))){
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 5");
}
if( ((var0+(int)(88))>(var0*(int)(269)))){
if( ((var2-(short)(20524))<(var2%(short)(10012)))){
if( ((var1%(float)(0.52877253))<((var1-(float)(0.33394027))+(var1+(float)(0.88607246))))){
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 13");
}
}
}
if( ((var0-(int)(439))==((var0-(int)(463))*(var0+(int)(333))))){
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 16");
}
for(int i = 0; i < 0; i++){
 if( ((((var1+(float)(0.21988499))+((var1+(float)(0.65221524))%(float)(0.3481326)))%(float)(0.7723755))<(var1*(float)(0.51618004)))){
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 24");
}
}
if( (((var3-(long)(105))<=(var3*(long)(105)))||((var3+(long)(763))!=(var3-(long)(61))))){
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 29");
}
switch(((((var0/(int)(475))-(var0*(int)(361)))-(var0+(int)(109)))+(var0/(int)(269)))){
case 0:
f4 = (double)(((double)(0.8494690113540257)+(double)(0.9188121041286658))-(((((double)(0.8959724358824563)%(double)(0.1681780054967772))+((double)(0.6833638236080984)/(double)(0.189688219888149)))-((double)(0.5755221641421909)*(double)(0.9824937378717089)))/(double)(0.3305230742885029)));
 break;
case 1:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 37");
 break;
case 2:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 42");
 break;
case 3:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 46");
 break;
case 4:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 50");
 break;
case 5:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 57");
 break;
case 6:
System.out.println("TenKLOC4 - TenKLOC4method4- LineInMethod: 61");
 break;
case 7:
f3 = (double)((((f3*(double)(0.22288594031272446))-(((f3*f0)+(f3%(double)(0.5520256141545499)))*(f4*f3)))*(f3+f4))%(double)(0.2488641540968627));
 break;
default :
f0 = (double)(((double)(0.9237449368316318)*(double)(0.35517577962058655))*((double)(0.8713505616829315)%(double)(0.816530349771159)));
}
return (String)"zycltgbdthlncjhsghhovfuepzyegwfywozfqszychvlycixjlyvagnlgpdsqtrngtewoolbeditnexch";

}


public static void main(String args[]){
TenKLOC4 obj = new TenKLOC4();
obj.TenKLOCInterface2Method0("owlkxmdqvcvblsscctxrzpwdjwryihezyemrmwducwlyckzevpbxiniqyayxwp",(short)(25380),new TenKLOC7());
TenKLOC4method0((int)(0),"wnuvdjheyhcftnsujlhocamjuwxryjbggfthsfgfxhwkpkaklglvtgrcbrfgisaesmcgndqqxhxmzjnbpgyudv",(byte)(63),(double)(0.6318810477925801));
obj.TenKLOC4method1(new TenKLOC29(),(byte)(-65),(double)(0.7544253034084499));
TenKLOC4method2((double)(0.13589868212809753),(short)(27666),"tapjoqlxrrvutpnbqqfh");
obj.TenKLOC4method3((float)(0.40660274),(long)(295),(byte)(83));
TenKLOC4method4((int)(663),(float)(0.7185603),(short)(11745),(long)(711));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC4 obj = new TenKLOC4();
obj.TenKLOCInterface2Method0("euzaqosbdswfqnzxncnugpjbv",(short)(18918),new TenKLOC7());
TenKLOC4method0(i3,"aoztxwnwv",(byte)(51),(double)(0.7838321947877456));
obj.TenKLOC4method1(new TenKLOC29(),(byte)(-119),(double)(0.35508038256955676));
TenKLOC4method2((double)(0.08865479506268692),(short)(25419),"kvthemzyhucoynkefdnnsldyqdtjzwylpoiruihxsgewtcfpatyswisqaujiiecuzfbrhtcutugfqmyxak");
obj.TenKLOC4method3((float)(0.9655201),(long)(745),(byte)(-119));
TenKLOC4method4(i5,(float)(0.100461304),(short)(18817),(long)(480));
}

}