package com.accenture.lab.carfast.test;


public class TenKLOC5 implements TenKLOCInterface1 {
static TenKLOC8[] f0= new TenKLOC8[123];
static double f1;


public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2){
 TenKLOC5 classObj = new TenKLOC5();
switch((var0*(int)(698))){
case 0:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 3");
 break;
case 1:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 10");
 break;
default :
var2 = (short)(((var2*(short)(16142))+(var2/(short)(6173)))*((var2*(short)(13564))-(var2-(short)(23215))));
}
if( ((((var2%(short)(12542))>=(var2%(short)(22283)))&&(((((var2*(short)(3905))-(var2*(short)(13507)))/(short)(27258))*(var2/(short)(19027)))!=(var2/(short)(795))))&&((var2-(short)(16725))==(var2*(short)(2119))))){
if( ((var0+(int)(303))!=(var0*(int)(562)))){
if( ((var2%(short)(18953))<(var2+(short)(30410)))){
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 22");
}
}
}
if( ((((var2-(short)(3370))-(var2*(short)(16451)))-(var2-(short)(25477)))<((var2+(short)(6716))+((var2*(short)(14371))-((var2*(short)(24067))*(var2+(short)(31497))))))){
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 29");
}
if( ((var2-(short)(5317))>=(var2+(short)(12544)))){
var1 = new TenKLOC29();
var1.TenKLOCInterface0Method0((float)(0.66605425),'h',var2,"hyjlizzxgepfbicxqcjddngaomndvwzqgkv",null);
}
switch((var0%(int)(709))){
case 0:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 36");
 break;
case 1:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 43");
 break;
case 2:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 47");
 break;
case 3:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 54");
 break;
case 4:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 57");
 break;
case 5:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 62");
 break;
case 6:
var2 = (short)(((var2*(short)(3769))+((((var2+(short)(27260))-(var2*(short)(12548)))*((var2*(short)(27275))%(short)(11530)))*(var2+(short)(12299))))-((var2%(short)(12568))-((var2-(short)(19642))+(var2/(short)(25401)))));
 break;
case 7:
System.out.println("TenKLOC5 - TenKLOCInterface1Method0- LineInMethod: 71");
 break;
default :
var1 = new TenKLOC0();
}
return (short)var2;

}

public String TenKLOCInterface1Method1(int var0, byte var1, String var2){
 TenKLOC5 classObj = new TenKLOC5();
switch((var0*(int)(437))){
case 0:
var0 = (int)(var0/(int)(44));
 break;
case 1:
System.out.println("TenKLOC5 - TenKLOCInterface1Method1- LineInMethod: 6");
 break;
case 2:
System.out.println("TenKLOC5 - TenKLOCInterface1Method1- LineInMethod: 12");
 break;
case 3:
var0 = (int)(var0/(int)(534));
 break;
case 4:
TenKLOC8.TenKLOC8method3((long)(303),'z',var0);
 break;
case 5:
var2 = (String)((var2+"fiyhmpssupdeaurgwicpsu")+((var2+"igtnhagneatqcwaedrnkrszmqaqnnsucpsdxwqufyuqcochdeqyhahzx")+(var2+"vojgemgamnwhuisgnyzmcheolz")));
 break;
default :
System.out.println("TenKLOC5 - TenKLOCInterface1Method1- LineInMethod: 27");
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC5 - TenKLOCInterface1Method1- LineInMethod: 34");
}
return (String)var2;

}

public Object TenKLOCInterface1Method2(double var0, byte var1, int var2){
 TenKLOC5 classObj = new TenKLOC5();
switch(((var2*(int)(253))/(int)(266))){
case 0:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 3");
 break;
case 1:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 6");
 break;
case 2:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 13");
 break;
case 3:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 17");
 break;
case 4:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 24");
 break;
case 5:
var0 = TenKLOC8.TenKLOC8method3((long)(100),'n',var2);

 break;
case 6:
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 33");
 break;
default :
System.out.println("TenKLOC5 - TenKLOCInterface1Method2- LineInMethod: 38");
}
return (Object)null;

}

public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2){
 TenKLOC5 classObj = new TenKLOC5();
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC5 - TenKLOCInterface1Method3- LineInMethod: 4");
}
for(int i = 0; i < 3; i++){
 var0 = new TenKLOC16();
}
if(((var2*(int)(708))>(var2%(int)(699)))){
System.out.println("TenKLOC5 - TenKLOCInterface1Method3- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC5 - TenKLOCInterface1Method3- LineInMethod: 21");
}
if(((((var1%(float)(0.16212153))*(var1-(float)(0.6537978)))==(var1+(float)(0.911534)))&&((var1*(float)(0.76306915))==(var1*(float)(0.45670813))))){
System.out.println("TenKLOC5 - TenKLOCInterface1Method3- LineInMethod: 30");
}
else{
 System.out.println("TenKLOC5 - TenKLOCInterface1Method3- LineInMethod: 34");
}
return (double)(double)(0.5520357276211324);

}

public static float TenKLOC5method0(TenKLOC5 var0, TenKLOC16 var1, long var2, TenKLOC29 var3){
 TenKLOC5 classObj = new TenKLOC5();
if(((var2+(long)(92))>(var2+(long)(234)))){
f0[109] = new TenKLOC8();
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method0- LineInMethod: 6");
}
if(((var2*(long)(632))<=(var2-(long)(166)))){
System.out.println("TenKLOC5 - TenKLOC5method0- LineInMethod: 13");
}
else{
 var1 = new TenKLOC16();
}
if( ((var2-(long)(458))>=(var2*(long)(356)))){
if( (((var2/(long)(287))+(var2*(long)(490)))>=(var2+(long)(730)))){
if( ((var2*(long)(490))!=((((((var2+(long)(615))*(var2-(long)(257)))*(var2*(long)(299)))/(long)(498))/(long)(522))*(var2-(long)(639))))){
TenKLOC29.TenKLOC29method0((double)(0.09448598443838196),(int)(650),"keetnmwkejinlhdvmdnfvdnnjphdwovtapawivhcdpemsnepcrmjetsamqzfaixypfdcgtkchelompmcksvpj");
}
}
}
if(((var2-(long)(96))==(var2-(long)(214)))){
System.out.println("TenKLOC5 - TenKLOC5method0- LineInMethod: 27");
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method0- LineInMethod: 32");
}
if(((var2%(long)(40))>=(var2/(long)(214)))){
var1 = new TenKLOC16();
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method0- LineInMethod: 41");
}
return (float)(float)(0.8194459);

}

public static char TenKLOC5method1(long var0, float var1, double var2){
 TenKLOC5 classObj = new TenKLOC5();
if(((var0/(long)(224))<=(var0*(long)(442)))){
System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 5");
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 6");
}
if(((var2+(double)(0.40946480490557036))!=(var2/(double)(0.4366186262423718)))){
var1 = (float)((var1/(float)(0.5490032))*((var1*(float)(0.52293855))+((var1+(float)(0.7976524))-(var1%(float)(0.0021737218)))));
}
else{
 var0 = (long)(27);
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 15");
}
if((((var2-(double)(0.36192807445734865))*(var2+(double)(0.5769771771690299)))!=(var2-(double)(0.3937904759930716)))){
System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 22");
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 25");
}
if( ((((((var0+(long)(766))+((var0+(long)(254))*(var0-(long)(433))))<(var0*(long)(622)))&&(((var0%(long)(148))>(var0/(long)(224)))||(((var0/(long)(611))>((var0-(long)(570))-((var0+(long)(145))+(((var0/(long)(719))/(long)(333))*(var0*(long)(644))))))||((var0*(long)(395))<=((var0*(long)(614))-(var0*(long)(51)))))))&&((var0%(long)(174))!=(var0-(long)(667))))&&((((var0+(long)(160))>(var0/(long)(319)))&&((var0/(long)(48))>=(var0*(long)(161))))||((((var0-(long)(29))*(var0+(long)(282)))!=(var0-(long)(221)))||((((((var0*(long)(292))+(var0/(long)(720)))-(var0*(long)(67)))/(long)(262))*((var0/(long)(66))*(var0/(long)(467))))!=(var0/(long)(694))))))){
if( ((var0+(long)(206))<=((var0/(long)(561))-(var0-(long)(554))))){
if( ((var0-(long)(553))>=((var0*(long)(669))*((var0%(long)(214))+(var0/(long)(4)))))){
System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 33");
}
}
}
if( (((var2-(double)(0.5180698523342894))==(var2*(double)(0.45894974515900067)))&&((var2-(double)(0.3059127282788864))==(f1-(double)(0.2953528172324902))))){
System.out.println("TenKLOC5 - TenKLOC5method1- LineInMethod: 37");
}
return (char)'y';

}

public double TenKLOC5method2(short var0, float var1, double var2, short var3, double var4){
 TenKLOC5 classObj = new TenKLOC5();
if(((((var0/(short)(6291))<(var3*(short)(2267)))&&((((var3-(short)(32016))>=(var3-var0))||((var3*(short)(26424))==(var0%(short)(11128))))&&((var3%(short)(23787))>(var0%(short)(9548)))))&&((((var0-(short)(21941))*(var0+(short)(21313)))==(var3-(short)(32543)))&&((var0*var3)>=(var3*(short)(26059)))))){
f0[106] = new TenKLOC8();
f0[106].TenKLOC8method1(null,var1,'p');
}
else{
 var4 = (double)((var4*var2)+(var4+(double)(0.9639658591237772)));
}
if( ((var0/(short)(5557))!=(var0*var3))){
if( ((var0-(short)(6730))>(((var0*var3)+(var3%(short)(32491)))/(short)(26723)))){
var2 = (double)((((var2*var4)-(var2*(double)(0.5311802154354268)))*(var4+var2))+(var2*(double)(0.43578679824459665)));
}
}
for(int i = 0; i < 4; i++){
 System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 14");
}
if(((var1*(float)(0.45473164))>(var1%(float)(0.36676502)))){
System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 23");
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 24");
}
if(((((((var1*(float)(0.49217176))>=(var1*(float)(0.8510921)))||((var1+(float)(0.94874644))!=((var1-(float)(0.64552075))*(var1/(float)(0.51084435)))))&&((var1-(float)(0.70721734))>=(var1+(float)(0.14522648))))||((var1%(float)(0.5578523))<(var1+(float)(0.8886441))))&&((var1/(float)(0.31918627))!=((((var1/(float)(0.4881081))-(var1-(float)(0.73007447)))%(float)(0.7992887))/(float)(0.8782737))))){
System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 32");
}
else{
 var3 = (short)((var0-var3)-(var3*var0));
}
if((((var1*(float)(0.3955195))<=(var1-(float)(0.035184145)))&&((var1+(float)(0.9917479))<=(var1-(float)(0.72050273))))){
System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 39");
}
else{
 System.out.println("TenKLOC5 - TenKLOC5method2- LineInMethod: 41");
}
return (double)var2;

}

public static Object TenKLOC5method3(char var0, TenKLOC1 var1, int var2, char var3, double var4){
 TenKLOC5 classObj = new TenKLOC5();
switch((var2*(int)(280))){
case 0:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 3");
 break;
case 1:
var1 = new TenKLOC1();
 break;
case 2:
var0 = (char)(var3+'e');
 break;
case 3:
f0[73] = new TenKLOC8();
f0[73].TenKLOC8method1(null,(float)(0.31383967),var0);
 break;
case 4:
f1 = (double)((var4-(double)(0.17128725700913228))*(var4+(double)(0.8053546495058639)));
 break;
default :
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 22");
}
switch((var2*(int)(497))){
case 0:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 25");
 break;
case 1:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 31");
 break;
default :
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 34");
}
switch((var2%(int)(702))){
case 0:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 38");
 break;
case 1:
var2 = (int)((var2-(int)(719))*(var2+(int)(613)));
 break;
case 2:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 47");
 break;
case 3:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 50");
 break;
case 4:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 57");
 break;
case 5:
f1 = (double)(f1-(double)(0.4109958130204209));
 break;
case 6:
System.out.println("TenKLOC5 - TenKLOC5method3- LineInMethod: 66");
 break;
case 7:
var2 = (int)((var2*(int)(185))-(var2+(int)(372)));
 break;
default :
f0[14] = new TenKLOC8();
}
return (Object)var1;

}

public long TenKLOC5method4(float var0, short var1, char var2, TenKLOC20 var3, String var4, short var5){
 TenKLOC5 classObj = new TenKLOC5();
for(int i = 0; i < 0; i++){
 if( (((var4+"gvsmgbfmxmqwiateaidpmtykcyhtmuumafyudzcnlmrltzivirbwmhjwegixeerloczyimx")+(var4+"fmlbgcgjkeapnazdwhznohqexwfevquocxdun"))==(var4+"sxbhpiiutsigawqpshxgozjtrqpfqgfxndvejgdtrimmihsusngwriamsxxvnrlqyuyhxxwtbbubtivpbffdsdbfbtdo"))){
System.out.println("TenKLOC5 - TenKLOC5method4- LineInMethod: 5");
}
}
for(int i = 0; i < 5; i++){
 var0 = (float)(0.04374993);
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC5 - TenKLOC5method4- LineInMethod: 13");
}
if( ((var4+"vyikehygwubiqjglowjazlwtuerxdebeecrhzbvnryfpdmmjwwmbetgqsyg")==(var4+"lwrhppprcugkewujeydyojjzdzcde"))){
if( ((var2/'h')>(var2*'m'))){
if( ((var5+var1)!=((var5+(short)(50))-((var1%(short)(7204))+(var1*var5))))){
System.out.println("TenKLOC5 - TenKLOC5method4- LineInMethod: 22");
}
}
}
if( (((var0-(float)(0.42010176))%(float)(0.809071))<(var0%(float)(0.62521803)))){
System.out.println("TenKLOC5 - TenKLOC5method4- LineInMethod: 29");
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC5 - TenKLOC5method4- LineInMethod: 33");
}
for(int i = 0; i < 9; i++){
 var1 = (short)((var1/(short)(2278))+(var1*var5));
}
return (long)(long)(396);

}


public static void main(String args[]){
TenKLOC5 obj = new TenKLOC5();
obj.TenKLOCInterface1Method0((int)(121),new TenKLOC29(),(short)(26048));
obj.TenKLOCInterface1Method1((int)(223),(byte)(116),"dygqppneygwbdfhohdltygjpuabttjusdfcugqnqeborunsdiwwvfuxftzdbhyw");
obj.TenKLOCInterface1Method2((double)(0.2567919822795861),(byte)(-90),(int)(722));
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.60217834),(int)(635));
TenKLOC5method0(new TenKLOC5(),new TenKLOC16(),(long)(10),new TenKLOC29());
TenKLOC5method1((long)(571),(float)(0.7256139),(double)(0.5978237937850637));
obj.TenKLOC5method2((short)(21714),(float)(0.80229515),(double)(0.9278057439915985),(short)(14486),(double)(0.3356766849987741));
TenKLOC5method3('b',new TenKLOC1(),(int)(442),'e',(double)(0.30882688750142406));
obj.TenKLOC5method4((float)(0.11164409),(short)(4932),'e',new TenKLOC20(),"hzabzghfrpgnhucvymgeqdhuribvwhfodjgpmadsubpcasqfhgetjxwhlwwxgigdxtwnotdny",(short)(24582));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC5 obj = new TenKLOC5();
obj.TenKLOCInterface1Method0(i2,new TenKLOC29(),(short)(28270));
obj.TenKLOCInterface1Method1(i1,(byte)(-12),"lgmahnsnjkoyadoestzpkolmaarriygykdncikftccnudfxgcsnvxonvmagxsletnmn");
obj.TenKLOCInterface1Method2((double)(0.10804529522956252),(byte)(-46),i6);
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.046663463),i5);
TenKLOC5method0(new TenKLOC5(),new TenKLOC16(),(long)(567),new TenKLOC29());
TenKLOC5method1((long)(180),(float)(0.7668367),(double)(0.8613521933533491));
obj.TenKLOC5method2((short)(17502),(float)(0.92381495),(double)(0.14544633617455316),(short)(28237),(double)(0.9174618434999889));
TenKLOC5method3('d',new TenKLOC1(),i2,'z',(double)(0.9681149410511751));
obj.TenKLOC5method4((float)(0.72291666),(short)(16203),'r',new TenKLOC20(),"tsllqgxjjcnusqsxvetitdqxonoebxrgbfranpnqtza",(short)(20853));
}

}