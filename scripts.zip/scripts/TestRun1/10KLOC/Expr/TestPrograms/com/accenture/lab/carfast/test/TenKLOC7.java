package com.accenture.lab.carfast.test;


public class TenKLOC7 extends TenKLOC27 implements TenKLOCInterface2 {
char f0;
double f1;


public short TenKLOCInterface2Method0(String var0, short var1, TenKLOC7 var2){
 TenKLOC7 classObj = new TenKLOC7();
if(((var0+"trperhqzksmrfivusklpxoedlwrvuvhhqoedwfszedopgbnsxqgvzzvoupgtfudavjzm")!=((var0+"ykwupvtscgzxvpozbpsnhvdtamuakrbppkmumzlhsfhxvc")+(var0+"ollpindmkavnjxdttspqdnjricbbczsmqrfublxmvnpkm")))){
var0 = "vfwavbzpkzlwormm";
}
else{
 System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 5");
}
if( (((var0+"sfporgugpcrzjzlirwmqajrffofuu")!=(var0+"wdktvxlbggzeqfsocvhxqeqfwsouyccfgpgsfanazimfthuxvnlgcgqnvpjiiibgaevtzpeogukbminzclhihr"))&&((var0+"hzuatrmrcrsfaabuvtzekykpznnwokkmaicvafdsbndprevbdzxbogaetajzouewmahtmnupznnuh")==(var0+"urydmlucgo")))){
if( ((var0+"rgivtdatsgeaaksnyrohcacrmbeqxmhzviogkqfemcaymquecowcwkykdeuzpfvpgtoydfinpdkopzxddyoxvsjjamfwe")==(var0+"wobldtspondodzpxpd"))){
if( ((var0+"eotoovfjgabolhjteslwurpctrhiumjyawqsebwlffncgghpixqgstjjenpzjbcyd")==(var0+"ajlvhxqlybpctzqibkaudgynjvretmcanu"))){
System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 13");
}
}
}
if( ((var0+"salzcoudfidwdgzgudcutuhvozjtacnghzrixykbaagpuyubrudgpmmxlwbkndjitqfgliorsms")==(var0+"quiwdzsbiovfl"))){
f0 = (char)(('a'-'u')+('y'-'v'));
}
if( ((var1%(short)(31466))>((var1*(short)(18900))*((var1-(short)(23585))+((var1*(short)(27066))%(short)(14937)))))){
System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 22");
}
for(int i = 0; i < 7; i++){
 f1 = (double)(((double)(0.4440213400612537)-(double)(0.9568780469964069))*((double)(0.7901200290521503)/(double)(0.05143234153095999)));
}
if(((((var1+(short)(20750))<(var1*(short)(4846)))&&((var1-(short)(22073))>(var1/(short)(26972))))&&((var1-(short)(20544))<=((var1/(short)(30504))-(var1-(short)(11265)))))){
System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 32");
}
else{
 System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 33");
}
if((((var1-(short)(14241))<(var1+(short)(29376)))&&((var1*(short)(15364))>(((var1-(short)(30364))-(var1+(short)(32645)))-(var1*(short)(1677)))))){
System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 42");
}
else{
 var1 = (short)(var1%(short)(10142));
}
if(((var1*(short)(20914))<((var1*(short)(27767))*(var1+(short)(30996))))){
System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 52");
}
else{
 System.out.println("TenKLOC7 - TenKLOCInterface2Method0- LineInMethod: 53");
}
return (short)var1;

}

public Object TenKLOC7method0(double var0, int var1, double var2){
 TenKLOC7 classObj = new TenKLOC7();
if(((var0%(double)(0.11634542476125254))>=(var2-(double)(0.9724813783125738)))){
f1 = (double)((var0-var2)*(var2*(double)(0.8702762117797191)));
}
else{
 System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 6");
}
if( ((((((var1/(int)(30))/(int)(618))/(int)(743))+(var1*(int)(527)))==(var1+(int)(463)))&&((var1/(int)(372))!=(var1+(int)(171))))){
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 12");
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 16");
}
for(int i = 0; i < 4; i++){
 if( (((var0+var2)-(var0*var2))<=(f1-(double)(0.36552744038898155)))){
if( ((var2*var0)<(var2-(double)(0.019542918322819625)))){
if( ((var1*(int)(60))>=((var1-(int)(501))+(var1+(int)(30))))){
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 28");
}
}
}
}
if( ((var1*(int)(538))!=(var1-(int)(456)))){
var2 = (double)((f1+(double)(0.4046175261571525))/(double)(0.8214501641381107));
}
if( ((var1*(int)(403))<(var1*(int)(436)))){
}
switch((var1*(int)(120))){
case 0:
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 38");
 break;
case 1:
var0 = (double)((var2/(double)(0.36084117456766607))*(var2-var0));
 break;
case 2:
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 44");
 break;
case 3:
f1 = (double)(((var2-var0)-(var2+(double)(0.5499652090053738)))*(f1%(double)(0.2755304373125439)));
 break;
default :
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 50");
}
if(((var2/(double)(0.09089260549746137))>=((var2/(double)(0.8459415580119515))/(double)(0.060675151819523765)))){
System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 55");
}
else{
 System.out.println("TenKLOC7 - TenKLOC7method0- LineInMethod: 56");
}
return (Object)null;

}

public char TenKLOC7method1(int var0, char var1, float var2){
 TenKLOC7 classObj = new TenKLOC7();
if( ((var0-(int)(618))<((var0*(int)(664))+(var0+(int)(125))))){
}
if(((((var1+'v')<(f0*'f'))&&(((var1*'c')+(var1%'j'))<(var1+'b')))&&(((f0-'g')+((f0*'y')*(f0-'h')))<=(var1*'u')))){
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 7");
}
else{
 System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 11");
}
if((((var1+'i')+(var1+'g'))!=(var1%'x'))){
var0 = (int)((var0+(int)(44))/(int)(462));
}
else{
 System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 18");
}
for(int i = 0; i < 9; i++){
 if( ((f0-'l')>(var1+'x'))){
if( ((var1-'p')>=(var1-'s'))){
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 26");
}
}
}
switch(((var0-(int)(499))+(var0*(int)(663)))){
case 0:
f0 = (char)((var1*'r')-((var1*'l')%'q'));
 break;
case 1:
f0 = (char)((var1*'a')+(var1%'t'));
 break;
case 2:
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 39");
 break;
default :
var0 = (int)(((var0/(int)(277))+(var0-(int)(259)))-(var0*(int)(335)));
}
switch((var0+(int)(547))){
case 0:
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 45");
 break;
case 1:
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 51");
 break;
case 2:
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 55");
 break;
case 3:
System.out.println("TenKLOC7 - TenKLOC7method1- LineInMethod: 60");
 break;
default :
var0 = (int)((((var0%(int)(213))+(var0-(int)(471)))+(var0-(int)(765)))*(var0+(int)(205)));
}
return (char)var1;

}

public static float TenKLOC7method2(char var0, int var1, int var2, char var3, char var4){
 TenKLOC7 classObj = new TenKLOC7();
if((((var0*var3)-(var0*var4))<=((var0-var4)/'j'))){
}
else{
 var1 = (int)((var2-(int)(138))%(int)(156));
}
switch((var1*(int)(87))){
case 0:
var4 = (char)((var4*var0)-(var3+var0));
 break;
case 1:
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 11");
 break;
case 2:
var1 = (int)((var2+(int)(644))+(var2-var1));
 break;
default :
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 20");
}
if(((var0+var4)>=(var0%'l'))){
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 25");
}
else{
 var0 = (char)(var4+'i');
}
for(int i = 0; i < 3; i++){
 if( (((var1*(int)(335))<(var2-var1))&&((((var1%(int)(133))+(var2-(int)(15)))<(var1+var2))&&((var1+var2)>=(var1/(int)(657)))))){
if( ((((var1*var2)==(var2*(int)(685)))&&((var1*(int)(337))>(var2/(int)(197))))&&((((var2+(int)(266))==(var2*var1))&&((((var2%(int)(464))==(var1-(int)(635)))&&((((var2/(int)(573))<(var2/(int)(292)))||((((var2*(int)(451))%(int)(670))>=(var1-(int)(79)))&&((var1/(int)(221))==(var2+(int)(269)))))&&((var1%(int)(52))>=(var2*(int)(209)))))&&((((var2*(int)(301))+(var1/(int)(539)))>=(var1-(int)(16)))||(((var1/(int)(586))==(var2+var1))&&(((var2*var1)%(int)(703))!=((var1%(int)(564))*(var1+(int)(6))))))))||((var1-var2)>=(var2-var1))))){
if( (((var2+var1)-(var1*var2))>(var2%(int)(149)))){
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 35");
}
}
}
}
for(int i = 0; i < 6; i++){
 var0 = (char)((var3*var0)%'d');
}
for(int i = 0; i < 8; i++){
 if( ((var0%'w')>(var0-'x'))){
var0 = (char)(var4-var0);
}
}
for(int i = 0; i < 7; i++){
 if( ((var2/(int)(286))!=(var1%(int)(366)))){
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 50");
}
}
if(((((var2+(int)(246))*((var1%(int)(450))%(int)(489)))<=(var2+var1))&&(((var2+(int)(317))!=((((var2+var1)/(int)(320))-(var1%(int)(776)))*(var1+(int)(538))))&&(((var1*(int)(7))-(var1+var2))>=(var2-var1))))){
System.out.println("TenKLOC7 - TenKLOC7method2- LineInMethod: 59");
}
else{
 var1 = (int)((var1*(int)(195))+((var1+var2)*((var2+(int)(322))-(var2+var1))));
}
return (float)(float)(0.87027013);

}

public static double TenKLOC7method3(short var0, TenKLOC20 var1, byte var2, short var3){
 TenKLOC7 classObj = new TenKLOC7();
if( ((var2+(byte)(102))<=((var2%(byte)(-119))+(var2+(byte)(-23))))){
if( ((var2+(byte)(-84))<((var2%(byte)(-121))*((var2*(byte)(-100))*((var2*(byte)(83))%(byte)(-39)))))){
if( ((var2*(byte)(105))==(var2/(byte)(-98)))){
var1 = new TenKLOC20();
var1.TenKLOC20method3('x',(long)(102),"pxfvclvhgfnueyatjaiqqqrzafpfuhzjuxvttcswgjozpdduwytlbfmrvmyujdrtfocunzfszb");
}
}
}
if(((((var0*(short)(13501))<(var0-(short)(18431)))&&((var3+var0)==((var0-(short)(7817))+(((((var3*(short)(14625))*(var3+(short)(26992)))/(short)(10247))%(short)(10403))+(var3-(short)(26471))))))&&((var3-(short)(22077))>(var0-var3)))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 12");
}
else{
 System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 16");
}
if( ((var3+var0)==(var3+(short)(27779)))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 22");
}
for(int i = 0; i < 9; i++){
 System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 29");
}
if( ((var2*(byte)(17))>(var2+(byte)(-22)))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 36");
}
if( (((var0-(short)(20508))<=(var3/(short)(25422)))&&((var3+(short)(17356))>=(var0/(short)(27571))))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 42");
}
if( ((((var2+(byte)(-120))!=(var2%(byte)(-75)))&&((var2%(byte)(-81))>=(var2-(byte)(13))))||((var2/(byte)(-88))>(var2-(byte)(127))))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 47");
}
if( ((var3-(short)(21859))<(var3-(short)(2015)))){
System.out.println("TenKLOC7 - TenKLOC7method3- LineInMethod: 52");
}
return (double)(double)(0.7480792757239947);

}

public static double TenKLOC27method0(byte var0, String var1, double var2, byte var3, TenKLOC28 var4){
 TenKLOC7 classObj = new TenKLOC7();
for(int i = 0; i < 8; i++){
 if( ((((var0-(byte)(-32))>(var3-(byte)(-5)))&&(((var0+(byte)(-118))/(byte)(-53))!=(var3-var0)))&&((var3+var0)<(var3%(byte)(-7))))){
if( ((var1+"aemfpxiftuxdycpufpqhkupbftcnvvkiefajsviozrlznvhhaiidwgzemsljyslknsyjxvglvijbbgapkqmkcqhbdq")!=(var1+"nw"))){
var4 = new TenKLOC28();
}
}
}
for(int i = 0; i < 1; i++){
 var4 = new TenKLOC28();
}
if( ((var1+"puhkqebvyn")!=(var1+"fsuuzpywchiuebppszforklzieqnnpwvextvkhqedfxhrphuqorzcihdtrnkqiqfqirujkbmrdqobpagnjmhqeal"))){
var2 = TenKLOC28.TenKLOC28method0((float)(0.11843306),var1,(int)(138),var2);

}
if( ((var1+"vqvqerysjuuseliqolxqqsgiwqjpexibgdwuepdktidmwimooftxjkulfdztfvjmm")!=(var1+"oeuruzqhpdkbbufffsdltxblrsooipcqbngnzhvvlhqzzaraqeyvmmhimfgacmvkerqofab"))){
if( ((var2-(double)(0.07304711300926126))<(var2%(double)(0.09111041677329434)))){
System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 18");
}
}
if( ((((var1+"fivdrnpuigxywrhmiayzjpjawonoypoyzghdhaapqrjoxkigccaxcwwnlfagdgpeksurxytbljhurovyd")!=(var1+"hdfeohxmz"))&&((var1+"jdfujdvehdlvuu")==(var1+"joyquxvuxdadgdqpqfxjd")))||((var1+"tahqhhspzdctlfdsydsbknttywudcrzurocuuwqiodkhxywhuoezuojrpbscfygqwfurrvu")==((var1+"zgoefqulxvorcjefjnyeyuevmpfzhcwte")+((var1+"acubfhpatckfab")+(var1+"mqftohzaiasslqutficposhxuqjghedrqfybyymtghorqotagssrpugmuqbnqmvzaidxxebnmbxf")))))){
System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 25");
}
if( ((((var0*(byte)(-3))+(var3-var0))>(var0-var3))&&((var3-var0)<(var0-(byte)(116))))){
System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 32");
}
if(((var1+"mikxoireerbzyvadsbycxakzcxvyjewwcvwyqbkykgumqrdlupvwjtkunurjwdwwbbznqzpteuankzulwcfbzhdjfroo")!=(var1+"rafhnyxgpguakgrkaxlayjclbhytlgijyxezuhmcytzqglhljrcgrmjbpvmbyeselmuvfptr"))){
System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 38");
}
else{
 System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 39");
}
for(int i = 0; i < 1; i++){
 var3 = (byte)((var0-(byte)(-7))/(byte)(70));
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 48");
}
if(((var3+(byte)(99))<=(var0+(byte)(103)))){
System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 55");
}
else{
 System.out.println("TenKLOC7 - TenKLOC27method0- LineInMethod: 56");
}
return (double)var2;

}


public static void main(String args[]){
TenKLOC7 obj = new TenKLOC7();
obj.TenKLOCInterface2Method0("unbjlakzekfocgnpkmcjuohagtiidvrwtbpx",(short)(23683),new TenKLOC7());
obj.TenKLOC7method0((double)(0.8445890747222582),(int)(334),(double)(0.2774496614097236));
obj.TenKLOC7method1((int)(187),'l',(float)(0.63875127));
TenKLOC7method2('q',(int)(742),(int)(730),'r','u');
TenKLOC7method3((short)(13366),new TenKLOC20(),(byte)(-16),(short)(19490));
TenKLOC27method0((byte)(-83),"wrbnadmnrsgvvyyjusfdqwdxdzmpicgpoqlhptrobmqxjcowzjnygynsoyzechyhgxx",(double)(0.19787837375342643),(byte)(8),new TenKLOC28());
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC7 obj = new TenKLOC7();
obj.TenKLOCInterface2Method0("xaoqtzttomqemftclrjtavmqetdixzqvhpqxxlplkppevzdqvkxblnjkmetubkisismcxobakabhkpvkpkdhuzwxbpza",(short)(29962),new TenKLOC7());
obj.TenKLOC7method0((double)(0.3051207294771836),i6,(double)(0.7868031286966185));
obj.TenKLOC7method1(i2,'s',(float)(0.9794819));
TenKLOC7method2('y',i0,i1,'t','j');
TenKLOC7method3((short)(4084),new TenKLOC20(),(byte)(85),(short)(13830));
TenKLOC27method0((byte)(2),"mlciqwolqwwglszouvyno",(double)(0.8945557083778157),(byte)(-8),new TenKLOC28());
}

}