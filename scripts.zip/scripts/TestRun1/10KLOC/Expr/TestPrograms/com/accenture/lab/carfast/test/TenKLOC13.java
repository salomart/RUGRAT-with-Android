package com.accenture.lab.carfast.test;


public class TenKLOC13 {
long[] f0= new long[76];
static double[] f1= new double[191];
static TenKLOC1[] f2= new TenKLOC1[148];


public static double TenKLOC13method0(String var0, long var1, double var2){
 TenKLOC13 classObj = new TenKLOC13();
for(int i = 0; i < 0; i++){
 if( (((var0+"jzjupcnxqktuyyyzlgasgymqlfvatjsyfxvlsoklljxabwovriyckjgsmslywtejwgdavxglkenlpcngqehbffnjzitvt")+(var0+"wjmvaizekgthqbvnvhrwfrfdqgfxlebrxibfhabyqaokcfadobspcnvbxxmsvueukvxoipbmmxpztzxpzllxwxm"))==(var0+"abcmxkxoqud"))){
if( (((f1[81]%(double)(0.2823518254569184))==(var2+(double)(0.8147947411847504)))&&(((f1[14]+f1[112])==(var2/(double)(0.31870402387435803)))&&(((f1[122]*f1[55])+(f1[52]/(double)(0.9974368079127798)))<(var2+(double)(0.7275318189193143)))))){
TenKLOC1.TenKLOC1method1('b','x',null);
}
}
}
if( ((var0+"iimgzuxqqzqwaxqewpurmrunyvlvuyjshtfvegqmdryvdicmiveiwmmkhgrggwxkaiski")==(var0+"dhmomcssvbzixznnonyhybomnqpgntdougtbgthpmamrwwzdryvvikbgyoofscueykledhfs"))){
System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 10");
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 16");
}
for(int i = 0; i < 1; i++){
 f1[176] = (double)((f1[77]-f1[141])+(var2*(double)(0.49658718235920285)));
}
if((((var1+(long)(508))!=(var1+(long)(473)))||(((var1+(long)(674))%(long)(158))!=((var1*(long)(601))+((var1/(long)(302))*(((var1-(long)(745))+((var1*(long)(261))-(var1*(long)(625))))%(long)(546))))))){
var1 = (long)(((var1/(long)(216))%(long)(700))+(var1*(long)(446)));
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 29");
}
if( ((var0+"oinchklymiovzwmksckbbefbwoovbpwfczwdxjlxvllrpbsdrnkuzzltbvadoorhmkwbsxdpjuyzmowhmpbghmyd")==(var0+"xlbdocaqvafpognshetgnlwdfkablorikupbysgpqmdfajxpmtiuxvgolqakpdpvyrgihll"))){
if( ((var0+"suhtzykimxavypitwgxnhwzxybafpxytxabwtxopwqrajh")!=(var0+"xfqvdvgfdzuzeqvchldomgxeowqazmrcrqfbqtnsmbdfijouuyslcxgksijnzeckmhmgchyumeynsesielsmjrhjyqmlnvofkhvr"))){
var1 = (long)((var1-(long)(666))+(var1-(long)(723)));
}
}
if((((var0+"siwnhdxdrpffarpycdmxmnghvzygcvcvylfbfjhbbyerybfisiwhfypbygoazryoozl")==(var0+"hniwhjlzgdshtryblvxkursengtvhjbhqmzaawyluvngaekrtpwjcycotkdzmxhspchonhvcqyrzgkqvlprlfaio"))&&((var0+"yerbtlubezpneqtverirrbxniuvjfrgqopxagusfqfrrdrsrxnvzzvvzfbikbhivgmojhgrbsgarolcfuvoxayqkdrmen")!=(var0+"ybtaiwwlwt")))){
System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 42");
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 43");
}
if( (((var0+"qyxcnebwizjcgksbwedvktnb")==(var0+"vigmdnkmjoriwojylruzyhgupuxmibblzs"))&&((((var0+"ecrqglufnpolmelatulnfxyjalfvpiuepgphxhrrpnzsjgchkldfbufulhoouyklyxfspwmbvvhypgjnctfyzopugvrnmhryvxbko")+((var0+"giwtyeirjxocertrdhkkjnpomrsjvcbuqistqaippisboxuehmzhdsqmfwsntukcrazsnswgbxtqwyiia")+(var0+"wuwmrdgguveywjhfhfbtbfhagqvrszjljop")))+(var0+"jkbcqxztdxzwlyxdnoddnocxghrmmulptvdqavqiwtdiumigqklftbroxydrldais"))!=(var0+"nuaqstukxbgsnhsvnugpibzdemzgvpkonlfhhhjrbqjahdltmchjqpmltbwyysfltvqpuagpljqscthecdl")))){
System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 50");
}
if(((var0+"lpeliffrftriqnhgxrxliavvbzbgisiaroeiqmfbcrwewzmmzjl")==(var0+"rhdyruoctvbojftfptt"))){
System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 57");
}
else{
 f2[48] = new TenKLOC19();
}
if( ((var1*(long)(470))==(var1/(long)(309)))){
System.out.println("TenKLOC13 - TenKLOC13method0- LineInMethod: 63");
}
if( (((((var2*(double)(0.8958166574926772))%(double)(0.24636269122543253))/(double)(0.9585057628279279))==(((var2*(double)(0.3095785789224449))-((var2*(double)(0.4087522379285674))+(var2*(double)(0.9233074191776849))))-(var2%(double)(0.20706541334503337))))&&((((var2-(double)(0.09438280352561079))>(var2-(double)(0.210576924744872)))&&((var2-(double)(0.9587637998730748))<(f1[48]/(double)(0.28533376683141576))))||(((f1[60]-f1[116])*((f1[125]%(double)(0.4076265476718306))*(f1[61]*f1[182])))<(var2+(double)(0.14709191078523054)))))){
var2 = (double)(((((var2-(double)(0.30852461835174594))*(var2+(double)(0.6446373529938386)))+(var2*(double)(0.8266273812178893)))+(var2%(double)(0.17994330607429954)))+(var2-(double)(0.26048404586875507)));
}
return (double)var2;

}

public byte TenKLOC13method1(String var0, float var1, TenKLOC18 var2){
 TenKLOC13 classObj = new TenKLOC13();
if(((var1+(float)(0.59301805))>(var1/(float)(0.5777571)))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 5");
}
else{
 TenKLOC1.TenKLOC1method4((byte)(41),(double)(0.2173464723012215),var0,(short)(21209));
}
for(int i = 0; i < 0; i++){
 System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 10");
}
if(((var1/(float)(0.056253433))<=(var1-(float)(0.6572618)))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 18");
}
else{
 f0[48] = (long)(((((long)(378)/(long)(486))-((long)(533)+(long)(288)))*((long)(355)*(long)(342)))-((long)(428)/(long)(291)));
}
if( (((var0+"bdqaigifuhqwqbjgunausvogtrxcispfzlimbyrjdox")+((var0+"rkdhdlekgbbrdsfrnclddlxwrpnnnejjgqkerhpagmxyhoqcdvjjhjihmdpybbujzlakatiznmzlzfbm")+((var0+"lsjtglllolonoooendkslaxmmuybkqbxpyzinmjjidakayruusxbmieowiqbralwvrnsyxs")+(var0+"bfgjzkdkjvlguwxlsrolylfnuvdvsprknmnuoznazwbqscatmmiokmmodzggkcfiqrdlesf"))))==(var0+"cbbudpcvuhaqiinqsiavxcgtsovqbbrqthwocmm"))){
if( ((var1%(float)(0.9364297))<=(var1/(float)(0.7389417)))){
if( (((((((var0+"pzaovfwvtftnyliwmuhttewsnbypmzgpzptvnnxdcxrwzisusomqvps")+(var0+"jkjecqwlkduanllvdpsmdsadyvuqaukymhhkuctxgymkgleufubngtodefdmvxdipqxhneeyv"))+(var0+"kknjssckvvjvjmqzpmnrzqevlabadvlxvmjgtagqtriaueihh"))+((var0+"nbwfqzrdcgzjxjdyqjgn")+(var0+"cxfmvnpnlfsxhjxm")))+((var0+"mptarxtzhlzmufgfiixrlcymljdjsbpkyxsuimuiclswdywsgyrzmgqunxbmmf")+(var0+"pvbgrlkfkwnemvrxsrcyqrconnsdmlwozzifahgrelllgjgpkceldhrildwkobtjwjpcn")))!=(var0+"dnleu"))&&((var0+"wfdetznodjioubpphwjlongdnzhhchvkzwtcxwpzyormludwrrnzovfiqjnomutzeidrpjlopxhzkczpfwejbhum")==((var0+"szphx")+(var0+"xbeghfavqt"))))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 29");
}
}
}
if(((var1-(float)(0.69242007))<=((((((var1%(float)(0.75764245))/(float)(0.41070104))-(var1+(float)(0.25353974)))-(var1+(float)(0.8571423)))-(var1%(float)(0.37278318)))+(var1/(float)(0.29108858))))){
var2 = new TenKLOC18();
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 36");
}
if((((((var0+"bwhmuf")+(var0+"spqcfkpronehvuvganqs"))==(var0+"kxjwkcplihjijrvphseozhfvuefyzsuw"))&&((var0+"zjluzixhudurgcoazbityzglylorojyiko")!=((var0+"pipadvvypolnjehnuab")+(var0+"slwfqqryph"))))&&(((var0+"ekiohebaj")!=((var0+"vovqgcryhmtspslqfazieblvljqu")+(var0+"ctxzyqonpftvnowvxiyrplwxlu")))&&(((var0+"ctxdphiwbqkqmgvmcx")==(var0+"qnwzslsltosgelncpopysoxqaawjxlmjskgvwfcjptzufcskfaojuzihoucvsxgdfxjvdewttkkv"))&&(((var0+"ostoydqxayvjjyabpfyghgmarhspzjpthxhrqiduvlwhxrrzvalrmirpexyrnkoriguygbidbhamtiwaki")!=(var0+"kuexxsdyftrlplvjmikuvlxjvwvboamhcdltkgmxtfcbsgwztxbtkidscbquwzthxgonanhfiemfrzphscuoinhcnttncxhu"))&&(((var0+"oktfhjhpbsqvgrfxhpcjikaqnbvtshetteuqmnoaxjphyymevbcytjzwqxnltmlkuvshkurqcnmddntjlulrmizyjhmnslpwl")!=(var0+"umjupyuswxsmdijiguzqoalpbhzfjvielyxefkylfmrxvwxaylofqdrflwxndimozxkbmkzsnkggrjbnwcahqxjghgrcuezcn"))||((var0+"duzniicuxjrnuiilqjnbmvnqjqldmmvtn")==(var0+"gxkcwnuupqnqnzjuiijsrazrxwltyrkxcunommrsfyh")))))))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 41");
}
else{
 f0[34] = (long)((((long)(111)*(long)(246))-(((long)(21)/(long)(761))%(long)(280)))/(long)(389));
}
if( ((var1/(float)(0.46290427))<=((var1+(float)(0.48665047))%(float)(0.537805)))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 47");
}
if( ((var0+"lwpggpdfmrsrzybwmuptzkuhbtnmflokwctguxlbcwgefqnbrxghzbpewbg")==(var0+"cfuqsfvqjdrrlkymwqosoiveufvqarssrtlaynirkadogp"))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 53");
}
if(((var0+"hrmxnoyprkyeqihudlykoplhexhbcftupprskqudkdqgzseernxyxoxuifsh")==(var0+"pfsjcwqvvrrfphpczxsgvpmskyglojzahbckqwcbmjqlicbaqhioaepiuruxqengyvtpxmamclcdkrogmrtpmbvlzvwxyldrsyqaq"))){
System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 60");
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method1- LineInMethod: 63");
}
if( ((var0+"pwtlkszybulhngvdcxerfqrqs")==((var0+"hewiyqhlwbjyezgyupixuxyyasssbn")+(var0+"klvndxhomwiukefvjxiuuz")))){
var0 = (String)((var0+"apxoessttjxblyidltlkrwiztyaymeebrteybgkrwbqpgfzfarklwdwopiacrhbiqvtbfo")+(var0+"suznagqyvmtzzuxjnjgsygbkpqtnnckenciixmzzfwrnggawooaxwwwqiagfjfhmabqxer"));
}
return (byte)(byte)(-27);

}

public long TenKLOC13method2(byte var0, char var1, long var2){
 TenKLOC13 classObj = new TenKLOC13();
if(((var1%'g')<(var1*'m'))){
TenKLOC1.TenKLOC1method0((double)(0.981844650423314),null,(float)(0.2682433));
}
else{
 var0 = (byte)(var0/(byte)(-54));
}
if((((var2*(long)(660))==(f0[60]/(long)(401)))&&((f0[31]-f0[7])<(var2+(long)(70))))){
f0[8] = (long)(((f0[31]-f0[29])+(f0[10]*f0[29]))%(long)(772));
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 12");
}
for(int i = 0; i < 3; i++){
 System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 16");
}
if(((f0[52]/(long)(577))==((var2*(long)(129))+(((((var2+(long)(200))*(var2/(long)(1)))-(var2*(long)(335)))*(var2+(long)(638)))/(long)(530))))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 23");
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 27");
}
for(int i = 0; i < 5; i++){
 if( ((((var1-'v')>(var1+'v'))&&((var1*'v')==((var1/'i')+(var1/'p'))))||(((var1+'q')+((var1/'x')%'r'))>((var1*'c')*((var1+'i')-(var1*'r')))))){
if( ((var1/'e')!=(var1+'v'))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 37");
}
}
}
for(int i = 0; i < 6; i++){
 if( ((var0+(byte)(-48))>(var0/(byte)(-17)))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 45");
}
}
if( ((var1*'g')<=(var1%'z'))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 49");
}
if( (((var2*(long)(126))<=(var2+(long)(680)))&&((f0[16]%(long)(135))!=(var2-(long)(236))))){
if( ((var0-(byte)(-27))!=(var0+(byte)(115)))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 54");
}
}
for(int i = 0; i < 3; i++){
 f0[60] = (long)(var2%(long)(571));
}
if((((var2*(long)(318))-(var2*(long)(494)))>(f0[34]*f0[19]))){
System.out.println("TenKLOC13 - TenKLOC13method2- LineInMethod: 62");
}
else{
 f0[69] = (long)((var2-(long)(222))+((var2+(long)(270))*(var2+(long)(750))));
}
return (long)var2;

}

public String TenKLOC13method3(byte var0, TenKLOC27 var1, double var2){
 TenKLOC13 classObj = new TenKLOC13();
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 3");
}
for(int i = 0; i < 2; i++){
 if( ((var2+(double)(0.8555089549517505))==(var2-(double)(0.1062114241870763)))){
if( ((var2%(double)(0.934580741823237))==(var2*(double)(0.522237856020512)))){
f0[23] = (long)((long)(215)+(long)(341));
}
}
}
if( ((var0+(byte)(106))>=(var0-(byte)(-54)))){
if( ((var0-(byte)(-14))<(var0*(byte)(-117)))){
TenKLOC27.TenKLOC27method4(var0,var0,(int)(199),(int)(550));
}
}
for(int i = 0; i < 2; i++){
 if( (((((var0+(byte)(53))*((var0-(byte)(93))+(var0-(byte)(71))))*(var0/(byte)(9)))*(var0/(byte)(126)))>=(var0*(byte)(103)))){
System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 20");
}
}
if( ((var0-(byte)(-87))>=(var0-(byte)(-79)))){
f0[18] = (long)((((long)(612)+(long)(622))*((long)(707)*(long)(69)))-((long)(42)-(long)(313)));
}
if(((var0*(byte)(6))>(var0+(byte)(122)))){
System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 32");
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 34");
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 39");
}
if((((var0*(byte)(-92))+(var0/(byte)(-99)))!=(var0-(byte)(111)))){
System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 48");
}
else{
 System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 53");
}
if( ((var2%(double)(0.44282445130833037))!=(var2*(double)(0.8991553282030477)))){
var2 = (double)(((var2-(double)(0.3527127644185022))%(double)(0.4580247326208956))*(var2-(double)(0.7182620638332456)));
}
if( (((var2+(double)(0.24497534039905078))==(var2+(double)(0.19284614611019646)))&&((((var2%(double)(0.11966176030337183))-(var2*(double)(0.651599295311217)))-(var2*(double)(0.9458775509498444)))<(var2%(double)(0.9501417718433488))))){
var1 = new TenKLOC7();
}
for(int i = 0; i < 9; i++){
 if( ((var0*(byte)(12))!=(var0+(byte)(-74)))){
System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 64");
}
}
if( ((var0+(byte)(57))!=(var0-(byte)(82)))){
System.out.println("TenKLOC13 - TenKLOC13method3- LineInMethod: 67");
}
return (String)"fkwpvpbjulznswatlsbkuquwhfreuvzdwxbk";

}

public static int TenKLOC13method4(byte var0, float var1, int var2){
 TenKLOC13 classObj = new TenKLOC13();
if(((var0+(byte)(77))==(var0%(byte)(48)))){
var0 = TenKLOC1.TenKLOC1method2(null,(short)(16973),var0,var1,(short)(15969));

}
else{
 System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 6");
}
if( ((var0/(byte)(69))<((var0*(byte)(-32))+((var0-(byte)(77))/(byte)(-3))))){
if( ((((var2-(int)(531))+(var2-(int)(42)))/(int)(462))>=(var2*(int)(641)))){
if( ((var1+(float)(0.9407422))<=(var1-(float)(0.27515644)))){
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 14");
}
}
}
switch((var2-(int)(91))){
case 0:
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 19");
 break;
case 1:
var1 = (float)((var1-(float)(0.84783566))%(float)(0.13920802));
 break;
case 2:
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 25");
 break;
default :
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 29");
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 34");
}
if( ((var2-(int)(470))>=(var2+(int)(539)))){
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 37");
}
switch((var2%(int)(16))){
case 0:
var2 = (int)(((var2*(int)(771))+(var2/(int)(462)))-(var2-(int)(661)));
 break;
case 1:
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 46");
 break;
case 2:
f1[159] = (double)(((double)(0.803116360571229)%(double)(0.9661579457783426))%(double)(0.16763351180538488));
 break;
default :
f1[124] = (double)(((double)(0.37703899267047525)*(double)(0.6243766231911153))/(double)(0.1719944582857934));
}
for(int i = 0; i < 2; i++){
 if( ((var2-(int)(397))<=(var2/(int)(306)))){
f1[73] = (double)(((double)(0.1321129261846704)%(double)(0.41286439382499185))%(double)(0.2566368287348264));
}
}
switch(((var2-(int)(629))-((var2%(int)(770))/(int)(88)))){
case 0:
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 64");
 break;
case 1:
f2[6] = new TenKLOC26();
 break;
case 2:
var2 = (int)((var2+(int)(118))*(var2+(int)(563)));
 break;
case 3:
var1 = (float)((var1-(float)(0.3052402))*(var1+(float)(0.5191676)));
 break;
case 4:
f2[82] = new TenKLOC1();
 break;
case 5:
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 82");
 break;
default :
System.out.println("TenKLOC13 - TenKLOC13method4- LineInMethod: 86");
}
return (int)var2;

}


public static void main(String args[]){
TenKLOC13 obj = new TenKLOC13();
TenKLOC13method0("nnvsbnw",(long)(328),(double)(0.6551338680795287));
obj.TenKLOC13method1("zsujzguzaduealaoctqtywdhfwinjkocuyjvgiuvfmignlekecolmiquylxpzzdtzckrvi",(float)(0.36482173),new TenKLOC18());
obj.TenKLOC13method2((byte)(18),'t',(long)(606));
obj.TenKLOC13method3((byte)(121),new TenKLOC27(),(double)(0.9081464684679742));
TenKLOC13method4((byte)(112),(float)(0.46793306),(int)(745));
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC13 obj = new TenKLOC13();
TenKLOC13method0("ajjnlbcyap",(long)(669),(double)(0.12326349140555182));
obj.TenKLOC13method1("jw",(float)(0.4040938),new TenKLOC18());
obj.TenKLOC13method2((byte)(-95),'d',(long)(240));
obj.TenKLOC13method3((byte)(45),new TenKLOC27(),(double)(0.09272298916163091));
TenKLOC13method4((byte)(28),(float)(0.043041408),i2);
}

}