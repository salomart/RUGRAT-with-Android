package com.accenture.lab.carfast.test;


public class TenKLOC12 implements TenKLOCInterface1 {
static String f0;
static char f1;
byte f2;
char[] f3= new char[95];
static int f4;


public short TenKLOCInterface1Method0(int var0, TenKLOC29 var1, short var2){
 TenKLOC12 classObj = new TenKLOC12();
for(int i = 0; i < 3; i++){
 if( (((var2*(short)(19693))+(var2+(short)(1722)))>=(var2/(short)(6688)))){
var0 = (int)(150);
}
}
for(int i = 0; i < 2; i++){
 if( ((var0+(int)(425))!=(var0%(int)(296)))){
if( (((var2-(short)(29459))<=((var2+(short)(29211))-(var2*(short)(7870))))||(((var2%(short)(14132))<(var2-(short)(19771)))&&((((var2*(short)(5954))!=(var2*(short)(15394)))&&((var2/(short)(29138))<=(((var2*(short)(12920))-((var2+(short)(29449))+(var2-(short)(31765))))+(var2/(short)(13123)))))&&((var2*(short)(26111))<=(var2-(short)(24772))))))){
if( ((var0-(int)(30))>=(var0*(int)(111)))){
var0 = (int)(((var0-(int)(473))+(var0-(int)(510)))/(int)(88));
}
}
}
}
for(int i = 0; i < 9; i++){
 if( ((var2-(short)(22940))>(var2%(short)(26401)))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 18");
}
}
for(int i = 0; i < 6; i++){
 System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 21");
}
if( ((var2*(short)(28535))>=((((var2-(short)(13512))*(var2%(short)(22284)))*(((var2*(short)(29497))+(var2-(short)(24615)))/(short)(10352)))*((var2+(short)(28866))*(var2/(short)(9947)))))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 27");
}
if( (((var0+(int)(517))*(var0+(int)(201)))<=(var0-(int)(574)))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 31");
}
switch((var0-(int)(487))){
case 0:
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 36");
 break;
case 1:
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 39");
 break;
case 2:
var0 = (int)((var0%(int)(593))+((var0+(int)(396))+(var0*(int)(150))));
 break;
case 3:
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 45");
 break;
default :
System.out.println("TenKLOC12 - TenKLOCInterface1Method0- LineInMethod: 50");
}
return (short)var2;

}

public String TenKLOCInterface1Method1(int var0, byte var1, String var2){
 TenKLOC12 classObj = new TenKLOC12();
if((((var0+(int)(669))-(var0*(int)(57)))<(var0/(int)(452)))){
var1 = (byte)((var1-(byte)(35))-(f2+(byte)(-23)));
}
else{
 f2 = (byte)((var1+(byte)(90))-((var1/(byte)(-52))*(var1%(byte)(-63))));
}
for(int i = 0; i < 1; i++){
 if( ((var2+"sbotgojhrqenbszsewjlwuvdlmurungqozrylzlqlvwmcwyznvtrhmsmlxntxfhpicrlzglnhmo")!=(var2+"zpfdwoaqxqpytokchmxqwerdyllxcntzmzgolyvvfkmwrcoqse"))){
if( ((var1-(byte)(-81))!=(var1%(byte)(54)))){
if( ((((var1/(byte)(61))+(var1+(byte)(-36)))>(var1%(byte)(-11)))&&((var1-(byte)(54))!=(f2+(byte)(14))))){
f3[84] = (char)(('i'/'m')-('f'-'h'));
}
}
}
}
for(int i = 0; i < 6; i++){
 if( ((var2+"hkfvbpxqmlodntyvixeajlrfuyhqwfcnreoevxsaksgrdolsjfqfdrhtcoasvvqgy")==(var2+"agwvllvlslpwpfunnrlvorwaikbzhqtjcowhjqfrbbkzlnhmxwcqrlyzcrndrowipkanlsqivvsmibjxfhhyfyx"))){
f2 = (byte)((var1-(byte)(71))+(var1+(byte)(-87)));
}
}
switch((var0%(int)(243))){
case 0:
var2 = (String)(((var2+"awlbssasystrnhwdpacmq")+(var2+"ilwqnrzrsxvqgjocbonusholvxyuctktlqoyxx"))+(var2+"yndwqexosjiebmbqkrtuvgmvcmmzrrkagepncqnrdrhp"));
 break;
case 1:
var1 = (byte)(55);
 break;
case 2:
f3[36] = (char)(('h'*'n')*('c'-'b'));
 break;
case 3:
System.out.println("TenKLOC12 - TenKLOCInterface1Method1- LineInMethod: 31");
 break;
case 4:
f3[20] = (char)(('r'-'p')%'n');
 break;
case 5:
f2 = (byte)((var1+(byte)(-82))-(var1/(byte)(126)));
 break;
case 6:
System.out.println("TenKLOC12 - TenKLOCInterface1Method1- LineInMethod: 40");
 break;
case 7:
f2 = (byte)((var1*(byte)(-65))-(((var1*(byte)(-61))*((var1%(byte)(-72))+(var1+(byte)(99))))/(byte)(-10)));
 break;
default :
System.out.println("TenKLOC12 - TenKLOCInterface1Method1- LineInMethod: 46");
}
return (String)var2;

}

public Object TenKLOCInterface1Method2(double var0, byte var1, int var2){
 TenKLOC12 classObj = new TenKLOC12();
if(((var1*(byte)(10))==(var1*(byte)(-114)))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method2- LineInMethod: 5");
}
else{
 System.out.println("TenKLOC12 - TenKLOCInterface1Method2- LineInMethod: 6");
}
for(int i = 0; i < 9; i++){
 if( ((((var2-(int)(652))*(var2+(int)(481)))-(var2%(int)(25)))<=(var2/(int)(571)))){
if( ((var2-(int)(586))!=(((var2*(int)(185))+((var2-(int)(720))-(var2-(int)(29))))%(int)(101)))){
if( ((var2+(int)(725))!=(var2-(int)(425)))){
}
}
}
}
if( ((var0%(double)(0.6542535071699149))==((var0*(double)(0.7472777826634455))-((var0-(double)(0.3217700153091645))+(var0+(double)(0.9794797326440201)))))){
f3[8] = (char)('g'-'q');
}
for(int i = 0; i < 6; i++){
 if( ((((var1%(byte)(-73))+(var1/(byte)(84)))-(var1/(byte)(120)))<(var1+(byte)(-121)))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method2- LineInMethod: 25");
}
}
if(((var1-(byte)(-96))>(var1*(byte)(-75)))){
f3[5] = (char)((f3[38]*f3[62])%'p');
}
else{
 f2 = (byte)((f2/(byte)(-74))%(byte)(30));
}
for(int i = 0; i < 5; i++){
 System.out.println("TenKLOC12 - TenKLOCInterface1Method2- LineInMethod: 34");
}
return (Object)null;

}

public double TenKLOCInterface1Method3(TenKLOC16 var0, float var1, int var2){
 TenKLOC12 classObj = new TenKLOC12();
if( (((var1*(float)(0.73459643))!=(var1+(float)(0.2968549)))&&(((((var1/(float)(0.46823472))>=(var1*(float)(0.109282315)))&&((var1%(float)(0.63876545))==(var1-(float)(0.7530784))))&&(((var1-(float)(0.67192125))!=((var1+(float)(0.59000826))+((var1/(float)(0.5314256))*(var1+(float)(0.50903744)))))||(((var1+(float)(0.18780589))==(var1*(float)(0.8785283)))&&((var1-(float)(0.3146174))==(var1+(float)(0.5253198))))))&&((var1+(float)(0.2798705))==((var1*(float)(0.9580035))-(var1*(float)(0.40018058))))))){
if( ((var1+(float)(0.56340486))>=((((var1*(float)(0.9291726))%(float)(0.18390977))+((var1+(float)(0.7628775))/(float)(0.20461738)))%(float)(0.32307637)))){
if( (((var1%(float)(0.16300881))!=(var1*(float)(0.83881396)))&&((var1/(float)(0.51313865))>=((var1+(float)(0.5298975))-((var1%(float)(0.32511812))*(var1-(float)(0.0062085986))))))){
TenKLOC16.TenKLOC16method0("yjpznmtthbzslnqayvidlbwoizsohejzhxuvolin",(double)(0.08850531611765478),var2);
}
}
}
for(int i = 0; i < 3; i++){
 f3[31] = (char)((f3[47]+f3[41])%'c');
}
for(int i = 0; i < 4; i++){
 if( ((var1-(float)(0.23182076))!=((var1+(float)(0.5622039))*(var1%(float)(0.33762705))))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method3- LineInMethod: 15");
}
}
if( ((var2/(int)(566))==(var2-(int)(212)))){
f3[73] = (char)(('b'/'l')-('j'-'q'));
}
if(((var1*(float)(0.59962034))>=(var1*(float)(0.17665255)))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method3- LineInMethod: 25");
}
else{
 System.out.println("TenKLOC12 - TenKLOCInterface1Method3- LineInMethod: 28");
}
if( (((var2*(int)(624))>=(var2%(int)(443)))&&(((var2+(int)(569))>=(var2/(int)(458)))&&((var2-(int)(511))>=(var2*(int)(636)))))){
System.out.println("TenKLOC12 - TenKLOCInterface1Method3- LineInMethod: 35");
}
return (double)(double)(0.8560124572866621);

}

public String TenKLOC12method0(String var0, String var1, TenKLOC22 var2, float var3){
 TenKLOC12 classObj = new TenKLOC12();
if((((var0+var1)!=((var1+"nanea")+(var1+"asmmrkkjrjcvipoapxebpefhsuvsqcmdkxolbwexdkuziakqdvclqwydusrhhkwgigfqoujspijaphwnnmvshql")))&&(((var0+var1)+(var0+"rhwazyvugqzgxbuntujxfpsdypdzgtpyiuhgxqpvcnpqwoqynfuvoqsxnjgnpkaxuudgeqrmqylevabobi"))==(var1+"cwuhwidpxpfnbtedbwusymtgzddafdeisebchzerilhzovgajsdokpmhlqukjgeai")))){
var3 = (float)(var3-(float)(0.15822786));
}
else{
 var0 = "nvwuehawfrwfjrjmfrzlhfubyuopztnoczmdfzqrjffexutvoctmjuxqqtzmfbgohcgdaijumcwejgvb";
}
if(((var3/(float)(0.42647004))>=(var3-(float)(0.6431744)))){
System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 10");
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 11");
}
if(((var3*(float)(0.23661435))==(var3*(float)(0.48431385)))){
System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 20");
}
if( ((var3-(float)(0.122828186))>=(var3-(float)(0.74013674)))){
System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 25");
}
if((((var3%(float)(0.07730305))*(var3-(float)(0.63468164)))>((var3/(float)(0.29289317))%(float)(0.7475256)))){
System.out.println("TenKLOC12 - TenKLOC12method0- LineInMethod: 32");
}
else{
 f3[30] = (char)((f3[70]+f3[39])%'b');
}
return (String)var1;

}

public static Object TenKLOC12method1(int var0, short var1, String var2){
 TenKLOC12 classObj = new TenKLOC12();
for(int i = 0; i < 7; i++){
 f0 = (String)((var2+"xrpbqeuoxoagsuxgvgmwjmynpeuycxeqzjgzsmwai")+(f0+"bprdkkuqaqzgzftcaxackbchsparnxxcyzmgsvxssajjjtuexrkomxueegtbqwgrswouccqbqkciizrndh"));
}
for(int i = 0; i < 5; i++){
 if( ((var0+(int)(67))<=(var0%(int)(601)))){
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 8");
}
}
if((((((var0-(int)(29))-(var0*(int)(574)))+(var0%(int)(341)))-(var0*(int)(581)))!=(var0/(int)(735)))){
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 14");
}
else{
 var1 = (short)(((var1*(short)(11748))-(var1+(short)(18743)))%(short)(32543));
}
for(int i = 0; i < 1; i++){
 f1 = (char)(('j'/'m')+('p'+'c'));
}
if( ((var1+(short)(27729))==(var1%(short)(23791)))){
if( (((var2+"hdifzctbvhngvrgmwqnfv")!=(f0+"hsnycjjeokkryfyyurinhcucj"))||((var2+"mftfgsuddlvezcyesyzbrqkfzwdpgqqcyomijlgllucnwmotuzfmqfapxocsjkuwswpvsbggxndh")==(((var2+"qwljhrswqthmbruyqyfbuurqqefexnzibpagejkd")+(var2+"ngerymiymxemwr"))+(var2+"mmthzppqpeklzqtllginnjflgazpkhlkwbwujspnotwstqbcxnjfihonlorperxxyjzbiofolqtkzln"))))){
if( ((f4*(int)(267))!=(var0/(int)(676)))){
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 26");
}
}
}
if( (((var1+(short)(19526))+(var1-(short)(24464)))==(var1*(short)(5199)))){
}
switch((var0+(int)(139))){
case 0:
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 32");
 break;
case 1:
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 39");
 break;
case 2:
var1 = (short)((var1%(short)(12783))-(var1*(short)(23627)));
 break;
case 3:
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 45");
 break;
default :
System.out.println("TenKLOC12 - TenKLOC12method1- LineInMethod: 52");
}
return (Object)null;

}

public static byte TenKLOC12method2(byte var0, char var1, String var2, TenKLOC22 var3, short var4){
 TenKLOC12 classObj = new TenKLOC12();
if((((var0*(byte)(-115))+(((var0-(byte)(93))+(var0+(byte)(61)))+(var0-(byte)(-123))))<(var0*(byte)(34)))){
f1 = (char)((var1-'m')/'n');
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method2- LineInMethod: 6");
}
if((((var4%(short)(21682))*(var4-(short)(24456)))<(var4%(short)(20387)))){
var3 = new TenKLOC22();
var0 = var3.TenKLOC22method4(var4,var1,(double)(0.408704815668953));

}
else{
 System.out.println("TenKLOC12 - TenKLOC12method2- LineInMethod: 12");
}
for(int i = 0; i < 2; i++){
 if( ((((var1/'q')+(var1-'v'))+((var1+'t')*(((var1*'t')*(var1-'y'))*(var1/'f'))))<=(var1+'v'))){
var0 = (byte)((var0+(byte)(103))%(byte)(-2));
}
}
for(int i = 0; i < 9; i++){
 f0 = (String)((var2+"vpa")+(var2+"czbirj"));
}
if( ((f1*'i')!=(var1/'z'))){
f4 = (int)(((((int)(277)*(int)(364))*((int)(329)%(int)(389)))*((int)(552)/(int)(9)))/(int)(611));
}
if(((var0/(byte)(-35))<=(var0+(byte)(100)))){
System.out.println("TenKLOC12 - TenKLOC12method2- LineInMethod: 29");
}
else{
 var2 = (String)(var2+"bwzuibepxybgpnqqctphhzavpmjpmoimjbrmitbrjcihpvcyfmocswkscqyydfempjgxnddcyarsrzm");
}
if( (((var0+(byte)(109))>(((var0*(byte)(-90))+(((var0-(byte)(14))*(((var0+(byte)(60))-(((((var0+(byte)(55))+(var0%(byte)(87)))+((var0*(byte)(-56))/(byte)(-111)))*(var0+(byte)(24)))*((var0/(byte)(61))-(var0*(byte)(57)))))-((var0-(byte)(100))+(var0-(byte)(61)))))-(var0*(byte)(23))))-(((var0/(byte)(-26))+(var0+(byte)(123)))*((var0-(byte)(-76))%(byte)(-32)))))&&((var0-(byte)(50))>=(var0*(byte)(29))))){
if( ((var0-(byte)(19))<=(var0*(byte)(75)))){
System.out.println("TenKLOC12 - TenKLOC12method2- LineInMethod: 37");
}
}
return (byte)var0;

}

public int TenKLOC12method3(char var0, short var1, long var2, float var3, float var4){
 TenKLOC12 classObj = new TenKLOC12();
if(((var3*var4)<=((var3*var4)+(var4*(float)(0.6272897))))){
}
else{
 f2 = (byte)(((byte)(-125)/(byte)(-103))*((byte)(47)+(byte)(-49)));
}
if(((var3*(float)(0.27933675))<=(var4*(float)(0.54136926)))){
f3[15] = (char)((var0+'t')+(var0%'t'));
}
else{
 var2 = (long)(((var2*(long)(2))+(var2-(long)(705)))*(var2*(long)(513)));
}
if((((var4-var3)+(var4%(float)(0.4525442)))!=(var4-(float)(0.6498094)))){
System.out.println("TenKLOC12 - TenKLOC12method3- LineInMethod: 16");
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method3- LineInMethod: 19");
}
if((((var1+(short)(30104))<((var1*(short)(1319))*((var1%(short)(5187))+(var1%(short)(15050)))))&&((var1/(short)(28565))==(var1+(short)(1838))))){
System.out.println("TenKLOC12 - TenKLOC12method3- LineInMethod: 28");
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method3- LineInMethod: 31");
}
for(int i = 0; i < 1; i++){
 System.out.println("TenKLOC12 - TenKLOC12method3- LineInMethod: 37");
}
return (int)(int)(458);

}

public String TenKLOC12method4(int var0, byte var1, char var2){
 TenKLOC12 classObj = new TenKLOC12();
if( ((var1+(byte)(2))>((var1-(byte)(-12))-(var1/(byte)(-103))))){
var2 = (char)((var2*'v')-(var2/'k'));
}
if( (((var2-'g')>(f3[23]-f3[60]))&&(((var2-'s')!=(var2-'k'))||(((var2-'r')>(var2+'b'))||(((var2%'e')!=(var2-'z'))||(((var2+'d')==(var2*'o'))&&((var2-'u')>=(var2-'l')))))))){
if( ((var2*'u')==(var2-'c'))){
f2 = (byte)((var1/(byte)(69))-(var1-(byte)(-51)));
}
}
if( ((f3[55]+f3[61])<(var2%'n'))){
if( (((var0*(int)(350))==(var0*(int)(128)))&&(((var0-(int)(400))-(var0+(int)(117)))<=(var0+(int)(136))))){
}
}
for(int i = 0; i < 3; i++){
 if( ((var1/(byte)(-83))<((var1-(byte)(-40))-(var1+(byte)(-21))))){
f2 = (byte)((var1-(byte)(42))-((f2+(byte)(80))+(f2%(byte)(64))));
}
}
if( (((var1-(byte)(-13))%(byte)(-48))>((f2-(byte)(47))%(byte)(58)))){
var2 = (char)(((f3[25]*f3[34])-(((f3[36]-f3[62])-(f3[37]+f3[74]))/'q'))+((var2-'j')*((var2+'q')-(var2*'c'))));
}
if(((((var2+'h')*(var2+'v'))!=(var2+'z'))&&((f3[71]-f3[47])>((var2/'t')*(var2-'n'))))){
var1 = (byte)((var1/(byte)(-126))+(f2*(byte)(30)));
}
else{
 System.out.println("TenKLOC12 - TenKLOC12method4- LineInMethod: 26");
}
if((((var2-'w')*((var2+'x')+((var2+'h')/'x')))==((var2*'k')*(var2+'o')))){
System.out.println("TenKLOC12 - TenKLOC12method4- LineInMethod: 33");
}
else{
 f2 = (byte)((f2*(byte)(-26))-(f2*(byte)(-105)));
}
return (String)"ijoysvcmwbunbbfodqiawitwtfxjrgyaof";

}


public static void main(String args[]){
TenKLOC12 obj = new TenKLOC12();
obj.TenKLOCInterface1Method0((int)(713),new TenKLOC29(),(short)(25499));
obj.TenKLOCInterface1Method1((int)(132),(byte)(26),"xgbfijqrnzbmgcugvgmbnupcftpctwfngjqxkkkursw");
obj.TenKLOCInterface1Method2((double)(0.6927733366399043),(byte)(-53),(int)(265));
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.48000693),(int)(500));
obj.TenKLOC12method0("zhv","bqcsjecfpmjjqryrizpnqoyrjijmkmetspwkxvxfvugsabqvuyfykeeijhxyonfuszzaau",new TenKLOC22(),(float)(0.5717628));
TenKLOC12method1((int)(45),(short)(13025),"yfbevgktepqhndwotfqnbakfbcwiresvlqxbgiagddroud");
TenKLOC12method2((byte)(84),'q',"cazircoferpqakwqpjjsyodmxj",new TenKLOC22(),(short)(27272));
obj.TenKLOC12method3('s',(short)(22495),(long)(426),(float)(0.028365612),(float)(0.26764095));
obj.TenKLOC12method4((int)(710),(byte)(-15),'a');
}

public static void singleEntry(int i0,int i1,int i2,int i3,int i4,int i5,int i6){
TenKLOC12 obj = new TenKLOC12();
obj.TenKLOCInterface1Method0(i5,new TenKLOC29(),(short)(24399));
obj.TenKLOCInterface1Method1(i4,(byte)(-5),"krkxmhkcuwhtrdghpe");
obj.TenKLOCInterface1Method2((double)(0.957120065350506),(byte)(-121),i5);
obj.TenKLOCInterface1Method3(new TenKLOC16(),(float)(0.8675669),i5);
obj.TenKLOC12method0("ktlminjrvxqeguhhtocqroimiyhvnupumlbpvguukkcqysvoygifpklagzvxauyxyuhsuggescpkzotceritkjuh","gpkrlbnpkmxdrpzsjkyhhkguwegjlrcnrvivdnhymmwyplvshuxwqzavanwaoxvwjbwymtslm",new TenKLOC22(),(float)(0.8694877));
TenKLOC12method1(i1,(short)(407),"xbcnubilxkuksxzhckkanzumfofus");
TenKLOC12method2((byte)(-120),'p',"cvksgidmijbcjlkwcjcvclcdwvyifxlaxbyiziferabyhvfzwyzhfkketwqu",new TenKLOC22(),(short)(30109));
obj.TenKLOC12method3('m',(short)(4397),(long)(521),(float)(0.37052643),(float)(0.6152662));
obj.TenKLOC12method4(i0,(byte)(40),'t');
}

}